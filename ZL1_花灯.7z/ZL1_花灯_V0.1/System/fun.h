
#ifndef HUADENG_FUN_H
#define HUADENG_FUN_H

#include <stdbool.h>
#include "io_define.h"
#include "menu/menu.h"

#define MAX 2399

#define PWM_RED 0xFF000000
#define PWM_GREEN 0x00FF0000
#define PWM_BLUE 0x0000FF00
#define PWM_WHITE_ONLY 0x000000FF
#define PWM_WHITE 0xFFFFFFFF
#define PWM_RED_GREEN 0xFFFF0000
#define PWM_RED_BLUE 0xFF00FF00
#define PWM_GREEN_BLUE 0x00FFFF00
#define PWM_BLACK 0x00000000

typedef struct  mode_ctrl
{
    uint8_t mode;    //��ǰģʽ
    uint16_t run_time_16;  //����ʱ��
    uint16_t max_run_time_u16; //�������ʱ��
    uint16_t motor_run_time_16;
    uint16_t motor_max_run_time_u16;
    uint16_t mic_time;
    uint32_t store_time_16;
    uint32_t store_next_time_16;
    uint32_t store_light_time_16;

    uint32_t ws2812_run_time; //WS2812 ����ʱ��
}_mode_ctrl;

typedef struct {
    bool console_ir_mode;
    bool other_in_axxx;
    uint8_t console_ch_diff_ch25_mode;  //ws2812 mode choic
    uint8_t console_ch_diff_ch26_mode;  //ws2812 speed
    uint8_t console_ch_diff_ch27_mode;


    uint8_t console_ch_ease_ch15_mode;  //ws2812 speed
    uint8_t console_ch_ease_ch16_mode;  //ws2812 speed
    uint8_t console_ch_ease_ch17_mode;  //ws2812 speed

    uint8_t console_ch_ease_all_speed;
    uint8_t console_ch_diff_all_speed;

    uint8_t console_ch_ease_sexx_speed;
    uint8_t console_ch_diff_sexx_speed;
    Menu_With_Numbers *other_menu_addr;

} _console_data;

void fun_set_rg(bool r, bool g);  //
void fun_set_rgbw0(uint8_t r, uint8_t g, uint8_t b, uint8_t w);
void fun_set_rgbw1(uint8_t r, uint8_t g, uint8_t b, uint8_t w);
void fun_set_rgbw2(uint8_t r, uint8_t g, uint8_t b, uint8_t w);

void fun_set_rg_store(_mode_ctrl * modeCtrl,uint16_t min,uint16_t max,uint16_t store_speed,bool r, bool g);
void fun_set_rgbw0_store(_mode_ctrl * modeCtrl,uint16_t min,uint16_t max,uint16_t store_speed,uint8_t r, uint8_t g, uint8_t b, uint8_t w);
void fun_set_rgbw1_store(_mode_ctrl * modeCtrl,uint16_t min,uint16_t max,uint16_t store_speed,uint8_t r, uint8_t g, uint8_t b, uint8_t w);
void fun_set_rgbw2_store(_mode_ctrl * modeCtrl,uint16_t min,uint16_t max,uint16_t store_speed,uint8_t r, uint8_t g, uint8_t b, uint8_t w);

void fun_set_motor();

void fun_master_send_data();
void fun_slave_recv_data();
void fun_mode_timer_run();
void fun_mode_time_reset();
void fun_set_run_mode(_mode_ctrl * modeCtrl,uint16_t mode,uint16_t max_run_time);
extern _mode_ctrl mode_use;
extern _console_data console_data;

#endif //HUADENG_FUN_H

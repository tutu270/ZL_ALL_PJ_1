#include "flash.h"
#include "menu/menu.h"
#include "usartx/dmx.h"
#include "decode_433/d_433.h"


// д�� Flash (��ַ������2�ı���)
void flash_write()
{
    uint32_t tempAddress = FLASH_SAVE_ADDR; // ����flash��ʼ��ַ
    if ( d_433_on_or_off) return;

    // ���� Flash
    __disable_irq();
    RS485_TX_EN();
    FLASH_Unlock();

    // ����ҳ��������Ҫ���ã�һ���Ȳ�����д�룩
    FLASH_ErasePage(tempAddress);

    extern Menu_With_Numbers *menu_level_front_desk[];
    extern Menu_With_Numbers *ptr;
    extern Menu_With_Numbers *sys_ptr;  // ָ������̨ʱ�����ڵ�ǰ̨��ַ

    // д������
    FLASH_ProgramHalfWord(tempAddress, FLASH_SAVE_FLAG);
    tempAddress += 2;

    for (uint8_t i = 0; i < MENU_ARR_SIZE; i++) {
        FLASH_ProgramHalfWord(tempAddress, menu_level_front_desk[i]->number);
        tempAddress += 2;
    }

    if (sys_ptr == NULL) {
        if (ptr->master_menu != NULL) {
            FLASH_ProgramHalfWord(tempAddress, (uint16_t) ((uint32_t) ptr->master_menu >> 16));
            tempAddress += 2;
            FLASH_ProgramHalfWord(tempAddress, (uint16_t) (uint32_t) ptr->master_menu);
        }else{
            FLASH_ProgramHalfWord(tempAddress, (uint16_t) ((uint32_t) ptr >> 16));
            tempAddress += 2;
            FLASH_ProgramHalfWord(tempAddress, (uint16_t) (uint32_t) ptr);
        }
    }else{
        if (sys_ptr->master_menu != NULL) {
            FLASH_ProgramHalfWord(tempAddress, (uint16_t) ((uint32_t) sys_ptr->master_menu >> 16));
            tempAddress += 2;
            FLASH_ProgramHalfWord(tempAddress, (uint16_t) (uint32_t) sys_ptr->master_menu);
        }else{
            FLASH_ProgramHalfWord(tempAddress, (uint16_t) ((uint32_t) sys_ptr >> 16));
            tempAddress += 2;
            FLASH_ProgramHalfWord(tempAddress, (uint16_t) (uint32_t) sys_ptr);
        }
    }


    RS485_RX_EN();

    // ���� Flash
    FLASH_Lock();
    __enable_irq();

}

// ��ȡ Flash ����
uint16_t flash_read(uint32_t addr)
{

    return *(uint16_t *) addr;  // ��ָ����ַ��ȡ����
}

void Flash_GetSaveVariable()
{
    uint32_t tempAddress = FLASH_SAVE_ADDR;
    extern Menu_With_Numbers *menu_level_front_desk[];
    extern Menu_With_Numbers *ptr;
    // �ж϶�ȡ�������Ƿ�Ϊ flash_First_Bit_Flag
    if (FLASH_SAVE_FLAG == flash_read(FLASH_SAVE_ADDR)) {

        for (int i = 0; i < MENU_ARR_SIZE; i++) {
            tempAddress += 2;
            menu_level_front_desk[i]->number = flash_read(tempAddress);
        }

        ptr = (Menu_With_Numbers *) (uint32_t) ((flash_read(tempAddress + 2) << 16) | flash_read(tempAddress + 4));
    }

}
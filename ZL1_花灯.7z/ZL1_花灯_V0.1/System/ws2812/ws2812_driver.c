//
// Created by tutu on 2024/10/26.

#include <string.h>
#include "ws2812_driver.h"
#include "adafruit_neopixel.h"
#include "ws2812fx.h"
#include "ws2812_fun.h"


uint8_t spi_tx_buffer[SPI_BUFFER_SIZE] = {WS2812_SEt_1H,WS2812_SEt_1H,WS2812_SEt_1H,WS2812_SEt_1H,WS2812_SEt_0H,WS2812_SEt_0H,0,0,WS2812_SEt_0H};  // SPI���ͻ�����
volatile uint16_t spi_data_size = 0;  // ���ݴ�С
volatile uint16_t spi_data_index = 0;  // ��ǰ��������
volatile uint8_t spi_transfer_complete = 1;  // ������ɱ�־

void ws2812_spi1_dma_init(void)
{
    GPIO_InitTypeDef GPIO_InitStruct;
    SPI_InitTypeDef SPI_InitStruct;
    DMA_InitTypeDef DMA_InitStruct;
    NVIC_InitTypeDef NVIC_InitStruct;

    RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOB, ENABLE);
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_SPI1, ENABLE);
    RCC_AHBPeriphClockCmd(RCC_AHBPeriph_DMA1, ENABLE);  // ʹ��DMA1ʱ��

    GPIO_InitStruct.GPIO_Pin = GPIO_Pin_5;
    GPIO_InitStruct.GPIO_Mode = GPIO_Mode_AF;
    GPIO_InitStruct.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStruct.GPIO_OType = GPIO_OType_PP;
    GPIO_InitStruct.GPIO_PuPd = GPIO_PuPd_NOPULL;
    GPIO_Init(GPIOB, &GPIO_InitStruct);

    GPIO_PinAFConfig(GPIOB, GPIO_PinSource5, GPIO_AF_0);

    SPI_InitStruct.SPI_Direction = SPI_Direction_1Line_Tx;  // ������
    SPI_InitStruct.SPI_Mode = SPI_Mode_Master;
    SPI_InitStruct.SPI_DataSize = SPI_DataSize_8b;
    SPI_InitStruct.SPI_CPOL = SPI_CPOL_High;
    SPI_InitStruct.SPI_CPHA = SPI_CPHA_2Edge;
    SPI_InitStruct.SPI_NSS = SPI_NSS_Soft;  // ��NSSģʽ
    SPI_InitStruct.SPI_BaudRatePrescaler = SPI_BaudRatePrescaler_8;  // �ʵ��Ĳ�����
    SPI_InitStruct.SPI_FirstBit = SPI_FirstBit_MSB;
    SPI_InitStruct.SPI_CRCPolynomial = 7;
    SPI_Init(SPI1, &SPI_InitStruct);

    // ����DMA
    DMA_InitStruct.DMA_PeripheralBaseAddr = (uint32_t)&SPI1->DR;  // SPI1���ݼĴ�����ַ
//    DMA_InitStruct.DMA_MemoryBaseAddr = (uint32_t)spi_tx_buffer;  // �������ݻ�������ַ
    DMA_InitStruct.DMA_DIR = DMA_DIR_PeripheralDST;  // ���ڴ浽���裨������ֻ��Ҫ�������ݣ�
    DMA_InitStruct.DMA_BufferSize = SPI_BUFFER_SIZE;  // ���ݴ�С
    DMA_InitStruct.DMA_PeripheralInc = DMA_PeripheralInc_Disable;  // �����ַ����
    DMA_InitStruct.DMA_MemoryInc = DMA_MemoryInc_Enable;  // �ڴ��ַ��
    DMA_InitStruct.DMA_PeripheralDataSize = DMA_PeripheralDataSize_Byte;  // �������ݴ�СΪ�ֽ�
    DMA_InitStruct.DMA_MemoryDataSize = DMA_MemoryDataSize_Byte;  // �ڴ����ݴ�СΪ�ֽ�
    DMA_InitStruct.DMA_Mode = DMA_Mode_Normal;  // ��ͨģʽ
    DMA_InitStruct.DMA_Priority = DMA_Priority_High;  // �����ȼ�
    DMA_InitStruct.DMA_M2M = DMA_M2M_Disable;  // ��֧���ڴ浽�ڴ�
    DMA_Init(DMA1_Channel3, &DMA_InitStruct);  // ����DMAͨ��

    DMA_ITConfig(DMA1_Channel3, DMA_IT_TC, ENABLE);

    NVIC_InitStruct.NVIC_IRQChannel = DMA1_Channel2_3_IRQn;  // ѡ��DMAͨ��3���ж�
    NVIC_InitStruct.NVIC_IRQChannelPriority = 2;  // �ж����ȼ�
    NVIC_InitStruct.NVIC_IRQChannelCmd = ENABLE;  // ʹ���ж�
    NVIC_Init(&NVIC_InitStruct);

    SPI_I2S_DMACmd(SPI1, SPI_I2S_DMAReq_Tx, ENABLE);
//    DMA_Cmd(DMA1_Channel3, ENABLE);
    SPI_Cmd(SPI1, ENABLE);
    WS2812FX_init(WS2812_NUM, NEO_GRB);
    WS2812FX_setBrightness(255);
    WS2812FX_setSpeed(1000);
    WS2812FX_setColor(0x00000000);

    WS2812FX_start();
    memset(spi_tx_buffer, WS2812_SEt_0H, SPI_BUFFER_SIZE - 50);
    memset(spi_tx_buffer + SPI_BUFFER_SIZE - 50, 0, 50);
}

void ws2812_spi1_send_data(uint8_t *data, uint16_t size)
{
//    if (1 == spi_transfer_complete) {
//        spi_transfer_complete = 0;

        if (size > SPI_BUFFER_SIZE) {
            // ���ݴ�С����������
            return;
        }
        // ����DMA������ڴ��ַ�ʹ�С
        DMA1_Channel3->CMAR = (uint32_t) data;  // �����ڴ��ַΪ�������ݵĵ�ַ
        DMA1_Channel3->CNDTR = size;

        // ����DMA����
        DMA_Cmd(DMA1_Channel3, ENABLE);
//    }
}



void spi1_send_data1()
{

//    if (1 == spi_transfer_complete) {
//        spi_transfer_complete = 0;

//        // ����DMA���䳤��
//        DMA1_Channel3->CNDTR = SPI_BUFFER_SIZE;
//        DMA1_Channel3->CMAR = (uint32_t)spi_tx_buffer;
//        // ����DMA����
//        DMA_Cmd(DMA1_Channel3, ENABLE);
//    }

//    ws2812_spi1_send_data(spi_tx_buffer, SPI_BUFFER_SIZE);
//    if (index111 == 0) {
//        Adafruit_NeoPixel_fill(0xFFFFFF, 0, 55);
//        WS2812FX_mode_static();
//        Adafruit_NeoPixel_setBrightness(1);
//        Adafruit_NeoPixel_show();
//        index111++;
//    }
//    if (index111 == 10000) {
//        WS2812FX_setMode(FX_MODE_CHASE_FLASH_RANDOM);
//    }else if (index111 == 20000){
//        WS2812FX_setMode(FX_MODE_CHASE_BLACKOUT_RAINBOW);
//
//    }else if (index111 == 30000){
//        WS2812FX_setMode(FX_MODE_FIREWORKS_RANDOM);
//
//    }else if (index111 == 40000){
//        WS2812FX_setMode(FX_MODE_RAINBOW_CYCLE);
//    }else if (index111 == 50000){
//        WS2812FX_setMode(FX_MODE_COLOR_WIPE);
//    }else if (index111 == 60000){
//    }

//    ws2812_change_moder();


}







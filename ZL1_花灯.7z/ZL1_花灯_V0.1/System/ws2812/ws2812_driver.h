//
// Created by tutu on 2024/10/26.
//

#ifndef _WS2812_DRIVER_H
#define _WS2812_DRIVER_H
#include "stm32f0xx_conf.h"

#define WS2812_NUM  40
#define SPI_BUFFER_SIZE ((24 * WS2812_NUM)+50)
#define WS2812_SEt_1H 0xF8
#define WS2812_SEt_0H 0xC0


void ws2812_spi1_dma_init(void);
void ws2812_spi1_send_data(uint8_t *data, uint16_t size);
void spi1_send_data1();
#endif

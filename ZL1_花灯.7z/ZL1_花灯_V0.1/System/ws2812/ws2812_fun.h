
#ifndef _WS2812_FUN_H
#define _WS2812_FUN_H
void ws2812_change_moder();
void ws2812_console_choice_moder();
void set_flag_false();
void menu_fun_ptr_init(void);
#endif

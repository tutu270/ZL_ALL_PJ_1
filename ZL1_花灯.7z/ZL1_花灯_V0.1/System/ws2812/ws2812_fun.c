
#include <stdint.h>
#include <string.h>
#include "ws2812_fun.h"
#include "ws2812fx.h"
#include "menu/menu.h"
#include "adafruit_neopixel.h"
#include "usartx/dmx.h"
#include "sys_config.h"
#include "Dri_Motor.h"

bool flag = false;

void set_flag_false()
{
    flag = false;
}

uint8_t index1111 = 0;

void ws2812_change_moder()
{
    static char this_num = -1;
    extern Menu_With_Numbers *ptr;
//    extern  Segment_runtime* _seg_rt;           // currently active segment runtime (16 bytes)
//    extern volatile uint32_t g_tickCount;  // ���ڴ洢ϵͳ����ʱ�䣨���룩
    extern Segment_runtime *_segment_runtimes;

    if (ptr == &A1xx || ptr == &A2xx || ptr == &A3xx || ptr == &A4xx || ptr == &A5xx ||
        ptr == &A6xx || ptr == &A7xx || ptr == &A8xx || ptr == &A9xx || ptr == &AAxx || ptr == &ABxx ||
        ptr == &ACxx || ptr == &ADxx || ptr == &AExx || ptr == &AFxx) {

        if ((_segment_runtimes->counter_mode_call) > 500) {
            flag = !flag;
        }

        if (ptr == &A1xx) {
            index1111 = 2;
        } else if (ptr == &A2xx) {
            index1111 = 3;
        } else if (ptr == &A3xx) {
            index1111 = 4;
        } else if (ptr == &A4xx) {
            index1111 = 5;
        } else if (ptr == &A5xx) {
            index1111 = 6;
        } else if (ptr == &A6xx) {
            index1111 = 7;
        } else if (ptr == &A7xx) {
            index1111 = 8;
        } else if (ptr == &A8xx) {
            index1111 = 9;
        } else if (ptr == &A9xx) {
            index1111 = 10;
        } else if (ptr == &AAxx) {
            index1111 = 11;
        } else if (ptr == &ABxx) {
            index1111 = 12;
        } else if (ptr == &ACxx) {
            index1111 = 13;
        } else if (ptr == &ADxx) {
            index1111 = 14;
        } else if (ptr == &AExx) {
            index1111 = 15;
        } else if (ptr == &AFxx) {
            index1111 = 16;
        }
//    if (_segment_runtimes->counter_mode_call % 500 == 0) {
//        flag = !flag;
//    }

//    extern uint16_t _rand16seed;
//    _rand16seed = 0;
//    memset(_segment_runtimes, 0, 16 );
//    Adafruit_NeoPixel_clear();
//    g_tickCount = 1000;
//    _seg_rt->next_time = 0;

        WS2812FX_setSpeed(300 * (11 - ptr->number));
        WS2812FX_setColor(0xFFFFFF);
    }
    else if (ptr == &S1xx) {

        if (mode_use.mic_time > 0) {
            WS2812FX_setSpeed(300);
            WS2812FX_setColor(0xFFFFFF);
            index1111 = 15;
        } else {
            index1111 = 0;
        }

        if ((_segment_runtimes->counter_mode_call) > 500) {
            flag = !flag;
        }

    }
    else if (ptr == &S2xx) {

        if (mode_use.mic_time > 0) {
            WS2812FX_setSpeed(300);
            WS2812FX_setColor(0xFFFFFF);
            index1111 = 16;
        } else {
            index1111 = 0;
        }

        if ((_segment_runtimes->counter_mode_call) > 500) {
            flag = !flag;
        }

    }
    else if ((DMX_CONNECT_State == DMX_CONNECT_OK) && ((DMX_RxBuf[27] != 0 && Cxxx.number == SYS_CONSOLE_DIFF_CH) ||
                                                  (DMX_RxBuf[17] != 0 && Cxxx.number == SYS_CONSOLE_EASE_CH)) && DMX_RxBuf[0] == CONSOLE_FRAME_HEADER) {
        if ((_segment_runtimes->counter_mode_call) > 500) {
            flag = !flag;
        }

        uint8_t index = 0;
        if (Cxxx.number == SYS_CONSOLE_DIFF_CH) {
            index = console_data.console_ch_diff_ch27_mode;
        } else if (Cxxx.number == SYS_CONSOLE_EASE_CH) {
            index = console_data.console_ch_ease_ch17_mode;

        }
        if (index <= 14) {
//            WS2812FX_setSpeed(300 * (11 - SPxx_b.number));
            if (Cxxx.number == SYS_CONSOLE_DIFF_CH) {
                WS2812FX_setSpeed(300 * (11 - console_data.console_ch_diff_all_speed));
                index = console_data.console_ch_diff_ch27_mode;
            } else if (Cxxx.number == SYS_CONSOLE_EASE_CH) {
                WS2812FX_setSpeed(300 * (11 - console_data.console_ch_ease_all_speed));
                index = console_data.console_ch_ease_ch17_mode;

            }

            WS2812FX_setColor(0xFFFFFF);
            index1111 = index + 2;
        } else if (index == 15) {
            if (mode_use.mic_time > 0) {
//                WS2812FX_setSpeed(300 * (11 - SPxx_b.number));
                if (Cxxx.number == SYS_CONSOLE_DIFF_CH) {
                    WS2812FX_setSpeed(300 * (11 - console_data.console_ch_diff_all_speed));
                } else if (Cxxx.number == SYS_CONSOLE_EASE_CH) {
                    WS2812FX_setSpeed(300 * (11 - console_data.console_ch_ease_all_speed));
                }
                WS2812FX_setColor(0xFFFFFF);
                index1111 = 15;
            } else {
                index1111 = 0;
            }


        } else if (index == 16) {
            if (mode_use.mic_time > 0) {
//                WS2812FX_setSpeed(300 * (11 - SPxx_b.number));
                if (Cxxx.number == SYS_CONSOLE_DIFF_CH) {
                    WS2812FX_setSpeed(300 * (11 - console_data.console_ch_diff_all_speed));
                } else if (Cxxx.number == SYS_CONSOLE_EASE_CH) {
                    WS2812FX_setSpeed(300 * (11 - console_data.console_ch_ease_all_speed));
                }
                WS2812FX_setColor(0xFFFFFF);
                index1111 = 16;
            } else {
                index1111 = 0;
            }


        }

    } else {
        index1111 = 0;
    }
    if (index1111 == 2) {
        fun_set_run_mode(&mode_use, 2, 4500);
        if (flag)WS2812FX_setMode_Ref(FX_MODE_SCAN);
        else if (!flag)WS2812FX_setMode_Ref(FX_MODE_RAINBOW_CYCLE);

    } else if (index1111 == 3) {
        fun_set_run_mode(&mode_use, 3, 4000);
        if (flag) WS2812FX_setMode_Ref(FX_MODE_RAINBOW_CYCLE);
        else if (!flag)WS2812FX_setMode_Ref(FX_MODE_COLOR_WIPE);
    } else if (index1111 == 4) {
        fun_set_run_mode(&mode_use, 4, 4000);
        if (flag) WS2812FX_setMode_Ref(FX_MODE_COLOR_WIPE);
        else if (!flag)WS2812FX_setMode_Ref(FX_MODE_THEATER_CHASE);

    } else if (index1111 == 5) {
        fun_set_run_mode(&mode_use, 5, 4000);

        if (flag) WS2812FX_setMode_Ref(FX_MODE_THEATER_CHASE);
        else if (!flag)WS2812FX_setMode_Ref(FX_MODE_RAINBOW);

    } else if (index1111 == 6) {
        fun_set_run_mode(&mode_use, 6, 4500);


        if (flag) WS2812FX_setMode_Ref(FX_MODE_RAINBOW);
        else if (!flag)WS2812FX_setMode_Ref(FX_MODE_TWINKLE_RANDOM);

    } else if (index1111 == 7) {
        fun_set_run_mode(&mode_use, 7, 4500);

        if (flag) WS2812FX_setMode_Ref(FX_MODE_TWINKLE_RANDOM);
        else if (!flag) WS2812FX_setMode_Ref(FX_MODE_COLOR_SWEEP_RANDOM);

    } else if (index1111 == 8) {
        fun_set_run_mode(&mode_use, 8, 4500);

        if (flag) WS2812FX_setMode_Ref(FX_MODE_COLOR_SWEEP_RANDOM);
        else if (!flag)WS2812FX_setMode_Ref(FX_MODE_COLOR_WIPE_INV);
    } else if (index1111 == 9) {
        fun_set_run_mode(&mode_use, 9, 4500);

        if (flag) WS2812FX_setMode_Ref(FX_MODE_COLOR_WIPE_INV);
        else if (!flag)WS2812FX_setMode_Ref(FX_MODE_CHASE_RAINBOW);

    } else if (index1111 == 10) {
        fun_set_run_mode(&mode_use, 10, 4500);

        if (flag) WS2812FX_setMode_Ref(FX_MODE_CHASE_RAINBOW);
        else if (!flag)WS2812FX_setMode_Ref(FX_MODE_CHASE_RAINBOW_WHITE);

    } else if (index1111 == 11) {
        fun_set_run_mode(&mode_use, 11, 4500);

        if (flag) WS2812FX_setMode_Ref(FX_MODE_CHASE_RAINBOW_WHITE);
        else if (!flag)WS2812FX_setMode_Ref(FX_MODE_CHASE_BLACKOUT);

    } else if (index1111 == 12) {
        fun_set_run_mode(&mode_use, 12, 6500);

        if (flag) WS2812FX_setMode_Ref(FX_MODE_CHASE_BLACKOUT);
        else if (!flag)WS2812FX_setMode_Ref(FX_MODE_CHASE_BLACKOUT_RAINBOW);

    } else if (index1111 == 13) {
        fun_set_run_mode(&mode_use, 13, 6500);
        if (flag) WS2812FX_setMode_Ref(FX_MODE_CHASE_BLACKOUT_RAINBOW);
        else if (!flag)WS2812FX_setMode_Ref(FX_MODE_CHASE_FLASH_RANDOM);

    } else if (index1111 == 14) {
        fun_set_run_mode(&mode_use, 14, 10000);

        if (flag) WS2812FX_setMode_Ref(FX_MODE_CHASE_FLASH_RANDOM);
        else if (!flag)WS2812FX_setMode_Ref(FX_MODE_CHASE_RANDOM);

    } else if (index1111 == 15) {
        fun_set_run_mode(&mode_use, 15, 6500);

        if (flag) WS2812FX_setMode_Ref(FX_MODE_CHASE_RANDOM);
        else if (!flag)WS2812FX_setMode_Ref(FX_MODE_COMET);

    } else if (index1111 == 16) {
        fun_set_run_mode(&mode_use, 16, 10000);
        if (flag) WS2812FX_setMode_Ref(FX_MODE_HALLOWEEN);
        else if (!flag)WS2812FX_setMode_Ref(FX_MODE_SCAN);
    }

}

void ws2812_console_choice_moder()
{
    if (((Cxxx.number == SYS_CONSOLE_DIFF_CH &&DMX_RxBuf[27] == 0 && DMX_RxBuf[25] != 0) ||
            (Cxxx.number == SYS_CONSOLE_EASE_CH &&DMX_RxBuf[17] == 0 && DMX_RxBuf[15] != 0) && DMX_RxBuf[0] == CONSOLE_FRAME_HEADER)
            && (DMX_CONNECT_State == DMX_CONNECT_OK) && DMX_RxBuf[0] == CONSOLE_FRAME_HEADER
        ) {

        uint8_t index;
        if (Cxxx.number == SYS_CONSOLE_EASE_CH) {
            index = console_data.console_ch_ease_ch15_mode;
            WS2812FX_setSpeed(300 * (11 - (console_data.console_ch_ease_ch16_mode)));
        }
        else if (Cxxx.number == SYS_CONSOLE_DIFF_CH){
            index = console_data.console_ch_diff_ch25_mode;
            WS2812FX_setSpeed(300 * (11 - (console_data.console_ch_diff_ch26_mode)));
        }
//        WS2812FX_setColor(0xFFFFFF);
        WS2812FX_setColor(0xFFFFFF);


        if (DMX_RxBuf[1] == 0) {
            fun_set_run_mode(&mode_use, 99, 4500);
        }

        switch (index) {
            case 0:
                WS2812FX_setMode_Ref(FX_MODE_SCAN);
                break;
            case 1:
                WS2812FX_setMode_Ref(FX_MODE_RAINBOW_CYCLE);
                break;
            case 2:
                WS2812FX_setMode_Ref(FX_MODE_COLOR_WIPE);
                break;
            case 3:
                WS2812FX_setMode_Ref(FX_MODE_THEATER_CHASE);
                break;
            case 4:
                WS2812FX_setMode_Ref(FX_MODE_RAINBOW);
                break;
            case 5:
                WS2812FX_setMode_Ref(FX_MODE_TWINKLE_RANDOM);
                break;
            case 6:
                WS2812FX_setMode_Ref(FX_MODE_COLOR_SWEEP_RANDOM);
                break;
            case 7:
                WS2812FX_setMode_Ref(FX_MODE_COLOR_WIPE_INV);
                break;
            case 8:
                WS2812FX_setMode_Ref(FX_MODE_CHASE_RAINBOW);
                break;
            case 9:
                WS2812FX_setMode_Ref(FX_MODE_CHASE_RAINBOW_WHITE);
                break;
            case 10:
                WS2812FX_setMode_Ref(FX_MODE_CHASE_BLACKOUT);
                break;
            case 11:
                WS2812FX_setMode_Ref(FX_MODE_CHASE_BLACKOUT_RAINBOW);
                break;
            case 12:
                WS2812FX_setMode_Ref(FX_MODE_CHASE_FLASH_RANDOM);
                break;
            case 13:
                WS2812FX_setMode_Ref(FX_MODE_CHASE_RANDOM);
                break;
            case 14:
                WS2812FX_setMode_Ref(FX_MODE_COMET);
                break;
            case 15:
                WS2812FX_setMode_Ref(FX_MODE_HALLOWEEN);
                break;
            default:
                break;
        }
    }


}
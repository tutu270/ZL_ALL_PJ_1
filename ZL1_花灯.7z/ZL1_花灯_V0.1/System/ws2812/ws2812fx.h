#ifndef __WS2812FX_H
#define __WS2812FX_H
#define WS2812FX_VERSION 0x00000001

/*
  ��ֲ�ÿ���Ҫ��������ֲ��Adafruit_NeoPixel��Ļ�������ʵ��
  1.keil MDK��������֧�ֶ����Ʊ�ʾ�����ÿ��õ��˶����Ʊ�ʾ����Ҫ�õ�binary.h�ļ�
  2.Ϊ�˼��ٿ��ļ��������ݵ��޸ģ�������һЩ������ֲ�ĺꡣ
  3.��ǰ�汾��ֲ��æδ��ȫ����
  4.�ÿ���Ҫʵ�ֻ�ȡϵͳ����ʱ��ĺ���������ֱ��������HAL���ṩ��HAL_GetTick������
 */

#include <stdint.h>
#include <stdbool.h>
#include "stm32f0xx.h"
#include "binary.h"
#include "Main.h"
#include "fun.h"
/* Ϊ������ֲ����ĺ� */
typedef char __FlashStringHelper;
#define millis mode_use.ws2812_run_time
//#define millis 1
#define PROGMEM
#define min(a,b) ((a)<(b)?(a):(b))
#define max(a,b) ((a)>(b)?(a):(b))
#define constrain(amt,low,high) ((amt)<=(low)?(low):((amt)>=(high)?(high):(amt)))
typedef bool boolean;
#define FSH(x) (__FlashStringHelper*)(x)

//#include <Adafruit_NeoPixel.h>

#define DEFAULT_BRIGHTNESS (uint8_t)50
#define DEFAULT_MODE       (uint8_t)0
#define DEFAULT_SPEED      (uint16_t)1000
#define DEFAULT_COLOR      (uint32_t)0xFF0000
#define DEFAULT_COLORS     { RED, GREEN, BLUE }
#define COLORS(...)        (const uint32_t[]){__VA_ARGS__}

#if defined(ESP8266) || defined(ESP32)
//#pragma message("Compiling for ESP")
  #define SPEED_MIN (uint16_t)2
#else
//#pragma message("Compiling for Arduino")
#define SPEED_MIN (uint16_t)10
#endif
#define SPEED_MAX (uint16_t)65535

#define BRIGHTNESS_MIN (uint8_t)0
#define BRIGHTNESS_MAX (uint8_t)255

/* each segment uses 36 bytes of SRAM memory, so if you're compile fails
  because of insufficient flash memory, decreasing MAX_NUM_SEGMENTS may help */
#define MAX_NUM_SEGMENTS         1
#define MAX_NUM_ACTIVE_SEGMENTS  1
#define INACTIVE_SEGMENT        255 /* max uint_8 */
#define MAX_NUM_COLORS            3 /* number of colors per segment */
#define MAX_CUSTOM_MODES          8

// some common colors
#define RED        (uint32_t)0xFF0000
#define GREEN      (uint32_t)0x00FF00
#define BLUE       (uint32_t)0x0000FF
#define WHITE      (uint32_t)0xFFFFFF
#define BLACK      (uint32_t)0x000000
#define YELLOW     (uint32_t)0xFFFF00
#define CYAN       (uint32_t)0x00FFFF
#define MAGENTA    (uint32_t)0xFF00FF
#define PURPLE     (uint32_t)0x400080
#define ORANGE     (uint32_t)0xFF3000
#define PINK       (uint32_t)0xFF1493
#define GRAY       (uint32_t)0x101010
#define ULTRAWHITE (uint32_t)0xFFFFFFFF
#define DIM(c)     (uint32_t)((c >> 2) & 0x3f3f3f3f) // color at 25% intensity
#define DARK(c)    (uint32_t)((c >> 4) & 0x0f0f0f0f) // color at  6% intensity


// segment options
// bit    7: reverse animation
// bits 4-6: fade rate (0-7)
// bit    3: gamma correction
// bits 1-2: size
// bits   0: TBD
#define NO_OPTIONS   (uint8_t)B00000000
#define REVERSE      (uint8_t)B10000000
#define IS_REVERSE   ((_seg->options & REVERSE) == REVERSE)
#define FADE_XFAST   (uint8_t)B00010000
#define FADE_FAST    (uint8_t)B00100000
#define FADE_MEDIUM  (uint8_t)B00110000
#define FADE_SLOW    (uint8_t)B01000000
#define FADE_XSLOW   (uint8_t)B01010000
#define FADE_XXSLOW  (uint8_t)B01100000
#define FADE_GLACIAL (uint8_t)B01110000
#define FADE_RATE    ((_seg->options >> 4) & 7)
#define GAMMA        (uint8_t)B00001000
#define IS_GAMMA     ((_seg->options & GAMMA) == GAMMA)
#define SIZE_SMALL   (uint8_t)B00000000
#define SIZE_MEDIUM  (uint8_t)B00000010
#define SIZE_LARGE   (uint8_t)B00000100
#define SIZE_XLARGE  (uint8_t)B00000110
#define SIZE_OPTION  ((_seg->options >> 1) & 3)

// segment runtime options (aux_param2)
#define FRAME           ((uint8_t)B10000000)
#define SET_FRAME       (_seg_rt->aux_param2 |=  FRAME)
#define CLR_FRAME       (_seg_rt->aux_param2 &= ~FRAME)
#define CYCLE           ((uint8_t)B01000000)
#define SET_CYCLE       (_seg_rt->aux_param2 |=  CYCLE)
#define CLR_CYCLE       (_seg_rt->aux_param2 &= ~CYCLE)
#define CLR_FRAME_CYCLE (_seg_rt->aux_param2 &= ~(FRAME | CYCLE))

#define MODE_COUNT 63 //(sizeof(_names)/sizeof(_names[0]))

#define FX_MODE_STATIC                   0
#define FX_MODE_BLINK                    1
#define FX_MODE_BREATH                   2
#define FX_MODE_COLOR_WIPE               3
#define FX_MODE_COLOR_WIPE_INV           4
#define FX_MODE_COLOR_WIPE_REV           5
#define FX_MODE_COLOR_WIPE_REV_INV       6
#define FX_MODE_COLOR_WIPE_RANDOM        7
#define FX_MODE_RANDOM_COLOR             8
#define FX_MODE_SINGLE_DYNAMIC           9
#define FX_MODE_MULTI_DYNAMIC           10
#define FX_MODE_RAINBOW                 11
#define FX_MODE_RAINBOW_CYCLE           12
#define FX_MODE_SCAN                    13
#define FX_MODE_DUAL_SCAN               14
#define FX_MODE_FADE                    15
#define FX_MODE_THEATER_CHASE           16
#define FX_MODE_THEATER_CHASE_RAINBOW   17
#define FX_MODE_RUNNING_LIGHTS          18
#define FX_MODE_TWINKLE                 19
#define FX_MODE_TWINKLE_RANDOM          20
#define FX_MODE_TWINKLE_FADE            21
#define FX_MODE_TWINKLE_FADE_RANDOM     22
#define FX_MODE_SPARKLE                 23
#define FX_MODE_FLASH_SPARKLE           24
#define FX_MODE_HYPER_SPARKLE           25
#define FX_MODE_STROBE                  26
#define FX_MODE_STROBE_RAINBOW          27
#define FX_MODE_MULTI_STROBE            28
#define FX_MODE_BLINK_RAINBOW           29
#define FX_MODE_CHASE_WHITE             30
#define FX_MODE_CHASE_COLOR             31
#define FX_MODE_CHASE_RANDOM            32
#define FX_MODE_CHASE_RAINBOW           33
#define FX_MODE_CHASE_FLASH             34
#define FX_MODE_CHASE_FLASH_RANDOM      35
#define FX_MODE_CHASE_RAINBOW_WHITE     36
#define FX_MODE_CHASE_BLACKOUT          37
#define FX_MODE_CHASE_BLACKOUT_RAINBOW  38
#define FX_MODE_COLOR_SWEEP_RANDOM      39
#define FX_MODE_RUNNING_COLOR           40
#define FX_MODE_RUNNING_RED_BLUE        41
#define FX_MODE_RUNNING_RANDOM          42
#define FX_MODE_LARSON_SCANNER          43
#define FX_MODE_COMET                   44
#define FX_MODE_FIREWORKS               45
#define FX_MODE_FIREWORKS_RANDOM        46
#define FX_MODE_MERRY_CHRISTMAS         47
#define FX_MODE_FIRE_FLICKER            48
#define FX_MODE_FIRE_FLICKER_SOFT       49
#define FX_MODE_FIRE_FLICKER_INTENSE    50
#define FX_MODE_CIRCUS_COMBUSTUS        51
#define FX_MODE_HALLOWEEN               52
#define FX_MODE_BICOLOR_CHASE           53
#define FX_MODE_TRICOLOR_CHASE          54
#define FX_MODE_CUSTOM                  55  // keep this for backward compatiblity
#define FX_MODE_CUSTOM_0                55  // custom modes need to go at the end
#define FX_MODE_CUSTOM_1                56
#define FX_MODE_CUSTOM_2                57
#define FX_MODE_CUSTOM_3                58
#define FX_MODE_CUSTOM_4                59
#define FX_MODE_CUSTOM_5                60
#define FX_MODE_CUSTOM_6                61
#define FX_MODE_CUSTOM_7                62


typedef uint16_t (*mode_ptr)(void);

// segment parameters
typedef struct Segment { // 20 bytes
    uint16_t start;
    uint16_t stop;
    uint16_t speed;
    uint8_t  mode;
    uint8_t  options;
    uint32_t colors[MAX_NUM_COLORS];
} Segment;

// segment runtime parameters
typedef struct Segment_runtime { // 16 bytes
    unsigned long next_time;
    uint32_t counter_mode_step;
    uint32_t counter_mode_call;
    uint8_t aux_param;   // auxilary param (usually stores a color_wheel index)
    uint8_t aux_param2;  // auxilary param (usually stores bitwise options)
    uint16_t aux_param3; // auxilary param (usually stores a segment index)
} Segment_runtime;


void
//    timer(void),
WS2812FX_init(uint16_t num_leds, uint8_t type),
        WS2812FX_service(void),
        WS2812FX_start(void),
        WS2812FX_stop(void),
        WS2812FX_pause(void),
        WS2812FX_resume(void),
        WS2812FX_strip_off(void),
        WS2812FX_fade_out(void),
        WS2812FX_fade_out_targetColor(uint32_t),
        WS2812FX_setMode(uint8_t m),
        WS2812FX_setMode_Ref(uint8_t m),
        WS2812FX_setMode_seg(uint8_t seg, uint8_t m),
        WS2812FX_setOptions(uint8_t seg, uint8_t o),
        WS2812FX_setCustomMode(uint16_t (*p)()),
        WS2812FX_setCustomShow(void (*p)()),
        WS2812FX_setSpeed(uint16_t s),
        WS2812FX_setSpeed_seg(uint8_t seg, uint16_t s),
        WS2812FX_increaseSpeed(uint8_t s),
        WS2812FX_decreaseSpeed(uint8_t s),
        WS2812FX_setColor_rgb(uint8_t r, uint8_t g, uint8_t b),
        WS2812FX_setColor_rgbw(uint8_t r, uint8_t g, uint8_t b, uint8_t w),
        WS2812FX_setColor(uint32_t c),
        WS2812FX_setColor_seg(uint8_t seg, uint32_t c),
        WS2812FX_setColors(uint8_t seg, uint32_t* c),
        WS2812FX_setBrightness(uint8_t b),
        WS2812FX_increaseBrightness(uint8_t s),
        WS2812FX_decreaseBrightness(uint8_t s),
        WS2812FX_setLength(uint16_t b),
        WS2812FX_increaseLength(uint16_t s),
        WS2812FX_decreaseLength(uint16_t s),
        WS2812FX_trigger(void),
        WS2812FX_setCycle(void),
        WS2812FX_setNumSegments(uint8_t n),
        WS2812FX_setSegment_colorReverse(uint8_t n, uint16_t start, uint16_t stop, uint8_t mode, uint32_t color,          uint16_t speed, bool reverse),
        WS2812FX_setSegment_colorOptions(uint8_t n, uint16_t start, uint16_t stop, uint8_t mode, uint32_t color,          uint16_t speed, uint8_t options),
        WS2812FX_setSegment_colorsReverse(uint8_t n, uint16_t start, uint16_t stop, uint8_t mode, uint32_t colors[], uint16_t speed, bool reverse),
        WS2812FX_setSegment_colorsOptions(uint8_t n, uint16_t start, uint16_t stop, uint8_t mode, uint32_t colors[], uint16_t speed, uint8_t options),
        WS2812FX_setIdleSegment(uint8_t n, uint16_t start, uint16_t stop, uint8_t mode, uint32_t color,          uint16_t speed, uint8_t options),
        WS2812FX_setIdleSegment_colors(uint8_t n, uint16_t start, uint16_t stop, uint8_t mode, uint32_t colors[], uint16_t speed, uint8_t options),
        WS2812FX_addActiveSegment(uint8_t seg),
        WS2812FX_removeActiveSegment(uint8_t seg),
        WS2812FX_swapActiveSegment(uint8_t oldSeg, uint8_t newSeg),
        WS2812FX_resetSegments(void),
        WS2812FX_resetSegmentRuntimes(void),
        WS2812FX_resetSegmentRuntime(uint8_t),
        WS2812FX_setPixelColor(uint16_t n, uint32_t c),
        WS2812FX_setPixelColor_rgb(uint16_t n, uint8_t r, uint8_t g, uint8_t b),
        WS2812FX_setPixelColor_rgbw(uint16_t n, uint8_t r, uint8_t g, uint8_t b, uint8_t w),
        WS2812FX_copyPixels(uint16_t d, uint16_t s, uint16_t c),
        WS2812FX_setPixels(uint16_t, uint8_t*),
        WS2812FX_show(void);

boolean
        WS2812FX_isRunning(void),
        WS2812FX_isTriggered(void),
        WS2812FX_isFrame(void),
        WS2812FX_isFrame_seg(uint8_t),
        WS2812FX_isCycle(void),
        WS2812FX_isCycle_seg(uint8_t),
        WS2812FX_isActiveSegment(uint8_t seg);

uint8_t
        WS2812FX_random8(void),
        WS2812FX_random8_lim(uint8_t),
        WS2812FX_getMode(void),
        WS2812FX_getMode_seg(uint8_t),
        WS2812FX_getModeCount(void),
//      WS2812FX_setCustomMode(const __FlashStringHelper* name, uint16_t (*p)()),
//      WS2812FX_setCustomMode(uint8_t i, const __FlashStringHelper* name, uint16_t (*p)()),
WS2812FX_getNumSegments(void),
        WS2812FX_get_random_wheel_index(uint8_t),
        WS2812FX_getOptions(uint8_t),
        WS2812FX_getNumBytesPerPixel(void);

uint16_t
        WS2812FX_random16(void),
        WS2812FX_random16_lim(uint16_t),
        WS2812FX_getSpeed(void),
        WS2812FX_getSpeed_seg(uint8_t),
        WS2812FX_getLength(void),
        WS2812FX_getNumBytes(void);

uint32_t
        WS2812FX_color_wheel(uint8_t),
        WS2812FX_getColor(void),
        WS2812FX_getColor_seg(uint8_t),
        WS2812FX_intensitySum(void);

uint32_t* getColors(uint8_t);
uint32_t* intensitySums(void);
uint8_t*  getActiveSegments(void);

const __FlashStringHelper* getModeName(uint8_t m);

Segment* getSegment(void);

Segment* getSegment_seg(uint8_t);

Segment* getSegments(void);

Segment_runtime* getSegmentRuntime(void);

Segment_runtime* getSegmentRuntime_seg(uint8_t);

Segment_runtime* getSegmentRuntimes(void);

// mode helper functions
uint16_t
        WS2812FX_blink(uint32_t, uint32_t, bool strobe),
        WS2812FX_color_wipe(uint32_t, uint32_t, bool),
        WS2812FX_twinkle(uint32_t, uint32_t),
        WS2812FX_twinkle_fade(uint32_t),
        WS2812FX_sparkle(uint32_t, uint32_t),
        WS2812FX_chase(uint32_t, uint32_t, uint32_t),
        WS2812FX_chase_flash(uint32_t, uint32_t),
        WS2812FX_running(uint32_t, uint32_t),
        WS2812FX_fireworks(uint32_t),
        WS2812FX_fire_flicker(int),
        WS2812FX_tricolor_chase(uint32_t, uint32_t, uint32_t),
        WS2812FX_scan(uint32_t, uint32_t, bool);

uint32_t
WS2812FX_color_blend(uint32_t, uint32_t, uint8_t);


// builtin modes
uint16_t
        WS2812FX_mode_static(void),
        WS2812FX_mode_blink(void),
        WS2812FX_mode_blink_rainbow(void),
        WS2812FX_mode_strobe(void),
        WS2812FX_mode_strobe_rainbow(void),
        WS2812FX_mode_color_wipe(void),
        WS2812FX_mode_color_wipe_inv(void),
        WS2812FX_mode_color_wipe_rev(void),
        WS2812FX_mode_color_wipe_rev_inv(void),
        WS2812FX_mode_color_wipe_random(void),
        WS2812FX_mode_color_sweep_random(void),
        WS2812FX_mode_random_color(void),
        WS2812FX_mode_single_dynamic(void),
        WS2812FX_mode_multi_dynamic(void),
        WS2812FX_mode_breath(void),
        WS2812FX_mode_fade(void),
        WS2812FX_mode_scan(void),
        WS2812FX_mode_dual_scan(void),
        WS2812FX_mode_theater_chase(void),
        WS2812FX_mode_theater_chase_rainbow(void),
        WS2812FX_mode_rainbow(void),
        WS2812FX_mode_rainbow_cycle(void),
        WS2812FX_mode_running_lights(void),
        WS2812FX_mode_twinkle(void),
        WS2812FX_mode_twinkle_random(void),
        WS2812FX_mode_twinkle_fade(void),
        WS2812FX_mode_twinkle_fade_random(void),
        WS2812FX_mode_sparkle(void),
        WS2812FX_mode_flash_sparkle(void),
        WS2812FX_mode_hyper_sparkle(void),
        WS2812FX_mode_multi_strobe(void),
        WS2812FX_mode_chase_white(void),
        WS2812FX_mode_chase_color(void),
        WS2812FX_mode_chase_random(void),
        WS2812FX_mode_chase_rainbow(void),
        WS2812FX_mode_chase_flash(void),
        WS2812FX_mode_chase_flash_random(void),
        WS2812FX_mode_chase_rainbow_white(void),
        WS2812FX_mode_chase_blackout(void),
        WS2812FX_mode_chase_blackout_rainbow(void),
        WS2812FX_mode_running_color(void),
        WS2812FX_mode_running_red_blue(void),
        WS2812FX_mode_running_random(void),
        WS2812FX_mode_larson_scanner(void),
        WS2812FX_mode_comet(void),
        WS2812FX_mode_fireworks(void),
        WS2812FX_mode_fireworks_random(void),
        WS2812FX_mode_merry_christmas(void),
        WS2812FX_mode_halloween(void),
        WS2812FX_mode_fire_flicker(void),
        WS2812FX_mode_fire_flicker_soft(void),
        WS2812FX_mode_fire_flicker_intense(void),
        WS2812FX_mode_circus_combustus(void),
        WS2812FX_mode_bicolor_chase(void),
        WS2812FX_mode_tricolor_chase(void),
        WS2812FX_mode_custom_0(void),
        WS2812FX_mode_custom_1(void),
        WS2812FX_mode_custom_2(void),
        WS2812FX_mode_custom_3(void),
        WS2812FX_mode_custom_4(void),
        WS2812FX_mode_custom_5(void),
        WS2812FX_mode_custom_6(void),
        WS2812FX_mode_custom_7(void);

#endif /* __BSP_WS2812FX_H */



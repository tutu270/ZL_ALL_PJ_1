#ifndef _DIGITAL_TUBE_DRIVER_H
#define _DIGITAL_TUBE_DRIVER_H

/************* ����� ****************
 *            --------              *
 *               A                  *
 *            --------              *
 *            --    --              *
 *            F     B               *
 *            --    --              *
 *            --------              *
 *               G                  *
 *            --------              *
 *            --    --              *
 *            E     C               *
 *            --    --              *
 *            --------              *
 *               D                  *
 *            --------  - P -       *
 ************************************/


#include <stdint.h>
#include <stdbool.h>

#define DISPLAY_BS 0 // ���������
#define DISPLAY_AS 1 // ���������
#define  DISPLAY_TYPE DISPLAY_AS    //  ��ǰ���������


#define  CHIP_74H1640  0U   // �����ʹ��74H1640оƬ����
#define  IO_CONTROL  1U     // �����ʹ������оƬIOֱ�ӿ���
#define  CHIP_AIP650_Or_TM1650 2U // �����ʹ��AIP650/TM1650оƬ����
#define  DIGITAL_TUBE_CONTROL_CHIP  CHIP_AIP650_Or_TM1650   // ��ǰ����ܿ���ģʽ


#if  DISPLAY_TYPE == DISPLAY_BS
#define segA    (uint8_t)0x7FU
#define segB    (uint8_t)0xBFU
#define segC    (uint8_t)0xDFU
#define segD    (uint8_t)0xEFU
#define segE    (uint8_t)0xF7U
#define segF    (uint8_t)0xFBU
#define segG    (uint8_t)0xFDU
#define segP    (uint8_t)0xFEU

#define NO_DATA    (uint8_t)0xFF
#define SHOW_NUM0    (uint8_t)(segA & segB & segC & segD & segE & segF )
#define SHOW_NUM1    (uint8_t)(segB & segC )
#define SHOW_NUM2    (uint8_t)(segA & segB & segG & segE &segD )
#define SHOW_NUM3    (uint8_t)(segA & segB & segG & segC & segD )
#define SHOW_NUM4    (uint8_t)(segF & segG & segB & segC )
#define SHOW_NUM5    (uint8_t)(segA & segF & segG & segC & segD )
#define SHOW_NUM6    (uint8_t)(segA & segF & segG & segC & segE & segD )
#define SHOW_NUM7    (uint8_t)(segA & segB & segC )
#define SHOW_NUM8    (uint8_t)(segA & segB & segC & segD & segE & segF & segG )
#define SHOW_NUM9    (uint8_t)(segA & segB & segC & segD & segF & segG )
#define SHOW_A          (uint8_t)(segA & segB & segC & segE & segF &segF &segG )
#define SHOW_B          (uint8_t)(segF & segG & segE & segC & segD  )
#define SHOW_C          (uint8_t)(segA & segF & segE & segD )
#define SHOW_D          (uint8_t)(segB & segC & segD & segE & segG )
#define SHOW_E          (uint8_t)(segA & segF & segG & segE & segD )
#define SHOW_F          (uint8_t)(segA & segE & segF & segG)
#define SHOW_G          (uint8_t)(segA & segF & segE & segD & segC)
#define SHOW_H          (uint8_t)(segF & segE & segG & segC &segB )
#define SHOW_I          (uint8_t)(segA & segB & segC & segD)
#define SHOW_J          (uint8_t)(segB & segC & segD )
#define SHOW_K          (uint8_t)(segA & segC & segE & segF & segG )
#define SHOW_L          (uint8_t)(segD & segE & segF)
#define SHOW_M          (uint8_t)(segE & segF & segA & segB &segC )
#define SHOW_N          (uint8_t)(segE & segG &segC )
#define SHOW_O          (uint8_t)(segE & segG & segC &segD )
#define SHOW_P          (uint8_t)(segA & segB & segE & segF & segG )
#define SHOW_Q          (uint8_t)(segA & segB &segC & segF & segG )
#define SHOW_R          (uint8_t)(segF & segG & segE & segF)
#define SHOW_S          (uint8_t)(segA & segG & segD & segF & segC)
#define SHOW_T          (uint8_t)(segF & segG & segE & segD )
#define SHOW_U          (uint8_t)(segF & segE &segD &segC &segB )
#define SHOW_V          (uint8_t)(segE &segD &segC)
#define SHOW_W          (uint8_t)(segB & segC & segD &segE &segF &segG )
#define SHOW_X          (uint8_t)(segC &segF &segG)
#define SHOW_Y          (uint8_t)(segB & segC & segD & segF &segG )
#define SHOW_Z          (uint8_t)(segB & segD & segE &segG )


#elif DISPLAY_TYPE == DISPLAY_AS
#if DIGITAL_TUBE_CONTROL_CHIP == CHIP_AIP650_Or_TM1650
#define segA    (uint8_t)~0xFEU
#define segB    (uint8_t)~0xFDU
#define segC    (uint8_t)~0xFBU
#define segD    (uint8_t)~0xF7U
#define segE    (uint8_t)~0xEFU
#define segF    (uint8_t)~0xDFU
#define segG    (uint8_t)~0xBFU
#define segP    (uint8_t)~0x7FU
#else
#define segA    (uint8_t)~0x7FU
#define segB    (uint8_t)~0xBFU
#define segC    (uint8_t)~0xDFU
#define segD    (uint8_t)~0xEFU
#define segE    (uint8_t)~0xF7U
#define segF    (uint8_t)~0xFBU
#define segG    (uint8_t)~0xFDU
#define segP    (uint8_t)~0xFEU
#endif

#define NO_DATA     (uint8_t)~0xFFU
#define SHOW_NUM0       (uint8_t)(segA | segB | segC | segD | segE | segF )
#define SHOW_NUM1       (uint8_t)(segB | segC )
#define SHOW_NUM2       (uint8_t)(segA | segB | segG | segE | segD )
#define SHOW_NUM3       (uint8_t)(segA | segB | segG | segC | segD )
#define SHOW_NUM4       (uint8_t)(segF | segG | segB | segC )
#define SHOW_NUM5       (uint8_t)(segA | segF | segG | segC | segD )
#define SHOW_NUM6       (uint8_t)(segA | segF | segG | segC | segE | segD )
#define SHOW_NUM7       (uint8_t)(segA | segB | segC )
#define SHOW_NUM8       (uint8_t)(segA | segB | segC | segD | segE | segF | segG )
#define SHOW_NUM9       (uint8_t)(segA | segB | segC | segD | segF | segG )
#define SHOW_A          (uint8_t)(segA | segB | segC | segE | segF | segF | segG )
#define SHOW_B          (uint8_t)(segF | segG | segE | segC | segD )
#define SHOW_C          (uint8_t)(segG | segE | segD )
#define SHOW_D          (uint8_t)(segB | segC | segD | segE | segG )
#define SHOW_E          (uint8_t)(segA | segF | segG | segE | segD |segB )
#define SHOW_F          (uint8_t)(segA | segE | segF | segG)
#define SHOW_G          (uint8_t)(segA | segF | segE | segD | segC )
#define SHOW_H          (uint8_t)(segF | segE | segG | segC  )
#define SHOW_I          (uint8_t)(segC )
#define SHOW_J          (uint8_t)(segB | segC | segD )
#define SHOW_K          (uint8_t)(segA | segC | segE | segF | segG )
#define SHOW_L          (uint8_t)(segD | segE | segF )
#define SHOW_M          (uint8_t)(segE | segF | segA | segB | segC )
#define SHOW_N          (uint8_t)(segE | segG | segC )
#define SHOW_O          (uint8_t)(segE | segG | segC | segD )
#define SHOW_P          (uint8_t)(segA | segB | segE | segF | segG )
#define SHOW_Q          (uint8_t)(segA | segB | segC | segF | segG )
#define SHOW_R          (uint8_t)(segG | segE )
#define SHOW_S          (uint8_t)(segA | segG | segD | segF | segC )
#define SHOW_T          (uint8_t)(segF | segG | segE | segD )
#define SHOW_U          (uint8_t)(segF | segE | segD | segC | segB )
#define SHOW_V          (uint8_t)(segE | segD | segC )
#define SHOW_W          (uint8_t)(segB | segC | segD | segE | segF | segG )
#define SHOW_X          (uint8_t)(segC | segF | segG )
#define SHOW_Y          (uint8_t)(segB | segC | segD | segF | segG )
#define SHOW_Z          (uint8_t)(segB | segD | segE | segG )
#endif








enum SegmentationType {
    WITH_SEG_P ,
    ONLY_SEG_P,
    NO_SEG_P  ,
};


void DisplayCharForISR(const char *data,uint8_t bit1cycle, uint8_t bit2cycle, uint8_t bit3cycle, uint8_t bit4cycle,enum SegmentationType seg_mode);
void DisplayChar(const char *data,uint8_t bit1cycle, uint8_t bit2cycle, uint8_t bit3cycle, uint8_t bit4cycle,bool is_open);


#endif

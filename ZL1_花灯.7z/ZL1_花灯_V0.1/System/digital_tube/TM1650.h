#ifndef _AIP650_H
#define _AIP650_H


#include <stdint.h>
#include "stm32f0xx_conf.h"
#define	brighting_8			0x00
#define	brighting_7			0x07
#define	brighting_6			0x06
#define	brighting_5			0x05
#define	brighting_4			0x04
#define	brighting_3			0x03
#define	brighting_2			0x02
#define	brighting_1			0x01



#define TM1650_SCL_H    GPIO_SetBits(TIM1650_CLK_GPIO_Port, TIM1650_CLK_Pin);
#define TM1650_SCL_L    GPIO_ResetBits(TIM1650_CLK_GPIO_Port, TIM1650_CLK_Pin);
#define TM1650_SDA_H    GPIO_SetBits(TIM1650_DAT_GPIO_Port, TIM1650_DAT_Pin);
#define TM1650_SDA_L    GPIO_ResetBits(TIM1650_DAT_GPIO_Port, TIM1650_DAT_Pin);
#define READ_SDA 		GPIO_ReadInputDataBit(TIM1650_DAT_GPIO_Port,TIM1650_DAT_Pin)		 //����ƽ



#ifdef __cplusplus
extern "C" {
#endif

void tm1650_send_dig_data(uint16_t index, uint16_t num);
void display_number_4bit_dig(unsigned short num);
void tm1650_send_command(unsigned char address, unsigned char data);
void tm1650_init(void);
unsigned char tm1650_read_key(void);
uint32_t tm1650_get_key(void);


#ifdef __cplusplus
}
#endif
#endif

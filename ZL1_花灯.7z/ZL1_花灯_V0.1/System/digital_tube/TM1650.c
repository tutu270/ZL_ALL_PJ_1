#include "TM1650.h"
#include "digital_tube_driver.h"
#include "../io_define.h"

uint8_t seven_segment_numbers[16] = {SHOW_NUM0, SHOW_NUM1, SHOW_NUM2, SHOW_NUM3, SHOW_NUM4, SHOW_NUM5, SHOW_NUM6, SHOW_NUM7, SHOW_NUM8, SHOW_NUM9};
uint32_t key_number[7][4] = {
        {11, 12, 13, 14},
        {21, 22, 23, 24},
        {31, 32, 33, 34},
        {41, 42, 43, 44},
        {51, 52, 53, 54},
        {61, 62, 63, 64},
        {71, 72, 73, 74}
};
uint8_t key_numberH[7][4] = {
        {0x44, 0x45, 0x46, 0x47},
        {0x4C, 0x4D, 0x4E, 0x4F},
        {0x54, 0x55, 0x56, 0x57},
        {0x5C, 0x5D, 0x5E, 0x5F},
        {0x64, 0x65, 0x66, 0x67},
        {0x6C, 0x6D, 0x6E, 0x6F},
        {0x74, 0x75, 0x76, 0x77}
};

void sda_input(void) {
    GPIO_InitTypeDef gpioConfig;
    RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOB, ENABLE);
    gpioConfig.GPIO_Pin = TIM1650_DAT_Pin;
    gpioConfig.GPIO_Speed = GPIO_Speed_10MHz;
    gpioConfig.GPIO_Mode = GPIO_Mode_IN;
    GPIO_Init(TIM1650_DAT_GPIO_Port, &gpioConfig);
}

void sda_output(void) {
    GPIO_InitTypeDef gpioConfig;
    RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOB, ENABLE);
    gpioConfig.GPIO_Pin = TIM1650_DAT_Pin;
    gpioConfig.GPIO_Speed = GPIO_Speed_10MHz;
    gpioConfig.GPIO_Mode = GPIO_Mode_OUT;
    gpioConfig.GPIO_OType = GPIO_OType_PP;
    gpioConfig.GPIO_PuPd = GPIO_PuPd_NOPULL;
    GPIO_Init(TIM1650_DAT_GPIO_Port, &gpioConfig);
}

void tm1650_delay_us(unsigned short delay) {
    for (; delay > 0; delay--) {
        __NOP(); // No Operation
    }
}

void tm1650_start(void) {
    sda_output();
    TM1650_SDA_H;
    TM1650_SCL_H;
    tm1650_delay_us(4);
    TM1650_SDA_L;
    tm1650_delay_us(4);
    TM1650_SCL_L;
}

void tm1650_stop(void) {
    sda_output();
    TM1650_SCL_L;
    TM1650_SDA_L;
    tm1650_delay_us(4);
    TM1650_SCL_H;
    tm1650_delay_us(4);
    TM1650_SDA_H;
}

unsigned char tm1650_wait_ack(void) {
    unsigned char err_time = 0;
    sda_input();
    TM1650_SDA_H;
    tm1650_delay_us(1);
    TM1650_SCL_H;
    tm1650_delay_us(1);
    while (READ_SDA) {
        err_time++;
        if (err_time > 250) {
            tm1650_stop();
            return 1; // Timeout
        }
    }
    TM1650_SCL_L;
    return 0;
}

void tm1650_ack(void) {
    TM1650_SCL_L;
    sda_output();
    TM1650_SDA_L;
    tm1650_delay_us(4);
    TM1650_SCL_H;
    tm1650_delay_us(4);
    TM1650_SCL_L;
}

void tm1650_nack(void) {
    TM1650_SCL_L;
    sda_output();
    TM1650_SDA_H;
    tm1650_delay_us(4);
    TM1650_SCL_H;
    tm1650_delay_us(4);
    TM1650_SCL_L;
}

void tm1650_send_byte(unsigned char byte) {
    unsigned char t = 0;
    sda_output();
    TM1650_SCL_L;
    for ( t = 0; t < 8; t++) {
        if (byte & 0x80) {
            TM1650_SDA_H;
        } else {
            TM1650_SDA_L;
        }
        byte <<= 1;
        tm1650_delay_us(4);
        TM1650_SCL_H;
        tm1650_delay_us(4);
        TM1650_SCL_L;
        tm1650_delay_us(4);
    }
}

unsigned char tm1650_read_byte(void) {
    unsigned char i, rekey = 0;
    sda_input();
    for (i = 0; i < 8; i++) {
        TM1650_SCL_L;
        tm1650_delay_us(4);
        TM1650_SCL_H;
        rekey <<= 1;
        if (READ_SDA) rekey++;
        tm1650_delay_us(4);
    }
    return rekey;
}

void tm1650_send_command(unsigned char address, unsigned char data) {
    tm1650_start();
    tm1650_send_byte(address);
    tm1650_wait_ack();
    tm1650_send_byte(data);
    tm1650_wait_ack();
    tm1650_stop();
}

void tm1650_send_dig_data(uint16_t index, uint16_t num) {
    uint8_t index_address = 0;
    uint8_t num_value = seven_segment_numbers[num];

    switch (index) {
        case 1: index_address = 0x68; break;
        case 2: index_address = 0x6A; break;
        case 3: index_address = 0x6C; break;
        case 4: index_address = 0x6E; break;
        default: return; // Invalid index
    }

    tm1650_start();
    tm1650_send_byte(index_address);
    tm1650_wait_ack();
    tm1650_send_byte(num_value);
    tm1650_wait_ack();
    tm1650_stop();
}

void tm1650_set_display(uint8_t brightness) {
    tm1650_send_command(0x48, brightness * 16 + 1 * 4 + 1);
}

void tm1650_init(void) {
    GPIO_InitTypeDef gpioConfig;
    RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOB, ENABLE);

    gpioConfig.GPIO_Pin = TIM1650_DAT_Pin | TIM1650_CLK_Pin;
    gpioConfig.GPIO_Speed = GPIO_Speed_10MHz;
    gpioConfig.GPIO_Mode = GPIO_Mode_OUT;
    gpioConfig.GPIO_OType = GPIO_OType_PP;
    gpioConfig.GPIO_PuPd = GPIO_PuPd_NOPULL;
    GPIO_Init(TIM1650_DAT_GPIO_Port, &gpioConfig);

    GPIO_ResetBits(GPIOB, TIM1650_CLK_Pin | TIM1650_DAT_Pin);

    TM1650_SCL_H;
    TM1650_SDA_H;
    tm1650_set_display(brighting_2);
}

void display_number_4bit_dig(uint16_t num) {
    tm1650_send_dig_data(1, num / 1000 % 10);
    tm1650_send_dig_data(2, num / 100 % 10);
    tm1650_send_dig_data(3, num / 10 % 10);
    tm1650_send_dig_data(4, num % 10);
}

unsigned char tm1650_read_key(void) {
    unsigned char temp;
    tm1650_start();
    tm1650_send_byte(0x49);
    tm1650_wait_ack();
    temp = tm1650_read_byte();
    tm1650_wait_ack();
    tm1650_stop();
    return temp;
}

uint32_t tm1650_get_key(void) {
    uint32_t i = 0;
    uint32_t j = 0;
    unsigned char key = tm1650_read_key();
    for (i = 0; i < 7; i++) {
        for ( j = 0; j < 4; j++) {
            if (key == key_numberH[i][j]) {
                return key_number[i][j];
            }
        }
    }
    return 0; // No key pressed
}

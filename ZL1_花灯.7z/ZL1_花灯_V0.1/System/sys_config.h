
#ifndef _SYS_CONFIG_H
#define _SYS_CONFIG_H

#define IR_OPEN  1
#define IR_CLOSE 0

#define SYS_DEFAULT_R3XX_NUMBER 8     // 0 - 10
#define SYS_DEFAULT_G3XX_NUMBER 8     // 0 - 10
#define SYS_DEFAULT_B3XX_NUMBER 8     // 0 - 10
#define SYS_DEFAULT_W3XX_NUMBER 8     // 0 - 10
#define SYS_DEFAULT_R4XX_NUMBER 8     // 0 - 10
#define SYS_DEFAULT_G4XX_NUMBER 8     // 0 - 10
#define SYS_DEFAULT_B4XX_NUMBER 8     // 0 - 10
#define SYS_DEFAULT_W4XX_NUMBER 8     // 0 - 10
#define SYS_DEFAULT_R5XX_NUMBER 8     // 0 - 10
#define SYS_DEFAULT_G5XX_NUMBER 8     // 0 - 10
#define SYS_DEFAULT_B5XX_NUMBER 8     // 0 - 10
#define SYS_DEFAULT_W5XX_NUMBER 8     // 0 - 10
#define SYS_DEFAULT_RXXX_NUMBER 200     // 1 - 255
#define SYS_DEFAULT_GXXX_NUMBER 200     // 1 - 255
#define SYS_DEFAULT_BXXX_NUMBER 200     // 1 - 255
#define SYS_DEFAULT_IR_STATIC IR_OPEN   // ң��״̬
#define SYS_DEFAULT_S1xx_NUMBER 5     // 0 - 10
#define SYS_DEFAULT_S2xx_NUMBER 5     // 0 - 10

#define SYS_CONSOLE_EASE_CH  19
#define SYS_CONSOLE_DIFF_CH  29
#define SYS_DEFAULT_CONSOLE_CH SYS_CONSOLE_EASE_CH

#endif

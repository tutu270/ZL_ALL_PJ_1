#ifndef RDM_CONFIG_H
#define RDM_CONFIG_H


#define MAN_ID    0X1099

#define DEVICE_MODEL_ID1             0x00  /* MSB */
#define DEVICE_MODEL_ID0             0x01  /* LSB */

#define SW_VERSION_ID3               0x01  /* MSB */
#define SW_VERSION_ID2               0x00
#define SW_VERSION_ID1               0x00
#define SW_VERSION_ID0               0x03  /* LSB */
#define FIRMWARE_VERSION             "V108"

#define SC_NULL                      0x00  /* NULL Start Code Packet */
#define SC_TEXT                      0x17  /* Start Code ASCII Text Packet */
#define SC_RDM                       0xCC  /* Start Code RDM Packet */

#define SC_SUB_MESSAGE               0x01

// RDM command classes (Slot 20)
#define DISCOVERY_COMMAND            0x10
#define DISCOVERY_COMMAND_RESPONSE   0x11
#define GET_COMMAND                  0x20
#define GET_COMMAND_RESPONSE         0x21
#define SET_COMMAND                  0x30
#define SET_COMMAND_RESPONSE         0x31

#define RESPONSE_TYPE_ACK            0x00
#define RESPONSE_TYPE_ACK_TIMER      0x01
#define RESPONSE_TYPE_NACK_REASON    0x02
#define RESPONSE_TYPE_ACK_OVERFLOW   0x03

#define DISC_UNIQUE_BRANCH           0x0001  //Ѱ���豸
#define DISC_MUTE                    0x0002  //�豸����
#define DISC_UN_MUTE                 0x0003  //�豸ȡ������
#define DEVICE_INFO                  0x0060  //�豸��Ϣ
#define SOFTWARE_VERSION_LABEL       0x00C0  //�����汾��ǩ
#define DMX_PERSONALITY   					 0x00E0  //�豸DMXģʽ�����ԣ�
#define DMX_START_ADDRESS            0x00F0  //DMX��ʼ��ַ
#define IDENTIFY_DEVICE              0x1000  //��֤�豸
#define DEVICE_LABEL                 0x0082  //�豸��ǩ
#define MANUFACTURER_LABEL           0x0081  //���̱�ǩ
#define DEVICE_HOURS                 0x0400  //�豸����ʱ��


#endif

//
//#include "rdm_test.h"
//#include "menu/menu.h"
//#include "dmx.h"
//#include "i_flash/flash.h"
//#include "fun.h"
//#include "rdm.h"
//
//#define ID_BASE_ADDR 0x1FFFF7AC
//rdm_dmx512 apm_rdm_dmx512 ;
//uint8_t ch_num[] = {0,8, 9};
//uint8_t ch_mode = 1;
//uint8_t crc_high_first(uint8_t *ptr, uint8_t len)
//{
//    uint8_t i;
//    uint8_t crc = 0x00; /* ����ĳ�ʼcrcֵ */
//
//    while (len--) {
//        crc ^= *ptr++;        /* ÿ��������Ҫ������������,������ָ����һ���� */
//        for (i = 8; i > 0; --i)   /* ������μ�����������һ���ֽ�crcһ�� */
//        {
//            if (crc & 0x80)
//                crc = (crc << 1) ^ 0x31;
//            else
//                crc = (crc << 1);
//        }
//    }
//    return (crc);
//}
//
//
//void RDM_init_globals(void)
//{
//
//    uint8_t *addr = (uint8_t *) ID_BASE_ADDR;
//    uint8_t chip_uid[12];
//
//    for (unsigned char  i = 0;i <12;i++) {
//        chip_uid[i] = *addr;
//        addr++;
//    }
//    apm_rdm_dmx512.unique_id[0] = 0x10;//(MAN_ID>>8)&0xFF
//    apm_rdm_dmx512.unique_id[1] = 0x99;//(MAN_ID>>0)&0xFF
//    apm_rdm_dmx512.unique_id[2] = crc_high_first(&chip_uid[9], 3);
//    apm_rdm_dmx512.unique_id[3] = crc_high_first(&chip_uid[6], 3);
//    apm_rdm_dmx512.unique_id[4] = crc_high_first(&chip_uid[3], 3);
//    apm_rdm_dmx512.unique_id[5] = crc_high_first(&chip_uid[0], 3);
//
//    apm_rdm_dmx512.rdm_break_time_u16 = 300;           /* 250 usec */
//    apm_rdm_dmx512.rdm_mab_time_u8 = 30;            /*  40 usec */
//    apm_rdm_dmx512.rdm_message_count_u8 = 0;
//    apm_rdm_dmx512.rdm_identify_state_u8 = 0;
//}
//
//
//static uint16_t calc_crc(uint8_t *codedata, uint8_t len)
//{
//    uint16_t crc = 0;
//    uint16_t i;
//
//    for (i = 0; i < len; i++) {
//        crc += *codedata++;
//    }
//    return crc;
//}
//
//
//static bool check_broadcast(void)
//{
//    if ((DMX_RxBuf[5] == 0xFF) && (DMX_RxBuf[6] == 0xFF) &&
//        (DMX_RxBuf[7] == 0xFF) && (DMX_RxBuf[8] == 0xFF)) {
//        if (((DMX_RxBuf[3] == 0xFF) && (DMX_RxBuf[4] == 0xFF)) ||
//            ((DMX_RxBuf[3] == apm_rdm_dmx512.unique_id[0]) &&
//             (DMX_RxBuf[4] == apm_rdm_dmx512.unique_id[1]))) {
//            return true; //3��4��5��6��7��8==0XFF  ���� 3=MAN_ID_L��4=MAN_ID_H ��5��6��7��8==0XFF
//        }
//    }
//    return false;//ֻ��5��6��7��8==0XFF
//}
//
//static bool check_own_uid(void)
//{
//    if ((DMX_RxBuf[3] == apm_rdm_dmx512.unique_id[0]) &&
//        (DMX_RxBuf[4] == apm_rdm_dmx512.unique_id[1]) &&
//        (DMX_RxBuf[5] == apm_rdm_dmx512.unique_id[2]) &&
//        (DMX_RxBuf[6] == apm_rdm_dmx512.unique_id[3]) &&
//        (DMX_RxBuf[7] == apm_rdm_dmx512.unique_id[4]) &&
//        (DMX_RxBuf[8] == apm_rdm_dmx512.unique_id[5])) {
//        return true;
//    }
//    return false;
//}
//
//
//void Uart_XmitDmxSlotValues(uint16_t msg_len, uint16_t break_time, uint16_t mab_time)
//{
//    uint16_t senddata_order;
//
//    DMX512_StartTransmit_user( apm_rdm_dmx512.rdm_response_msg, msg_len, break_time,
//                               mab_time);
//
//}
//
//static void send_disc_response(void)
//{
//    uint16_t crc;
//    apm_rdm_dmx512.rdm_response_msg[0] = 0xFE;
//    apm_rdm_dmx512.rdm_response_msg[1] = 0xFE;
//    apm_rdm_dmx512.rdm_response_msg[2] = 0xFE;
//    apm_rdm_dmx512.rdm_response_msg[3] = 0xFE;
//    apm_rdm_dmx512.rdm_response_msg[4] = 0xFE;
//    apm_rdm_dmx512.rdm_response_msg[5] = 0xFE;
//    apm_rdm_dmx512.rdm_response_msg[6] = 0xFE;
//    apm_rdm_dmx512.rdm_response_msg[7] = 0xAA;
//    apm_rdm_dmx512.rdm_response_msg[8] = apm_rdm_dmx512.unique_id[0] | 0xAA;
//    apm_rdm_dmx512.rdm_response_msg[9] = apm_rdm_dmx512.unique_id[0] | 0x55;
//    apm_rdm_dmx512.rdm_response_msg[10] = apm_rdm_dmx512.unique_id[1] | 0xAA;
//    apm_rdm_dmx512.rdm_response_msg[11] = apm_rdm_dmx512.unique_id[1] | 0x55;
//    apm_rdm_dmx512.rdm_response_msg[12] = apm_rdm_dmx512.unique_id[2] | 0xAA;
//    apm_rdm_dmx512.rdm_response_msg[13] = apm_rdm_dmx512.unique_id[2] | 0x55;
//    apm_rdm_dmx512.rdm_response_msg[14] = apm_rdm_dmx512.unique_id[3] | 0xAA;
//    apm_rdm_dmx512.rdm_response_msg[15] = apm_rdm_dmx512.unique_id[3] | 0x55;
//    apm_rdm_dmx512.rdm_response_msg[16] = apm_rdm_dmx512.unique_id[4] | 0xAA;
//    apm_rdm_dmx512.rdm_response_msg[17] = apm_rdm_dmx512.unique_id[4] | 0x55;
//    apm_rdm_dmx512.rdm_response_msg[18] = apm_rdm_dmx512.unique_id[5] | 0xAA;
//    apm_rdm_dmx512.rdm_response_msg[19] = apm_rdm_dmx512.unique_id[5] | 0x55;
//    crc = calc_crc(&apm_rdm_dmx512.rdm_response_msg[8], 12);
//    apm_rdm_dmx512.rdm_response_msg[20] = ((crc >> 8) & 0xFF) | 0xAA;
//    apm_rdm_dmx512.rdm_response_msg[21] = ((crc >> 8) & 0xFF) | 0x55;
//    apm_rdm_dmx512.rdm_response_msg[22] = ((crc >> 0) & 0xFF) | 0xAA;
//    apm_rdm_dmx512.rdm_response_msg[23] = ((crc >> 0) & 0xFF) | 0x55;
//    Uart_XmitDmxSlotValues(24, 0/*NO BREAK*/, 0);
//}
//
//
//static void send_recRDMdata(uint16_t command_class, uint8_t data_len)
//{
//    uint16_t crc;
//    uint8_t count = 24 + data_len;
//
//    apm_rdm_dmx512.rdm_response_msg[0] = SC_RDM;
//    apm_rdm_dmx512.rdm_response_msg[1] = SC_SUB_MESSAGE;
//    apm_rdm_dmx512.rdm_response_msg[2] = count;
//    apm_rdm_dmx512.rdm_response_msg[3] = DMX_RxBuf[9];         // copy destination from received msg
//    apm_rdm_dmx512.rdm_response_msg[4] = DMX_RxBuf[10];
//    apm_rdm_dmx512.rdm_response_msg[5] = DMX_RxBuf[11];
//    apm_rdm_dmx512.rdm_response_msg[6] = DMX_RxBuf[12];
//    apm_rdm_dmx512.rdm_response_msg[7] = DMX_RxBuf[13];
//    apm_rdm_dmx512.rdm_response_msg[8] = DMX_RxBuf[14];
//
//    apm_rdm_dmx512.rdm_response_msg[9] = apm_rdm_dmx512.unique_id[0];
//    apm_rdm_dmx512.rdm_response_msg[10] = apm_rdm_dmx512.unique_id[1];
//    apm_rdm_dmx512.rdm_response_msg[11] = apm_rdm_dmx512.unique_id[2];
//    apm_rdm_dmx512.rdm_response_msg[12] = apm_rdm_dmx512.unique_id[3];
//    apm_rdm_dmx512.rdm_response_msg[13] = apm_rdm_dmx512.unique_id[4];
//    apm_rdm_dmx512.rdm_response_msg[14] = apm_rdm_dmx512.unique_id[5];
//
//    apm_rdm_dmx512.rdm_response_msg[15] = DMX_RxBuf[15];        // pass back Transaction Number
//    apm_rdm_dmx512.rdm_response_msg[16] = RESPONSE_TYPE_ACK;
//    apm_rdm_dmx512.rdm_response_msg[17] = apm_rdm_dmx512.rdm_message_count_u8;
//    apm_rdm_dmx512.rdm_response_msg[18] = 0;                  // Sub-Device MSB
//    apm_rdm_dmx512.rdm_response_msg[19] = 0;                  // Sub-Device LSB
//    apm_rdm_dmx512.rdm_response_msg[20] = command_class;
//    apm_rdm_dmx512.rdm_response_msg[21] = DMX_RxBuf[21];        // copy PID from received msg
//    apm_rdm_dmx512.rdm_response_msg[22] = DMX_RxBuf[22];
//    apm_rdm_dmx512.rdm_response_msg[23] = data_len;
//    crc = calc_crc(apm_rdm_dmx512.rdm_response_msg, count);
//    apm_rdm_dmx512.rdm_response_msg[count + 0] = (crc >> 8) & 0xFF;
//    apm_rdm_dmx512.rdm_response_msg[count + 1] = (crc >> 0) & 0xFF;
//
//    Uart_XmitDmxSlotValues((count + 2), apm_rdm_dmx512.rdm_break_time_u16, apm_rdm_dmx512.rdm_mab_time_u8);
//}
//
//static void send_disc_mute_response(void)
//{
//    // no binding uid, only the control field
//    apm_rdm_dmx512.rdm_response_msg[24] = 0;
//    apm_rdm_dmx512.rdm_response_msg[25] = 0;
//    send_recRDMdata(DISCOVERY_COMMAND_RESPONSE, 2);
//}
//
//static void send_get_device_info_response(void)
//{
//    if (33 == Cxxx.number) {
//        ch_mode = 1;
//    }else if (9 == Cxxx.number) {
//        ch_mode = 2;
//    }
//    apm_rdm_dmx512.rdm_response_msg[24] = 0x01;  // RDM Protocol Version MSB
//    apm_rdm_dmx512.rdm_response_msg[25] = 0x00;  // RDM Protocol Version LSB
//    apm_rdm_dmx512.rdm_response_msg[26] = DEVICE_MODEL_ID1;
//    apm_rdm_dmx512.rdm_response_msg[27] = DEVICE_MODEL_ID0;
//    apm_rdm_dmx512.rdm_response_msg[28] = 0x01;  // Product Category MSB
//    apm_rdm_dmx512.rdm_response_msg[29] = 0x01;  // Product Category LSB
//    apm_rdm_dmx512.rdm_response_msg[30] = SW_VERSION_ID3;
//    apm_rdm_dmx512.rdm_response_msg[31] = SW_VERSION_ID2;
//    apm_rdm_dmx512.rdm_response_msg[32] = SW_VERSION_ID1;
//    apm_rdm_dmx512.rdm_response_msg[33] = SW_VERSION_ID0;
//    apm_rdm_dmx512.rdm_response_msg[34] = 0x00;  // DMX512 Footprint MSB
//    apm_rdm_dmx512.rdm_response_msg[35] = (uint8_t) ch_num[ch_mode];//��ǰģʽ��ռ�õ�ͨ����
//    apm_rdm_dmx512.rdm_response_msg[36] = ch_mode;  // DMX512 Personality MSB  512���Ը�λ  512��ǰģʽ
//    apm_rdm_dmx512.rdm_response_msg[37] = 2;        // DMX512 Personality LSB  512���Ե�λ  512ģʽ��
//    apm_rdm_dmx512.rdm_response_msg[38] = (Axxx.number >> 8) & 0xFF; // DMX512 Start Address MSB
//    apm_rdm_dmx512.rdm_response_msg[39] = (Axxx.number >> 0) & 0xFF; // DMX512 Start Address LSB
//    apm_rdm_dmx512.rdm_response_msg[40] = 0x00;  // Sub-Device Count MSB
//    apm_rdm_dmx512.rdm_response_msg[41] = 0x00;  // Sub-Device Count LSB
//    apm_rdm_dmx512.rdm_response_msg[42] = 0x00;  // Sensor Count
//    send_recRDMdata(GET_COMMAND_RESPONSE, 19);
//}
//static void send_get_dmx_start_address_response(void)
//{
//    apm_rdm_dmx512.rdm_response_msg[24] = (Axxx.number >> 8) & 0xFF;
//    apm_rdm_dmx512.rdm_response_msg[25] = (Axxx.number >> 0) & 0xFF;
//    send_recRDMdata(GET_COMMAND_RESPONSE, 2);
//}
//
//static void send_get_identify_device_response(uint8_t state)
//{
//    apm_rdm_dmx512.rdm_response_msg[24] = state;
//    send_recRDMdata(GET_COMMAND_RESPONSE, 1);
//}
//
//static void send_get_dmx_personality_response(void)//��ȡDMXģʽ
//{
//    apm_rdm_dmx512.rdm_response_msg[24] = 1;
//    apm_rdm_dmx512.rdm_response_msg[25] = 1;
//    send_recRDMdata(SET_COMMAND_RESPONSE, 2);
//}
//
//static void send_set_dmx_start_address_response(void)
//{
//    send_recRDMdata(SET_COMMAND_RESPONSE, 0);
//}
//
//static void send_set_identify_device_response(void)
//{
//    send_recRDMdata(SET_COMMAND_RESPONSE, 0);
//}
//
//static void send_set_dmx_personality_response(void)//����DMXģʽ
//{
//    send_recRDMdata(SET_COMMAND_RESPONSE, 0);
//}
//uint8_t i;
//uint8_t len;
//uint16_t crc;
//bool broadcast;
//bool own_uid;
//uint16_t pid;
//uint16_t sdas;
//bool rdm_muted = false;
//
//void rdm_handle_recRDMdata(void)
//{
//
//
//    bool less_t_upper_uid = false;   //С�� upper_bound_uid
//    bool greater_t_lower_uid = false;//���� lower_bound_uid
//
//    /* check sub start code in RDM Packet and minimum lenght */
//    if ((DMX_RxBuf[1] == SC_SUB_MESSAGE) && (DMX_RxBuf[2] >= 24)) {
//        len = DMX_RxBuf[2];
//        sdas = calc_crc(DMX_RxBuf, len);
//        crc = DMX_RxBuf[len] << 8 | DMX_RxBuf[len + 1];
//        pid = DMX_RxBuf[21] << 8 | DMX_RxBuf[22];
//
//        if (sdas != crc) return;
//
//        broadcast = check_broadcast();
//        own_uid = check_own_uid();
//
//        if (!broadcast && !own_uid) return;
//
//
//        switch (DMX_RxBuf[20]) {
//            case DISCOVERY_COMMAND:
//
//                if ((pid == DISC_UNIQUE_BRANCH) && (len == 36)) {
//                    if (!rdm_muted) {
//
//                        for (i = 0; i < 6; i++)                              //�ȴ����λ��ʼ�Ƚϣ����λ���ھ��Ǵ���
//                        {
//                            if (apm_rdm_dmx512.unique_id[i] >
//                                DMX_RxBuf[i + 24])      //UID�Ӹ�λ��ʼ����RDM��Сֵ��λ ���ڷ�Χ�ڣ�ֱ���˳�
//                            {
//                                greater_t_lower_uid = true;
//                                break;
//                            } else if (apm_rdm_dmx512.unique_id[i] <
//                                       DMX_RxBuf[i + 24]) //UID�Ӹ�λ��ʼС����RDM��Сֵ��λ �Ȳ��ڷ�Χ�ڣ�ֱ���˳�
//                            {
//                                greater_t_lower_uid = false;
//                                break;
//                            } else                                       //UID�Ӹ�λ����RDM��Сֵ��λ��Ҫ�Ƚ���һλ��ֱ�����һλ���ǵ��ڣ����ڷ�Χ��
//                            {
//                                if (i == 5) {
//                                    greater_t_lower_uid = true;
//                                    break;
//                                }
//                            }
//                        }
//
//                        for (i = 0; i < 6; i++)                        //�ȴ����λ��ʼ�Ƚϣ����λС�ھ���С��
//                        {
//                            if (apm_rdm_dmx512.unique_id[i] <
//                                DMX_RxBuf[i + 30])//UID�Ӹ�λ��ʼС��RDM���ֵ��λ ���ڷ�Χ�ڣ�ֱ���˳�
//                            {
//                                less_t_upper_uid = true;
//                                break;
//                            }
//                            if (apm_rdm_dmx512.unique_id[i] >
//                                DMX_RxBuf[i + 30])//UID�Ӹ�λ��ʼ����RDM���ֵ��λ �Ȳ��ڷ�Χ�ڣ�ֱ���˳�
//                            {
//                                less_t_upper_uid = false;
//                                break;
//                            } else                                  //UID�Ӹ�λ����RDM���ֵ��λ��Ҫ�Ƚ���һλ��ֱ�����һλ���ǵ��ڣ����ڷ�Χ��
//                            {
//                                if (i == 5) {
//                                    less_t_upper_uid = true;
//                                    break;
//                                }
//                            }
//                        }
//
//                        if (greater_t_lower_uid && less_t_upper_uid) {
//                            send_disc_response();
//                        }
//                    }
//                }
//                else if ((pid == DISC_MUTE) && (len == 24)) {
//                    rdm_muted = true;
//                    if (own_uid)
//                        send_disc_mute_response();
//                }
//                else if ((pid == DISC_UN_MUTE) && (len == 24)) {
//                    rdm_muted = false;
//                    if (own_uid)
//                        send_disc_mute_response();
//                    //send_disc_un_mute_response();
//                }
//                break;
//            case GET_COMMAND:
//                if (own_uid) {
//                    if ((pid == DEVICE_INFO || pid == 0x00E1) && (len == 24))               //RDMҪ���ȡ�豸��Ϣ
//                    {
//                        send_get_device_info_response();
//                    }
////						else if ((pid == SOFTWARE_VERSION_LABEL) && (len == 24))//RDMҪ���ȡ�豸�̼��汾
////						{
////							send_get_software_version_response();
////						}
//                    else if ((pid == DMX_START_ADDRESS) && (len == 24))     //RDMҪ���ȡ�豸��ַ��
//                    {
//                        send_get_dmx_start_address_response();
//                    } else if ((pid == IDENTIFY_DEVICE) && (len == 24))       //RDMҪ���ȡ�豸��֤
//                    {
//                        send_get_identify_device_response(apm_rdm_dmx512.rdm_identify_state_u8);
//                    }
//                    if ((pid == DMX_PERSONALITY) && (len == 24))            //�豸DMXģʽ����
//                    {
//                        send_get_dmx_personality_response();
//                    }
////						else if((pid == MANUFACTURER_LABEL) && (len == 24))    //RDMҪ���ȡ��˾��ǩ
////						{
////							send_get_manufacturer_label_response();
////						}
////						else if ((pid == DEVICE_LABEL) && (len == 24))          //RDMҪ���ȡ�豸��ǩ
////						{
////							send_get_device_label_response();
////						}
//                }
//                break;
//            case SET_COMMAND:
//                if ((pid == DMX_START_ADDRESS) && (len == 26))             //�޸��豸��ַ��
//                {
//                    Axxx.number = (DMX_RxBuf[24] << 8) | DMX_RxBuf[25];
//                    if (own_uid)
//                        send_set_dmx_start_address_response();
//                    flash_write();
//                } else if ((pid == DMX_PERSONALITY) && (len == 25))         //�޸��豸��ͨ��ģʽ
//                {
//                    ch_mode = DMX_RxBuf[24];
//                    Cxxx.number = ch_num[ch_mode];
//                    send_set_dmx_personality_response();
//                    flash_write();
//
//                } else if ((pid == IDENTIFY_DEVICE) && (len == 25))         //��֤�豸������
//                {
//                    apm_rdm_dmx512.rdm_identify_state_u8 = DMX_RxBuf[24];
//                    if (apm_rdm_dmx512.rdm_identify_state_u8) {
//
//                        fun_set_rgbw0(255, 255, 255, 255);
//                    } else {
//                        sys_fun_OOOO_B();
//                    }
//                    if (own_uid)
//                        send_set_identify_device_response();
//                }
//                break;
//            default:
//                break;
//        }
//    }
//}
//
//void rdm_Init()
//{
//    apm_rdm_dmx512.rx_flag = false;
//    RDM_init_globals();
//    apm_rdm_dmx512.rdm_break_time_u16 = 100;
//    apm_rdm_dmx512.rdm_mab_time_u8 = 10;
//    apm_rdm_dmx512.rdm_message_count_u8 = 0;
//    apm_rdm_dmx512.rdm_identify_state_u8 = 0;
//
//    if (33 == Cxxx.number) {
//        ch_mode = 1;
//    } else if (9 == Cxxx.number) {
//        ch_mode = 2;
//    }
//
//}

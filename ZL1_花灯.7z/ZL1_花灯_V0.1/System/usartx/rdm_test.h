//
//#ifndef HUADENG_RDM_TEST_H
//#define HUADENG_RDM_TEST_H
//
//
//#include <stdint.h>
//#include <stdbool.h>
//#include "rdm_config.h"
//
//typedef struct  {
//    bool RDM_recFinish_b;
//    bool rx_flag;
//    uint8_t unique_id[6];   // RMD����ID
//    uint8_t rdm_mab_time_u8;
//    uint8_t rdm_message_count_u8;
//    uint8_t rdm_response_msg[64];
//    uint8_t rdm_identify_state_u8;
//    uint16_t rdm_break_time_u16;
//
//
//} rdm_dmx512;
//
//void rdm_Init();
//
//void rdm_handle_recRDMdata(void);
//
//extern rdm_dmx512 apm_rdm_dmx512;
//#endif

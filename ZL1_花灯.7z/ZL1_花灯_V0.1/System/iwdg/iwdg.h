
#ifndef _IWDG_H
#define _IWDG_H
#include "stm32f0xx_conf.h"

void iwdg_init(void);
void iwdg_feed(void);

#endif //HUADENG_IWDG_H

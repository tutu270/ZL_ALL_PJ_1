
#include "menu.h"
#include "digital_tube/digital_tube_driver.h"
#include "key/key.h"
#include "ws2812/ws2812_fun.h"
#include "i_flash/flash.h"
#include "decode_433/d_433.h"
#include "sysfun.h"
#include "usartx/dmx.h"
#include "sys_config.h"

Menu_With_Numbers OOOO_b = MENU_INIT("V000", 1, 1, 1);
Menu_With_Numbers R3xxx_b = MENU_INIT("R3XX", 1, SYS_DEFAULT_R3XX_NUMBER, 10);
Menu_With_Numbers G3xxx_b = MENU_INIT("G3XX", 1, SYS_DEFAULT_G3XX_NUMBER, 10);
Menu_With_Numbers B3xxx_b = MENU_INIT("B3XX", 1, SYS_DEFAULT_B3XX_NUMBER, 10);
Menu_With_Numbers W3xxx_b = MENU_INIT("W3XX", 1, SYS_DEFAULT_W3XX_NUMBER, 10);
Menu_With_Numbers R4xxx_b = MENU_INIT("R4XX", 1, SYS_DEFAULT_R4XX_NUMBER, 10);
Menu_With_Numbers G4xxx_b = MENU_INIT("G4XX", 1, SYS_DEFAULT_G4XX_NUMBER, 10);
Menu_With_Numbers B4xxx_b = MENU_INIT("B4XX", 1, SYS_DEFAULT_B4XX_NUMBER, 10);
Menu_With_Numbers W4xxx_b = MENU_INIT("W4XX", 1, SYS_DEFAULT_W4XX_NUMBER, 10);
Menu_With_Numbers R5xxx_b = MENU_INIT("R5XX", 1, SYS_DEFAULT_R5XX_NUMBER, 10);
Menu_With_Numbers G5xxx_b = MENU_INIT("G5XX", 1, SYS_DEFAULT_G5XX_NUMBER, 10);
Menu_With_Numbers B5xxx_b = MENU_INIT("B5XX", 1, SYS_DEFAULT_B5XX_NUMBER, 10);
Menu_With_Numbers W5xxx_b = MENU_INIT("W5XX", 1, SYS_DEFAULT_W5XX_NUMBER, 10);
Menu_With_Numbers Rxxx_b = MENU_INIT("RXXX", 1, SYS_DEFAULT_RXXX_NUMBER, 255);
Menu_With_Numbers Gxxx_b = MENU_INIT("GXXX", 1, SYS_DEFAULT_GXXX_NUMBER, 255);
Menu_With_Numbers Bxxx_b = MENU_INIT("BXXX", 1, SYS_DEFAULT_BXXX_NUMBER, 255);
Menu_With_Numbers IRxx_b = MENU_INIT("IRXX", 0, SYS_DEFAULT_IR_STATIC, 1);
Menu_With_Numbers SEND_b = MENU_INIT("SEND", 1, 1, 10);


Menu_With_Numbers Axxx = MENU_INIT("AXXX", 1, 1, 512);
Menu_With_Numbers Cxxx = MENU_INIT("CXXX", 1, SYS_DEFAULT_CONSOLE_CH, 33);
Menu_With_Numbers A1xx = MENU_INIT("A1-X", 1, 1, 9);
Menu_With_Numbers A2xx = MENU_INIT("A2-X", 1, 1, 9);
Menu_With_Numbers A3xx = MENU_INIT("A3-X", 1, 1, 9);
Menu_With_Numbers A4xx = MENU_INIT("A4-X", 1, 1, 9);
Menu_With_Numbers A5xx = MENU_INIT("A5-X", 1, 1, 9);
Menu_With_Numbers A6xx = MENU_INIT("A6-X", 1, 1, 9);
Menu_With_Numbers A7xx = MENU_INIT("A7-X", 1, 1, 9);
Menu_With_Numbers A8xx = MENU_INIT("A8-X", 1, 1, 9);
Menu_With_Numbers A9xx = MENU_INIT("A9-X", 1, 1, 9);
Menu_With_Numbers AAxx = MENU_INIT("AA-X", 1, 1, 9);
Menu_With_Numbers ABxx = MENU_INIT("AB-X", 1, 1, 9);
Menu_With_Numbers ACxx = MENU_INIT("AC-X", 1, 1, 9);
Menu_With_Numbers ADxx = MENU_INIT("AD-X", 1, 1, 9);
Menu_With_Numbers AExx = MENU_INIT("AE-X", 1, 1, 9);
Menu_With_Numbers AFxx = MENU_INIT("AF-X", 1, 1, 9);
Menu_With_Numbers S1xx = MENU_INIT("S1-X", 1, SYS_DEFAULT_S1xx_NUMBER, 10);
Menu_With_Numbers S2xx = MENU_INIT("S2-X", 1, SYS_DEFAULT_S2xx_NUMBER, 10);

Menu_With_Numbers SAVE = MENU_INIT("SAVE", 1, 1, 1);
Menu_With_Numbers Off = MENU_INIT("0OFF", 1, 1, 1);

Menu_With_Numbers *ptr = &Axxx;   // ָ��ͬ�˵�
Menu_With_Numbers *sys_ptr = NULL;  // ָ������̨ʱ�����ڵ�ǰ̨��ַ
uint8_t save_flag = 0;


Menu_With_Numbers *menu_level_front_desk[] = {
        &R3xxx_b,
        &G3xxx_b,
        &B3xxx_b,
        &R4xxx_b,
        &G4xxx_b,
        &B4xxx_b,
        &R5xxx_b,
        &G5xxx_b,
        &B5xxx_b,
        &W5xxx_b,
        &Rxxx_b,
        &Gxxx_b,
        &Bxxx_b,
        &Axxx,
        &A1xx,
        &A2xx,
        &A3xx,
        &A4xx,
        &A5xx,
        &A6xx,
        &A7xx,
        &A8xx,
        &A9xx,
        &AAxx,
        &ABxx,
        &ACxx,
        &ADxx,
        &AExx,
        &AFxx,
        &S1xx,
        &S2xx,
        &Cxxx,
        &IRxx_b,

};

void menu_init(void)
{

    OOOO_b.next_menu = &R3xxx_b;
    R3xxx_b.next_menu = &G3xxx_b;
    G3xxx_b.next_menu = &B3xxx_b;
    B3xxx_b.next_menu = &W3xxx_b;
    W3xxx_b.next_menu = &R4xxx_b;
    R4xxx_b.next_menu = &G4xxx_b;
    G4xxx_b.next_menu = &B4xxx_b;
    B4xxx_b.next_menu = &W4xxx_b;
    W4xxx_b.next_menu = &R5xxx_b;
    R5xxx_b.next_menu = &G5xxx_b;
    G5xxx_b.next_menu = &B5xxx_b;
    B5xxx_b.next_menu = &W5xxx_b;
    W5xxx_b.next_menu = &Rxxx_b;
    Rxxx_b.next_menu = &Gxxx_b;
    Gxxx_b.next_menu = &Bxxx_b;
    Bxxx_b.next_menu = &IRxx_b;
    IRxx_b.next_menu = &SEND_b;
    SEND_b.next_menu = &OOOO_b;


    Axxx.next_b_menu = &OOOO_b;
    A1xx.next_b_menu = &OOOO_b;
    A2xx.next_b_menu = &OOOO_b;
    A3xx.next_b_menu = &OOOO_b;
    A4xx.next_b_menu = &OOOO_b;
    A5xx.next_b_menu = &OOOO_b;
    A6xx.next_b_menu = &OOOO_b;
    A7xx.next_b_menu = &OOOO_b;
    A8xx.next_b_menu = &OOOO_b;
    A9xx.next_b_menu = &OOOO_b;
    AAxx.next_b_menu = &OOOO_b;
    ABxx.next_b_menu = &OOOO_b;
    ACxx.next_b_menu = &OOOO_b;
    ADxx.next_b_menu = &OOOO_b;
    AExx.next_b_menu = &OOOO_b;
    AFxx.next_b_menu = &OOOO_b;
    S1xx.next_b_menu = &OOOO_b;
    S2xx.next_b_menu = &OOOO_b;


    Axxx.next_menu = &A1xx;
    A1xx.next_menu = &A2xx;
    A2xx.next_menu = &A3xx;
    A3xx.next_menu = &A4xx;
    A4xx.next_menu = &A5xx;
    A5xx.next_menu = &A6xx;
    A6xx.next_menu = &A7xx;
    A7xx.next_menu = &A8xx;
    A8xx.next_menu = &A9xx;
    A9xx.next_menu = &AAxx;
    AAxx.next_menu = &ABxx;
    ABxx.next_menu = &ACxx;
    ACxx.next_menu = &ADxx;
    ADxx.next_menu = &AExx;
    AExx.next_menu = &AFxx;
    AFxx.next_menu = &S1xx;
    S1xx.next_menu = &S2xx;
    S2xx.next_menu = &Axxx;


    Axxx.next_save = &Cxxx;
    Cxxx.next_save = &Axxx;
    Cxxx.master_menu = &Axxx;

//    uint32_t a = (uint32_t) &Axxx;
//    ptr = (Menu_With_Numbers *) a;

}

void
menu_get_name(Menu_With_Numbers *this, uint16_t bit1cycle, uint16_t bit2cycle, uint16_t bit3cycle, uint16_t bit4cycle,
              bool is_open, uint8_t seg_mode)
{

    char res[4];
    res[0] = this->m_name[0];
    res[1] = this->m_name[1];
    res[2] = this->m_name[2];
    res[3] = this->m_name[3];


    if (res[1] == 'X') {
        res[1] = this->number / 100 % 10 + '0';
    }

    if (res[2] == 'X') {
        res[2] = this->number / 10 % 10 + '0';
    }

    if (res[3] == 'X') {
        res[3] = this->number % 10 + '0';
    }

    DisplayChar(res, bit1cycle, bit2cycle, bit3cycle, bit4cycle, is_open);
}

void number_add(Menu_With_Numbers *this)
{
    if (this == &Cxxx) {
        if (this->number == SYS_CONSOLE_EASE_CH) {
            this->number = SYS_CONSOLE_DIFF_CH;
        } else if (this->number == SYS_CONSOLE_DIFF_CH) {
            this->number = SYS_CONSOLE_EASE_CH;
        }
    } else {
        if (this->number < this->number_max) {
            this->number++;
        } else {
            this->number = this->number_min;
        }
    }


}

void number_subtract(Menu_With_Numbers *this)
{
    if (this == &Cxxx) {
        if (this->number == SYS_CONSOLE_EASE_CH) {
            this->number = SYS_CONSOLE_DIFF_CH;
        } else if (this->number == SYS_CONSOLE_DIFF_CH) {
            this->number = SYS_CONSOLE_EASE_CH;
        }
    } else {
        if (this->number > this->number_min) {
            this->number--;
        } else {
            this->number = this->number_max;
        }
    }

}

void menu_func_call(Menu_With_Numbers *this)
{
    if (DMX_CONNECT_State == DMX_CONNECT_ERROR) {
        if (this->func_ptr == NULL) return;
        (this->func_ptr)();
    }else if (DMX_CONNECT_State == DMX_CONNECT_OK) {
        Axxx.func_ptr();
    }

}


void menu_fun_ptr_init(void)
{
//    Sxxx.func_ptr = ws2812_change_moder;
    A1xx.func_ptr = sys_fun_a1xx;
    A2xx.func_ptr = sys_fun_a2xx;
    A3xx.func_ptr = sys_fun_a3xx;
    A4xx.func_ptr = sys_fun_a4xx;
    A5xx.func_ptr = sys_fun_a5xx;
    A6xx.func_ptr = sys_fun_a6xx;
    A7xx.func_ptr = sys_fun_a7xx;
    A8xx.func_ptr = sys_fun_a8xx;
    A9xx.func_ptr = sys_fun_a9xx;
    AAxx.func_ptr = sys_fun_aaxx;
    ABxx.func_ptr = sys_fun_abxx;
    ACxx.func_ptr = sys_fun_acxx;
    ADxx.func_ptr = sys_fun_adxx;
    AExx.func_ptr = sys_fun_aexx;
    AFxx.func_ptr = sys_fun_afxx;
    S1xx.func_ptr = sys_fun_suxx;
    S2xx.func_ptr = sys_fun_suxx;
//
    R3xxx_b.func_ptr = sys_fun_R3xxx_b;
    G3xxx_b.func_ptr = sys_fun_G3xxx_b;
    B3xxx_b.func_ptr = sys_fun_B3xxx_b;
    W3xxx_b.func_ptr = sys_fun_W3xxx_b;
    R4xxx_b.func_ptr = sys_fun_R4xxx_b;
    G4xxx_b.func_ptr = sys_fun_G4xxx_b;
    B4xxx_b.func_ptr = sys_fun_B4xxx_b;
    W4xxx_b.func_ptr = sys_fun_W4xxx_b;
    R5xxx_b.func_ptr = sys_fun_R5xxx_b;
    G5xxx_b.func_ptr = sys_fun_G5xxx_b;
    B5xxx_b.func_ptr = sys_fun_B5xxx_b;
    W5xxx_b.func_ptr = sys_fun_W5xxx_b;
    Rxxx_b.func_ptr = sys_fun_Rxxx_b;
    Gxxx_b.func_ptr = sys_fun_Gxxx_b;
    Bxxx_b.func_ptr = sys_fun_Bxxx_b;
    IRxx_b.func_ptr = sys_fun_OOOO_B;
    SEND_b.func_ptr = sys_fun_OOOO_B;
    OOOO_b.func_ptr = sys_fun_OOOO_B;
    Off.func_ptr = sys_fun_OOOO_B;

    Axxx.func_ptr = sys_fun_Axxx_Cxxx;
    Cxxx.func_ptr = sys_fun_Axxx_Cxxx;

//    SUxx.func_ptr = sys_fun_SUxx_SExx;
//    SExx.func_ptr = sys_fun_SUxx_SExx;
//    SOxx.func_ptr = sys_fun_SUxx_SExx;
}

static void menu_show_save_mode(uint8_t *flag, uint16_t save_show_time)
{
    static uint16_t show_time = 0;
    DMX_TxBuf[0] = MASTER_SLAVE_FRAME_SAVE_HEADER;
    DMX_TxBuf[1] = MASTER_SLAVE_FRAME_SAVE_HEADER1;
    DMX_TxBuf[2] = MASTER_SLAVE_FRAME_SAVE_HEADER2;
    DMX_TxBuf[3] = R3xxx_b.number;
    DMX_TxBuf[4] = G3xxx_b.number;
    DMX_TxBuf[5] = B3xxx_b.number;
    DMX_TxBuf[6] = W3xxx_b.number;
    DMX_TxBuf[7] = R4xxx_b.number;
    DMX_TxBuf[8] = G4xxx_b.number;
    DMX_TxBuf[9] = B4xxx_b.number;
    DMX_TxBuf[10] = W4xxx_b.number;
    DMX_TxBuf[11] = R5xxx_b.number;
    DMX_TxBuf[12] = G5xxx_b.number;
    DMX_TxBuf[13] = B5xxx_b.number;
    DMX_TxBuf[14] = W5xxx_b.number;
    DMX_TxBuf[15] = Rxxx_b.number;
    DMX_TxBuf[16] = Gxxx_b.number;
    DMX_TxBuf[17] = Bxxx_b.number;
    DMX_TxBuf[18] = IRxx_b.number;
    DMX_TxBuf[19] = MASTER_SLAVE_FRAME_SAVE_HEADER2;
    DMX_TxBuf[20] = MASTER_SLAVE_FRAME_SAVE_HEADER1;
    DMX_TxBuf[21] = MASTER_SLAVE_FRAME_SAVE_HEADER;

    show_time++;
    menu_get_name(&SAVE, 0, 0, 0, 0, true, WITH_SEG_P);

    if (ptr == &SEND_b) {
        DMX512_StartTransmit(DMX_TxBuf, 30);
    }

    if (show_time == save_show_time) {
        show_time = 0;
        (*flag) = 0;
    }


}


void menu_run()
{
    extern Key *key_arr[];
    static uint16_t long_press_count = 0;
    if (key_arr[0]->key_mode == shortPress) {    // ����1�̰�
//        if (apm_usart1_dat.pRxBuf[0] != CONSOLE_FRAME_HEADER && apm_usart1_dat.pRxBuf[0] != RDM_FRAME_HEADER) {
//            if (menu_show == nullptr) {
//                Menu_Utils::index++;
//                if (Menu_Utils::index == Menu_Utils::arr_size) {
//                    Menu_Utils::index = 0;
//                }
//            } else {
//                menu_show = nullptr;
//            }
//        }
        if (ptr->master_menu != NULL) {
            ptr = ptr->master_menu;
        } else {
            if ((ptr)->next_menu != NULL)ptr = (ptr)->next_menu;
        }
        save_flag_light = false;

        set_flag_false();
        key_arr[0]->key_mode = noPress;
    } else if (key_arr[0]->key_mode == longPress) {  // ����1����
        if (long_press_count < 500)long_press_count++;
        if (long_press_count == 500) {
            if (sys_ptr == NULL) {
                sys_ptr = ptr;
                ptr = (ptr)->next_b_menu;
            } else {
                ptr = sys_ptr;
                sys_ptr = NULL;
            }
            set_flag_false();
            long_press_count = 2001;
        }
        save_flag_light = false;

    } else if (key_arr[1]->key_mode == shortPress) { // ����2�̰�
        number_add(ptr);
        key_arr[1]->key_mode = noPress;
        save_flag_light = false;

    } else if (key_arr[1]->key_mode == longPress) { // ����2����
        long_press_count++;
        if (long_press_count == 25) {
            long_press_count = 0;
            number_add(ptr);
        }
        save_flag_light = false;


    } else if (key_arr[2]->key_mode == shortPress) {  // ����3�̰�
        number_subtract(ptr);
        key_arr[2]->key_mode = noPress;
        save_flag_light = false;

    } else if (key_arr[2]->key_mode == longPress) {  // ����3����
        long_press_count++;
        if (long_press_count == 25) {
            long_press_count = 0;
            number_subtract(ptr);
        }
        save_flag_light = false;

    } else if (key_arr[3]->key_mode == shortPress || key_arr[3]->key_mode == longPress) {  //����4 ���� ���� ����4 �̰�
        if (ptr->next_save != NULL) {
            ptr = ptr->next_save;
        }
        flash_write();
        save_flag = 1;
        key_arr[3]->key_mode = noPress;
        save_flag_light = false;

    } else {  // û�а�������
        long_press_count = 0;
    }

    if (save_flag) {
        menu_show_save_mode(&save_flag, 100);
    } else {
        if (DMX_CONNECT_State == DMX_CONNECT_OK) {
            menu_get_name(ptr, 100, 0, 0, 0, true, WITH_SEG_P);
        } else {
            menu_get_name(ptr, 0, 0, 0, 0, true, ONLY_SEG_P);
        }
    }
//    func_call(ptr);
}


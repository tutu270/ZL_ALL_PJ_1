
#ifndef _MENU_H
#define _MENU_H

#include <stdint.h>
#include <stdio.h>
#include <stdbool.h>

#define MENU_ARR_SIZE 33



// ����ṹ���������
typedef struct Menu_With_Numbers {
    const char *m_name;     // �˵�����
    int8_t number_min;      // �˵�Ҫ��ʾ����С����
    uint16_t number;        // �˵�Ҫ��ʾ������
    uint16_t number_max;    // �˵�Ҫ��ʾ���������
    void (*func_ptr)(void); // ����ָ��
    struct Menu_With_Numbers *next_save;
    struct Menu_With_Numbers *next_menu;
    struct Menu_With_Numbers *next_b_menu;
    struct Menu_With_Numbers *master_menu;

} Menu_With_Numbers;

#define MENU_INIT(name, min, num, max) { \
    name,   /* m_name */                 \
    min,    /* number_min */  \
    num,    /* number */      \
    max,    /* number_max */  \
    NULL,   /* next_save */   \
    NULL,   /* next_menu */   \
    NULL,   /* next_menu */   \
    NULL,   /* next_menu */   \
    NULL    /* func_ptr */    \
}

void menu_init(void);

void menu_run(void);

void number_subtract(Menu_With_Numbers *this);
void menu_func_call(Menu_With_Numbers *this);

void number_add(Menu_With_Numbers *this);

extern Menu_With_Numbers OOOO_b;
extern Menu_With_Numbers R3xxx_b;
extern Menu_With_Numbers G3xxx_b;
extern Menu_With_Numbers B3xxx_b;
extern Menu_With_Numbers W3xxx_b;
extern Menu_With_Numbers R4xxx_b;
extern Menu_With_Numbers G4xxx_b;
extern Menu_With_Numbers B4xxx_b;
extern Menu_With_Numbers W4xxx_b;
extern Menu_With_Numbers R5xxx_b;
extern Menu_With_Numbers G5xxx_b;
extern Menu_With_Numbers B5xxx_b;
extern Menu_With_Numbers W5xxx_b;
extern Menu_With_Numbers Rxxx_b;
extern Menu_With_Numbers Gxxx_b;
extern Menu_With_Numbers Bxxx_b;
extern Menu_With_Numbers IRxx_b;
extern Menu_With_Numbers Axxx;
extern Menu_With_Numbers Cxxx;
extern Menu_With_Numbers A1xx;
extern Menu_With_Numbers A2xx;
extern Menu_With_Numbers A3xx;
extern Menu_With_Numbers A4xx;
extern Menu_With_Numbers A5xx;
extern Menu_With_Numbers A6xx;
extern Menu_With_Numbers A7xx;
extern Menu_With_Numbers A8xx;
extern Menu_With_Numbers A9xx;
extern Menu_With_Numbers AAxx;
extern Menu_With_Numbers ABxx;
extern Menu_With_Numbers ACxx;
extern Menu_With_Numbers ADxx;
extern Menu_With_Numbers AExx;
extern Menu_With_Numbers AFxx;
extern Menu_With_Numbers S1xx;
extern Menu_With_Numbers S2xx;
extern Menu_With_Numbers *ptr;
extern Menu_With_Numbers *sys_ptr;  // ָ������̨ʱ�����ڵ�ǰ̨��ַ

extern Menu_With_Numbers Off ;
extern uint8_t save_flag;

#endif

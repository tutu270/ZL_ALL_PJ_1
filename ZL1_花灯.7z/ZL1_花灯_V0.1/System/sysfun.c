

#include "sysfun.h"
#include "io_define.h"
#include "Main.h"
#include "menu/menu.h"
#include "ws2812/adafruit_neopixel.h"
#include "ws2812/ws2812fx.h"
#include "usartx/dmx.h"
#include "fun.h"
#include "Dri_Motor.h"
#include "i_flash/flash.h"
#include "usartx/rdm.h"
#include "sys_config.h"
bool save_flag_light = false;

//#define RED 0xFF000000
//#define GREEN 0x00FF0000
//#define BLUE 0x0000FF00
//#define WHITE_ONLY 0x000000FF
//#define WHITE 0xFFFFFFFF
//#define RED_GREEN 0xFFFF0000
//#define RED_BLUE 0xFF00FF00
//#define GREEN_BLUE 0x00FFFF00
//#define BLACK 0x00000000
//
//#define USE_NONE_PWMX 100
//#define USE_RGBW 0
//#define USE_RGBW1 1
//#define USE_RGBW2 2
//#define USE_RGB1_RGBW2 3
//
//#define USE_RG 0
//#define USE_NONE_RG 1
//#define MAX 2000
//#define DIV255(x) ((((x) * 257) + 257) >> 16)
//
//_mode_ctrl mode_use;
//uint32_t a = 0;
//static uint32_t COLOR_SEQUENCE[] = {WHITE, RED, RED_GREEN, RED_BLUE, GREEN_BLUE, GREEN, BLUE};
//static void
//set_rgbwx(uint32_t rgbw, uint32_t rgbw2, uint32_t rgbw3)
//{
//    PWMR =  (MAX *  DIV255(((uint8_t)(rgbw >> 24))))* R3xxx_b.number / 10;
//    PWMG =  (MAX *  DIV255((uint8_t)(rgbw >> 16) )) * G3xxx_b.number / 10;
//    PWMB =  (MAX *  DIV255((uint8_t)(rgbw >> 8) )) * B3xxx_b.number / 10;
//    PWMW =  (MAX *  DIV255((uint8_t)(rgbw ) )) * W3xxx_b.number / 10;
//    PWMR1 = (MAX * DIV255((uint8_t)(rgbw2 >> 24) )) * R4xxx_b.number / 10;
//    PWMG1 = (MAX * DIV255((uint8_t)(rgbw2 >> 16) )) * G4xxx_b.number / 10;
//    PWMB1 = (MAX * DIV255((uint8_t)(rgbw2 >> 8) )) * B4xxx_b.number / 10;
//    PWMW1 = (MAX * DIV255((uint8_t)(rgbw2 ) )) * W4xxx_b.number / 10;
//    PWMR2 = (MAX * DIV255((uint8_t)(rgbw3 >> 24))) * R5xxx_b.number / 10;
//    PWMG2 = (MAX * DIV255((uint8_t)(rgbw3 >> 16))) * G5xxx_b.number / 10;
//    PWMB2 = (MAX * DIV255((uint8_t)(rgbw3 >> 8) )) * B5xxx_b.number / 10;
//    PWMW2 = (MAX * DIV255((uint8_t)(rgbw3 ) )) ;
//}
//
//static void set_rg(bool r, bool g)
//{
//    if (r) R_EN;   // �켤��
//    else R_DISEN;
//
//    if (g) G_EN;   // �̼���
//    else G_DISEN;
//}
//static void set_mode(_mode_ctrl * modeCtrl,uint16_t mode){
//    if (modeCtrl->mode != mode) {
//        modeCtrl->mode = mode;
//        modeCtrl->run_time_16 = 0;
//        modeCtrl->run_circle_16 = 0;
//    }
//}
//
//
//static void set_mode_runtime_max(_mode_ctrl * modeCtrl,uint16_t max_time){
//    modeCtrl->max_run_time_u16 = max_time;
//    modeCtrl->run_time_16++;
//    modeCtrl->run_time_16 %= modeCtrl->max_run_time_u16;
//
//    if (modeCtrl->run_time_16 % 100== 0) modeCtrl->run_circle_16++;
//    modeCtrl->run_circle_16 %= 1000;
//}
//
//
//static void set_mode_pwm(_mode_ctrl * modeCtrl, uint8_t pwmx,uint8_t rg,bool open_pwm){
//
//    uint32_t color1 = BLACK;
//    uint32_t color2 = BLACK;
//    uint32_t color3 = BLACK;
//    uint8_t rb_index = modeCtrl->run_time_16 /(modeCtrl->max_run_time_u16/3);
//    uint8_t index = modeCtrl->run_time_16 / 1000;
//
//    if (open_pwm == true) {
//        color1 = COLOR_SEQUENCE[index];
//    }
//
//    switch (pwmx) {
//        case USE_RGBW1:
//            color2 = COLOR_SEQUENCE[index];
//            break;
//        case USE_RGBW2:
//            color3 = COLOR_SEQUENCE[index];
//            break;
//        case USE_RGB1_RGBW2:
//            color3 = COLOR_SEQUENCE[index];
//            color2 = COLOR_SEQUENCE[index];
//            break;
//        default:
//            break;
//    }
//
//    switch (rg) {
//        case USE_RG:
//            if (rb_index == 0) {
//                set_rg(true,false);
//            } else if (rb_index == 1) {
//                set_rg(false,true);
//            } else if (rb_index == 2){
//                set_rg(true,true);
//            }
//            break;
//        case USE_NONE_RG:
//            set_rg(false,false);
//            break;
//        default:
//            break;
//    }
//
//
//    set_rgbwx(color1,color2,color3);
//
//}
//
//static void set_mode_pwm_color(_mode_ctrl * modeCtrl, uint8_t pwmx,uint8_t rg,bool open_pwm,uint32_t color){
//
//    uint32_t color1 = BLACK;
//    uint32_t color2 = BLACK;
//    uint32_t color3 = BLACK;
//    uint8_t rb_index = modeCtrl->run_time_16 /(modeCtrl->max_run_time_u16/3);
//    uint8_t index = modeCtrl->run_time_16 / 1000;
//
//    if (open_pwm == true) {
//        if (color != 0) {
//            color1 = color;
//
//        }else{
//            color1 = COLOR_SEQUENCE[index];
//        }
//    }
//
//    switch (pwmx) {
//        case USE_RGBW1:
//            color2 = COLOR_SEQUENCE[(index + 1) % 7];
//            break;
//        case USE_RGBW2:
//            color3 = COLOR_SEQUENCE[(index + 2) % 7];
//            break;
//        case USE_RGB1_RGBW2:
//            color3 = COLOR_SEQUENCE[(index + 2) % 7];
//            color2 = COLOR_SEQUENCE[(index + 1) % 7];
//            break;
//        default:
//            break;
//    }
//
//    switch (rg) {
//        case USE_RG:
//            if (rb_index == 0) {
//                set_rg(true,false);
//            } else if (rb_index == 1) {
//                set_rg(false,true);
//            } else if (rb_index == 2){
//                set_rg(true,true);
//            }
//            break;
//        case USE_NONE_RG:
//            set_rg(false,false);
//            break;
//        default:
//            break;
//    }
//
//
//    set_rgbwx(color1,color2,color3);
//
//}
//
//static void set_mode_store_pwm(_mode_ctrl * modeCtrl,uint8_t brighting,uint8_t pwmx,uint8_t rg){
//    modeCtrl->store_time_16 = GetSystemRunTime();
//    if (modeCtrl->store_time_16 >= modeCtrl->store_next_time_16) {
//        modeCtrl->store_next_time_16 = modeCtrl->store_time_16 + (((10 - brighting) * 5) + 30);
//        modeCtrl->store_light_time_16 =
//                modeCtrl->store_time_16 +( (((10 - brighting) * 5) + 30) / 3);
//    }
//
//
//    if (modeCtrl->store_time_16 < modeCtrl->store_light_time_16) {
//        set_mode_pwm(&mode_use, pwmx, rg, true);
//    } else {
//        set_mode_pwm(&mode_use, pwmx, rg, false);
//    }
//}
//
//static void set_mode_store_interval_pwm(_mode_ctrl * modeCtrl,uint8_t brighting ,uint16_t min_interval ,uint16_t keep_time,uint8_t light_pwmx,uint8_t light_rg,uint8_t dart_pwmx,uint8_t dart_rg){
//    if (modeCtrl->run_circle_16 > min_interval && modeCtrl->run_circle_16 <= keep_time) {
//        modeCtrl->store_time_16 = GetSystemRunTime();
//        if (modeCtrl->store_time_16 >= modeCtrl->store_next_time_16) {
//            modeCtrl->store_next_time_16 = modeCtrl->store_time_16 + (((10 - brighting) * 5) + 30);
//            modeCtrl->store_light_time_16 =
//                    modeCtrl->store_time_16 +( (((10 - brighting) * 5) + 30) / 3);
//        }
//
//
//        if (modeCtrl->store_time_16 < modeCtrl->store_light_time_16) {
//            set_mode_pwm_color(&mode_use, light_pwmx, light_rg, true,WHITE);
//        } else {
//            set_mode_pwm_color(&mode_use, dart_pwmx, dart_rg, false,BLACK);
//        }
//    }
//
//}
//
//uint32_t net_time = 0;
//uint32_t start_time = 0;
////static uint8_t store_speed[] = { 0, 140, 130, 120, 110, 0, 0, 0, 0, 50,40};
void sys_fun_a1xx()
{
    fun_set_rg_store(&mode_use, 0, 1000, 0, true, false);
    fun_set_rg_store(&mode_use, 1001, 2000, 0, true, true);
    fun_set_rg_store(&mode_use, 2001, 3000, 0, false, true);
    fun_set_rg_store(&mode_use, 3001, 3500, 0, true, false);
    fun_set_rg_store(&mode_use, 3501, 4000, 0, false, true);
    fun_set_rg_store(&mode_use, 4001, 4500, 0, true, true);

    fun_set_rgbw0_store(&mode_use, 0, mode_use.max_run_time_u16, 0, 0, 0, 0, 0);
    fun_set_rgbw1_store(&mode_use, 0, mode_use.max_run_time_u16, 0, 0, 0, 0, 0);
    fun_set_rgbw2_store(&mode_use, 0, mode_use.max_run_time_u16, 0, 0, 0, 0, 0);

}


void sys_fun_a2xx()
{
    fun_set_rg_store(&mode_use, 0, mode_use.max_run_time_u16, 0, false, false);
    fun_set_rgbw2_store(&mode_use, 0, mode_use.max_run_time_u16, 0, 0, 0, 0, 0);
    fun_set_rgbw0_store(&mode_use, 0, mode_use.max_run_time_u16, 0, 0, 0, 0, 0);

    fun_set_rgbw1_store(&mode_use, 0, 500, 0, 255, 0, 0, 0);
    fun_set_rgbw1_store(&mode_use, 501, 1000, 0, 0, 255, 0, 0);
    fun_set_rgbw1_store(&mode_use, 1001, 1500, 0, 0, 0, 255, 0);
    fun_set_rgbw1_store(&mode_use, 1501, 2000, 0, 0, 0, 0, 255);
    fun_set_rgbw1_store(&mode_use, 2001, 2500, 0, 255, 255, 0, 0);
    fun_set_rgbw1_store(&mode_use, 2501, 3000, 0, 255, 0, 255, 0);
    fun_set_rgbw1_store(&mode_use, 3001, 3500, 0, 0, 255, 255, 0);
    fun_set_rgbw1_store(&mode_use, 3501, 4000, 0, 255, 255, 255, 255);
}

void sys_fun_a3xx(){
    fun_set_rg_store(&mode_use, 0, mode_use.max_run_time_u16, 0, false, false);
    fun_set_rgbw1_store(&mode_use, 0, mode_use.max_run_time_u16, 0, 0, 0, 0, 0);
    fun_set_rgbw0_store(&mode_use, 0, mode_use.max_run_time_u16, 0, 0, 0, 0, 0);

    fun_set_rgbw2_store(&mode_use, 0, 500, 0, 255, 0, 0, 0);
    fun_set_rgbw2_store(&mode_use, 501, 1000, 0, 0, 255, 0, 0);
    fun_set_rgbw2_store(&mode_use, 1001, 1500, 0, 0, 0, 255, 0);
    fun_set_rgbw2_store(&mode_use, 1501, 2000, 0, 0, 0, 0, 255);
    fun_set_rgbw2_store(&mode_use, 2001, 2500, 0, 255, 255, 0, 0);
    fun_set_rgbw2_store(&mode_use, 2501, 3000, 0, 255, 0, 255, 0);
    fun_set_rgbw2_store(&mode_use, 3001, 3500, 0, 0, 255, 255, 0);
    fun_set_rgbw2_store(&mode_use, 3501, 4000, 0, 255, 255, 255, 255);
}
void sys_fun_a4xx(){
    fun_set_rg_store(&mode_use, 0, mode_use.max_run_time_u16, 0, false, false);
    fun_set_rgbw1_store(&mode_use, 0, mode_use.max_run_time_u16, 0, 0, 0, 0, 0);
    fun_set_rgbw2_store(&mode_use, 0, mode_use.max_run_time_u16, 0, 0, 0, 0, 0);

    fun_set_rgbw0_store(&mode_use, 0, 500, 0, 255, 0, 0, 0);
    fun_set_rgbw0_store(&mode_use, 501, 1000, 0, 0, 255, 0, 0);
    fun_set_rgbw0_store(&mode_use, 1001, 1500, 0, 0, 0, 255, 0);
    fun_set_rgbw0_store(&mode_use, 1501, 2000, 0, 0, 0, 0, 255);
    fun_set_rgbw0_store(&mode_use, 2001, 2500, 0, 255, 255, 0, 0);
    fun_set_rgbw0_store(&mode_use, 2501, 3000, 0, 255, 0, 255, 0);
    fun_set_rgbw0_store(&mode_use, 3001, 3500, 0, 0, 255, 255, 0);
    fun_set_rgbw0_store(&mode_use, 3501, 4000, 0, 255, 255, 255, 255);
}

void sys_fun_a5xx(){
    fun_set_rg_store(&mode_use, 0, 1000, 0, true, false);
    fun_set_rg_store(&mode_use, 1001, 2000, 0, true, true);
    fun_set_rg_store(&mode_use, 2001, 3000, 0, false, true);
    fun_set_rg_store(&mode_use, 3001, 3500, 0, true, false);
    fun_set_rg_store(&mode_use, 3501, 4000, 0, false, true);
    fun_set_rg_store(&mode_use, 4001, 4500, 0, true, true);

    fun_set_rgbw0_store(&mode_use, 0, mode_use.max_run_time_u16, 0, 0, 0, 0, 0);
    fun_set_rgbw2_store(&mode_use, 0, mode_use.max_run_time_u16, 0, 0, 0, 0, 0);

    fun_set_rgbw1_store(&mode_use, 0, 500, 0, 255, 0, 0, 0);
    fun_set_rgbw1_store(&mode_use, 501, 1000, 0, 0, 255, 0, 0);
    fun_set_rgbw1_store(&mode_use, 1001, 1500, 0, 0, 0, 255, 0);
    fun_set_rgbw1_store(&mode_use, 1501, 2000, 0, 0, 0, 0, 255);
    fun_set_rgbw1_store(&mode_use, 2001, 2200, 60, 255, 0, 0, 0);
    fun_set_rgbw1_store(&mode_use, 2201, 2500, 120, 255, 0, 0, 255);
    fun_set_rgbw1_store(&mode_use, 2501, 3000, 0, 255, 255, 0, 0);
    fun_set_rgbw1_store(&mode_use, 3001, 3500, 0, 255, 0, 255, 0);
    fun_set_rgbw1_store(&mode_use, 3501, 4000, 0, 0, 255, 255, 0);
    fun_set_rgbw1_store(&mode_use, 4001, 4500, 240, 255, 255, 255, 255);
}

void sys_fun_a6xx(){
    fun_set_rg_store(&mode_use, 0, 1000, 0, true, false);
    fun_set_rg_store(&mode_use, 1001, 2000, 0, true, true);
    fun_set_rg_store(&mode_use, 2001, 3000, 0, false, true);
    fun_set_rg_store(&mode_use, 3001, 3500, 0, true, false);
    fun_set_rg_store(&mode_use, 3501, 4000, 0, false, true);
    fun_set_rg_store(&mode_use, 4001, 4500, 0, true, true);

    fun_set_rgbw0_store(&mode_use, 0, mode_use.max_run_time_u16, 0, 0, 0, 0, 0);
    fun_set_rgbw1_store(&mode_use, 0, mode_use.max_run_time_u16, 0, 0, 0, 0, 0);

    fun_set_rgbw2_store(&mode_use, 0, 500, 0, 255, 0, 0, 0);
    fun_set_rgbw2_store(&mode_use, 501, 1000, 0, 0, 255, 0, 0);
    fun_set_rgbw2_store(&mode_use, 1001, 1500, 0, 0, 0, 255, 0);
    fun_set_rgbw2_store(&mode_use, 1501, 2000, 0, 0, 0, 0, 255);
    fun_set_rgbw2_store(&mode_use, 2001, 2200, 60, 255, 0, 0, 0);
    fun_set_rgbw2_store(&mode_use, 2201, 2500, 120, 255, 0, 0, 255);
    fun_set_rgbw2_store(&mode_use, 2501, 3000, 0, 255, 255, 0, 0);
    fun_set_rgbw2_store(&mode_use, 3001, 3500, 0, 255, 0, 255, 0);
    fun_set_rgbw2_store(&mode_use, 3501, 4000, 0, 0, 255, 255, 0);
    fun_set_rgbw2_store(&mode_use, 4001, 4500, 240, 255, 255, 255, 255);
}

void sys_fun_a7xx(){
    fun_set_rg_store(&mode_use, 0, 1000, 0, true, false);
    fun_set_rg_store(&mode_use, 1001, 2000, 0, true, true);
    fun_set_rg_store(&mode_use, 2001, 3000, 0, false, true);
    fun_set_rg_store(&mode_use, 3001, 3500, 0, true, false);
    fun_set_rg_store(&mode_use, 3501, 4000, 0, false, true);
    fun_set_rg_store(&mode_use, 4001, 4500, 0, true, true);

    fun_set_rgbw2_store(&mode_use, 0, mode_use.max_run_time_u16, 0, 0, 0, 0, 0);
    fun_set_rgbw1_store(&mode_use, 0, mode_use.max_run_time_u16, 0, 0, 0, 0, 0);

    fun_set_rgbw0_store(&mode_use, 0, 500, 0, 255, 0, 0, 0);
    fun_set_rgbw0_store(&mode_use, 501, 1000, 0, 0, 255, 0, 0);
    fun_set_rgbw0_store(&mode_use, 1001, 1500, 0, 0, 0, 255, 0);
    fun_set_rgbw0_store(&mode_use, 1501, 2000, 0, 0, 0, 0, 255);
    fun_set_rgbw0_store(&mode_use, 2001, 2200, 60, 255, 0, 0, 0);
    fun_set_rgbw0_store(&mode_use, 2201, 2500, 120, 255, 0, 0, 255);
    fun_set_rgbw0_store(&mode_use, 2501, 3000, 0, 255, 255, 0, 0);
    fun_set_rgbw0_store(&mode_use, 3001, 3500, 0, 255, 0, 255, 0);
    fun_set_rgbw0_store(&mode_use, 3501, 4000, 0, 0, 255, 255, 0);
    fun_set_rgbw0_store(&mode_use, 4001, 4500, 240, 255, 255, 255, 255);
}

void sys_fun_a8xx(){
    fun_set_rg_store(&mode_use, 0, 1000, 0, true, false);
    fun_set_rg_store(&mode_use, 1001, 2000, 0, true, true);
    fun_set_rg_store(&mode_use, 2001, 3000, 0, false, true);
    fun_set_rg_store(&mode_use, 3001, 3500, 0, true, false);
    fun_set_rg_store(&mode_use, 3501, 4000, 0, false, true);
    fun_set_rg_store(&mode_use, 4001, 4500, 0, true, true);

    fun_set_rgbw1_store(&mode_use, 0, mode_use.max_run_time_u16, 0, 0, 0, 0, 0);

    fun_set_rgbw0_store(&mode_use, 0, 500, 0, 0, 0, 255, 0);
    fun_set_rgbw0_store(&mode_use, 501, 1000, 0, 0, 0, 0, 255);
    fun_set_rgbw0_store(&mode_use, 1001, 1500, 0, 255, 0, 0, 0);
    fun_set_rgbw0_store(&mode_use, 1501, 2000, 0, 0, 255, 0, 0);
    fun_set_rgbw0_store(&mode_use, 2001, 2200, 60, 0, 255, 255, 0);
    fun_set_rgbw0_store(&mode_use, 2201, 2500, 120, 255, 255, 0, 0);
    fun_set_rgbw0_store(&mode_use, 2501, 3000, 0, 255, 0, 255, 0);
    fun_set_rgbw0_store(&mode_use, 3001, 3500, 0, 0, 255, 255, 0);
    fun_set_rgbw0_store(&mode_use, 3501, 4000, 0, 255, 255, 255, 255);
    fun_set_rgbw0_store(&mode_use, 4001, 4500, 240, 0, 255, 0, 0);


    fun_set_rgbw2_store(&mode_use, 0, 500, 60, 255, 0, 0, 0);
    fun_set_rgbw2_store(&mode_use, 501, 1000, 0, 0, 255, 0, 0);
    fun_set_rgbw2_store(&mode_use, 1001, 1500, 0, 0, 0, 255, 0);
    fun_set_rgbw2_store(&mode_use, 1501, 2000, 60, 0, 0, 0, 255);
    fun_set_rgbw2_store(&mode_use, 2001, 2200, 0, 255, 0, 0, 0);
    fun_set_rgbw2_store(&mode_use, 2201, 2500, 120, 255, 0, 0, 255);
    fun_set_rgbw2_store(&mode_use, 2501, 3000, 0, 255, 255, 0, 0);
    fun_set_rgbw2_store(&mode_use, 3001, 3500, 0, 255, 0, 255, 0);
    fun_set_rgbw2_store(&mode_use, 3501, 4000, 0, 0, 255, 255, 0);
    fun_set_rgbw2_store(&mode_use, 4001, 4500, 80, 255, 255, 255, 255);
}

void sys_fun_a9xx(){
    fun_set_rg_store(&mode_use, 0, 1000, 0, true, false);
    fun_set_rg_store(&mode_use, 1001, 2000, 0, true, true);
    fun_set_rg_store(&mode_use, 2001, 3000, 0, false, true);
    fun_set_rg_store(&mode_use, 3001, 3500, 0, true, false);
    fun_set_rg_store(&mode_use, 3501, 4000, 0, false, true);
    fun_set_rg_store(&mode_use, 4001, 4500, 0, true, true);

    fun_set_rgbw2_store(&mode_use, 0, mode_use.max_run_time_u16, 0, 0, 0, 0, 0);

    fun_set_rgbw0_store(&mode_use, 0, 500, 0, 0, 0, 255, 0);
    fun_set_rgbw0_store(&mode_use, 501, 1000, 0, 0, 0, 0, 255);
    fun_set_rgbw0_store(&mode_use, 1001, 1500, 0, 255, 0, 0, 0);
    fun_set_rgbw0_store(&mode_use, 1501, 2000, 0, 0, 255, 0, 0);
    fun_set_rgbw0_store(&mode_use, 2001, 2200, 60, 0, 255, 255, 0);
    fun_set_rgbw0_store(&mode_use, 2201, 2500, 120, 255, 255, 0, 0);
    fun_set_rgbw0_store(&mode_use, 2501, 3000, 0, 255, 0, 255, 0);
    fun_set_rgbw0_store(&mode_use, 3001, 3500, 0, 0, 255, 255, 0);
    fun_set_rgbw0_store(&mode_use, 3501, 4000, 0, 255, 255, 255, 255);
    fun_set_rgbw0_store(&mode_use, 4001, 4500, 240, 0, 255, 0, 0);


    fun_set_rgbw1_store(&mode_use, 0, 500, 60, 255, 0, 0, 0);
    fun_set_rgbw1_store(&mode_use, 501, 1000, 0, 0, 255, 0, 0);
    fun_set_rgbw1_store(&mode_use, 1001, 1500, 0, 0, 0, 255, 0);
    fun_set_rgbw1_store(&mode_use, 1501, 2000, 60, 0, 0, 0, 255);
    fun_set_rgbw1_store(&mode_use, 2001, 2200, 0, 255, 0, 0, 0);
    fun_set_rgbw1_store(&mode_use, 2201, 2500, 120, 255, 0, 0, 255);
    fun_set_rgbw1_store(&mode_use, 2501, 3000, 0, 255, 255, 0, 0);
    fun_set_rgbw1_store(&mode_use, 3001, 3500, 0, 255, 0, 255, 0);
    fun_set_rgbw1_store(&mode_use, 3501, 4000, 0, 0, 255, 255, 0);
    fun_set_rgbw1_store(&mode_use, 4001, 4500, 80, 255, 255, 255, 255);
}

void sys_fun_aaxx(){

    fun_set_rg_store(&mode_use, 0, 1000, 0, true, false);
    fun_set_rg_store(&mode_use, 1001, 2000, 0, true, true);
    fun_set_rg_store(&mode_use, 2001, 3000, 0, false, true);
    fun_set_rg_store(&mode_use, 3001, 3500, 0, true, false);
    fun_set_rg_store(&mode_use, 3501, 4000, 0, false, true);
    fun_set_rg_store(&mode_use, 4001, 4500, 0, true, true);
    fun_set_rgbw0_store(&mode_use, 0, mode_use.max_run_time_u16, 0, 0, 0, 0, 0);

    fun_set_rgbw2_store(&mode_use, 0, 500, 0, 255, 0, 0, 0);
    fun_set_rgbw2_store(&mode_use, 501, 1000, 0, 0, 255, 0, 0);
    fun_set_rgbw2_store(&mode_use, 1001, 1500, 0, 0, 0, 255, 0);
    fun_set_rgbw2_store(&mode_use, 1501, 2000, 0, 0, 0, 0, 255);
    fun_set_rgbw2_store(&mode_use, 2001, 2200, 60, 255, 0, 0, 0);
    fun_set_rgbw2_store(&mode_use, 2201, 2500, 120, 255, 0, 0, 255);
    fun_set_rgbw2_store(&mode_use, 2501, 3000, 0, 255, 255, 0, 0);
    fun_set_rgbw2_store(&mode_use, 3001, 3500, 0, 255, 0, 255, 0);
    fun_set_rgbw2_store(&mode_use, 3501, 4000, 0, 0, 255, 255, 0);
    fun_set_rgbw2_store(&mode_use, 4001, 4500, 240, 0, 255, 255, 0);

    fun_set_rgbw1_store(&mode_use, 0, 500, 0, 0, 0, 255, 0);
    fun_set_rgbw1_store(&mode_use, 501, 1000, 0, 0, 0, 0, 255);
    fun_set_rgbw1_store(&mode_use, 1001, 1500, 0, 255, 0, 0, 0);
    fun_set_rgbw1_store(&mode_use, 1501, 2000, 0, 0, 255, 0, 0);
    fun_set_rgbw1_store(&mode_use, 2001, 2200, 60, 0, 255, 255, 0);
    fun_set_rgbw1_store(&mode_use, 2201, 2500, 120, 255, 255, 0, 0);
    fun_set_rgbw1_store(&mode_use, 2501, 3000, 0, 255, 0, 255, 0);
    fun_set_rgbw1_store(&mode_use, 3001, 3500, 0, 0, 255, 255, 0);
    fun_set_rgbw1_store(&mode_use, 3501, 4000, 0, 255, 255, 255, 255);
    fun_set_rgbw1_store(&mode_use, 4001, 4500, 240, 0, 255, 0, 0);

}
void sys_fun_abxx(){
    fun_set_rg_store(&mode_use, 0, 1000, 0, true, false);
    fun_set_rg_store(&mode_use, 1001, 2000, 0, true, true);
    fun_set_rg_store(&mode_use, 2001, 3000, 0, false, true);
    fun_set_rg_store(&mode_use, 3001, 3500, 0, true, false);
    fun_set_rg_store(&mode_use, 3501, 4000, 0, false, true);
    fun_set_rg_store(&mode_use, 4001, 4500, 0, true, true);


    fun_set_rgbw2_store(&mode_use, 0, 500, 0, 255, 0, 0, 0);
    fun_set_rgbw2_store(&mode_use, 501, 1000, 0, 0, 0, 0, 0);
    fun_set_rgbw2_store(&mode_use, 1001, 1500, 0, 0, 255, 0, 0);
    fun_set_rgbw2_store(&mode_use, 1501, 2000, 0, 0, 0, 0, 0);
    fun_set_rgbw2_store(&mode_use, 2001, 2200, 0, 0, 0, 255, 0);
    fun_set_rgbw2_store(&mode_use, 2201, 2500, 0, 0, 0, 0, 0);
    fun_set_rgbw2_store(&mode_use, 2501, 3000, 0, 0, 0, 0, 255);
    fun_set_rgbw2_store(&mode_use, 3001, 3500, 0, 0, 0, 0, 0);
    fun_set_rgbw2_store(&mode_use, 3501, 4000, 0, 255, 255, 0, 0);
    fun_set_rgbw2_store(&mode_use, 4001, 4500, 0, 0, 0, 0, 0);
    fun_set_rgbw2_store(&mode_use, 4501, 5000, 0, 255, 0, 255, 0);
    fun_set_rgbw2_store(&mode_use, 5001, 5500, 0, 0, 0, 0, 0);
    fun_set_rgbw2_store(&mode_use, 5501, 6000, 0, 0, 255, 255, 0);
    fun_set_rgbw2_store(&mode_use, 6001, 6500, 0, 0, 0, 0, 0);



    fun_set_rgbw1_store(&mode_use, 0, 500, 0, 0, 0, 0, 0);
    fun_set_rgbw1_store(&mode_use, 501, 1000, 0, 255, 0, 0, 0);
    fun_set_rgbw1_store(&mode_use, 1001, 1500, 0, 0, 0, 0, 0);
    fun_set_rgbw1_store(&mode_use, 1501, 2000, 0, 0, 255, 0, 0);
    fun_set_rgbw1_store(&mode_use, 2001, 2200, 0, 0, 0, 0, 0);
    fun_set_rgbw1_store(&mode_use, 2201, 2500, 0, 0, 0, 255, 0);
    fun_set_rgbw1_store(&mode_use, 2501, 3000, 0, 0, 0, 0, 0);
    fun_set_rgbw1_store(&mode_use, 3001, 3500, 0, 0, 0, 0, 255);
    fun_set_rgbw1_store(&mode_use, 3501, 4000, 0, 0, 0, 0, 0);
    fun_set_rgbw1_store(&mode_use, 4001, 4500, 0, 255, 255, 0, 0);
    fun_set_rgbw1_store(&mode_use, 4501, 5000, 0, 0, 0, 0, 0);
    fun_set_rgbw1_store(&mode_use, 5001, 5500, 0, 255, 0, 255, 0);
    fun_set_rgbw1_store(&mode_use, 5501, 6000, 0, 0, 0, 0, 0);
    fun_set_rgbw1_store(&mode_use, 6001, 6500, 0, 0, 255, 255, 0);

    fun_set_rgbw0_store(&mode_use, 0, 500, 0, 0, 0, 0, 0);
    fun_set_rgbw0_store(&mode_use, 501, 1000, 0, 0, 0, 0, 0);
    fun_set_rgbw0_store(&mode_use, 1001, 1500, 60, 255, 255, 255, 255);
    fun_set_rgbw0_store(&mode_use, 1501, 2000, 60, 255, 255, 255, 255);
    fun_set_rgbw0_store(&mode_use, 2001, 2200, 0, 0, 0, 0, 0);
    fun_set_rgbw0_store(&mode_use, 2201, 2500, 0, 0, 0, 0, 0);
    fun_set_rgbw0_store(&mode_use, 2501, 3000, 0, 0, 0, 0, 0);
    fun_set_rgbw0_store(&mode_use, 3001, 3500, 60, 255, 255, 255, 255);
    fun_set_rgbw0_store(&mode_use, 3501, 4000, 0, 0, 0, 0, 0);
    fun_set_rgbw0_store(&mode_use, 4001, 4500, 0, 0, 0, 0, 0);
    fun_set_rgbw0_store(&mode_use, 4501, 5000, 480, 255, 255, 255, 0);
    fun_set_rgbw0_store(&mode_use, 5001, 5500, 0, 0, 0, 0, 0);
    fun_set_rgbw0_store(&mode_use, 5501, 6000, 60, 255, 255, 255, 255);
    fun_set_rgbw0_store(&mode_use, 6001, 6500, 0, 0, 0, 0, 0);
}

void sys_fun_acxx(){
    fun_set_rg_store(&mode_use, 0, 1000, 0, true, false);
    fun_set_rg_store(&mode_use, 1001, 2000, 0, true, true);
    fun_set_rg_store(&mode_use, 2001, 3000, 0, false, true);
    fun_set_rg_store(&mode_use, 3001, 3500, 0, true, false);
    fun_set_rg_store(&mode_use, 3501, 4000, 0, false, true);
    fun_set_rg_store(&mode_use, 4001, 4500, 0, true, true);


    fun_set_rgbw2_store(&mode_use, 0, 500, 0, 255, 0, 0, 0);
    fun_set_rgbw2_store(&mode_use, 501, 1000, 0, 0, 0, 0, 0);
    fun_set_rgbw2_store(&mode_use, 1001, 1500, 0, 0, 255, 0, 0);
    fun_set_rgbw2_store(&mode_use, 1501, 2000, 0, 0, 0, 0, 0);
    fun_set_rgbw2_store(&mode_use, 2001, 2200, 0, 0, 0, 255, 0);
    fun_set_rgbw2_store(&mode_use, 2201, 2500, 0, 0, 0, 0, 0);
    fun_set_rgbw2_store(&mode_use, 2501, 3000, 0, 0, 0, 0, 255);
    fun_set_rgbw2_store(&mode_use, 3001, 3500, 0, 0, 0, 0, 0);
    fun_set_rgbw2_store(&mode_use, 3501, 4000, 0, 255, 255, 0, 0);
    fun_set_rgbw2_store(&mode_use, 4001, 4500, 0, 0, 0, 0, 0);
    fun_set_rgbw2_store(&mode_use, 4501, 5000, 0, 255, 0, 255, 0);
    fun_set_rgbw2_store(&mode_use, 5001, 5500, 0, 0, 0, 0, 0);
    fun_set_rgbw2_store(&mode_use, 5501, 6000, 0, 0, 255, 255, 0);
    fun_set_rgbw2_store(&mode_use, 6001, 6500, 0, 0, 0, 0, 0);



    fun_set_rgbw1_store(&mode_use, 0, 500, 0, 0, 0, 0, 0);
    fun_set_rgbw1_store(&mode_use, 501, 1000, 0, 255, 0, 0, 0);
    fun_set_rgbw1_store(&mode_use, 1001, 1500, 0, 0, 0, 0, 0);
    fun_set_rgbw1_store(&mode_use, 1501, 2000, 0, 0, 255, 0, 0);
    fun_set_rgbw1_store(&mode_use, 2001, 2200, 0, 0, 0, 0, 0);
    fun_set_rgbw1_store(&mode_use, 2201, 2500, 0, 0, 0, 255, 0);
    fun_set_rgbw1_store(&mode_use, 2501, 3000, 0, 0, 0, 0, 0);
    fun_set_rgbw1_store(&mode_use, 3001, 3500, 0, 0, 0, 0, 255);
    fun_set_rgbw1_store(&mode_use, 3501, 4000, 0, 0, 0, 0, 0);
    fun_set_rgbw1_store(&mode_use, 4001, 4500, 0, 255, 255, 0, 0);
    fun_set_rgbw1_store(&mode_use, 4501, 5000, 0, 0, 0, 0, 0);
    fun_set_rgbw1_store(&mode_use, 5001, 5500, 0, 255, 0, 255, 0);
    fun_set_rgbw1_store(&mode_use, 5501, 6000, 0, 0, 0, 0, 0);
    fun_set_rgbw1_store(&mode_use, 6001, 6500, 0, 0, 255, 255, 0);

    fun_set_rgbw0_store(&mode_use, 0, 500, 0, 0, 0, 0, 0);
    fun_set_rgbw0_store(&mode_use, 501, 1000, 0, 0, 0, 0, 0);
    fun_set_rgbw0_store(&mode_use, 1001, 1500, 0, 255, 255, 255, 255);
    fun_set_rgbw0_store(&mode_use, 1501, 2000, 0, 255, 255, 255, 255);
    fun_set_rgbw0_store(&mode_use, 2001, 2200, 0, 0, 0, 0, 0);
    fun_set_rgbw0_store(&mode_use, 2201, 2500, 0, 0, 0, 0, 0);
    fun_set_rgbw0_store(&mode_use, 2501, 3000, 0, 0, 0, 0, 0);
    fun_set_rgbw0_store(&mode_use, 3001, 3500, 0, 255, 255, 255, 255);
    fun_set_rgbw0_store(&mode_use, 3501, 4000, 0, 0, 0, 0, 0);
    fun_set_rgbw0_store(&mode_use, 4001, 4500, 0, 0, 0, 0, 0);
    fun_set_rgbw0_store(&mode_use, 4501, 5000, 0, 255, 255, 255, 0);
    fun_set_rgbw0_store(&mode_use, 5001, 5500, 0, 0, 0, 0, 0);
    fun_set_rgbw0_store(&mode_use, 5501, 6000, 60, 255, 255, 255, 255);
    fun_set_rgbw0_store(&mode_use, 6001, 6500, 0, 0, 0, 0, 0);

}

void sys_fun_adxx(){
    fun_set_rg_store(&mode_use, 0, 1000, 0, true, false);
    fun_set_rg_store(&mode_use, 1001, 2000, 0, true, true);
    fun_set_rg_store(&mode_use, 2001, 3000, 0, false, true);
    fun_set_rg_store(&mode_use, 3001, 3500, 0, true, false);
    fun_set_rg_store(&mode_use, 3501, 4000, 0, false, true);
    fun_set_rg_store(&mode_use, 4001, 4500, 0, true, true);


    fun_set_rgbw2_store(&mode_use, 0, 500, 0, 255, 0, 0, 0);
    fun_set_rgbw2_store(&mode_use, 501, 1000, 0, 0, 0, 0, 0);
    fun_set_rgbw2_store(&mode_use, 1001, 1500, 0, 0, 0, 0, 0);

    fun_set_rgbw2_store(&mode_use, 1501, 2000, 0, 0, 255, 0, 0);
    fun_set_rgbw2_store(&mode_use, 2001, 2200, 0, 0, 0, 0, 0);
    fun_set_rgbw2_store(&mode_use, 2201, 2500, 0, 0, 0, 0, 0);

    fun_set_rgbw2_store(&mode_use, 2501, 3000, 0, 0, 0, 255, 0);
    fun_set_rgbw2_store(&mode_use, 3001, 3500, 0, 0, 0, 0, 0);
    fun_set_rgbw2_store(&mode_use, 3501, 4000, 0, 0, 0, 0, 0);

    fun_set_rgbw2_store(&mode_use, 4001, 4500, 0, 0, 255, 255, 0);
    fun_set_rgbw2_store(&mode_use, 4501, 5000, 0, 0, 0, 0, 0);
    fun_set_rgbw2_store(&mode_use, 5001, 5500, 0, 0, 0, 0, 0);

    fun_set_rgbw2_store(&mode_use, 5501, 6000, 0, 255, 0, 255, 0);
    fun_set_rgbw2_store(&mode_use, 6001, 6500, 0, 0, 0, 0, 0);
    fun_set_rgbw2_store(&mode_use, 6501, 7000, 0, 0, 0, 0, 0);

    fun_set_rgbw2_store(&mode_use, 7001, 7500, 0, 255, 255, 0, 0);
    fun_set_rgbw2_store(&mode_use, 7501, 8000, 0, 0, 0, 0, 0);
    fun_set_rgbw2_store(&mode_use, 8001, 8500, 0, 0, 0, 0, 0);

    fun_set_rgbw2_store(&mode_use, 8501, 9000, 0, 255, 255, 255, 255);
    fun_set_rgbw2_store(&mode_use, 9001, 9500, 0, 0, 0, 0, 0);
    fun_set_rgbw2_store(&mode_use, 9501, 10000, 0, 0, 0, 0, 0);




    fun_set_rgbw1_store(&mode_use, 0, 500, 0, 0, 255, 255, 0);
    fun_set_rgbw1_store(&mode_use, 501, 1000, 0, 0, 0, 0, 0);
    fun_set_rgbw1_store(&mode_use, 1001, 1500, 0, 0, 0, 0, 0);

    fun_set_rgbw1_store(&mode_use, 1501, 2000, 0, 255, 255, 0, 0);
    fun_set_rgbw1_store(&mode_use, 2001, 2200, 0, 0, 0, 0, 0);
    fun_set_rgbw1_store(&mode_use, 2201, 2500, 0, 0, 0, 0, 0);

    fun_set_rgbw1_store(&mode_use, 2501, 3000, 0, 255, 0, 255, 0);
    fun_set_rgbw1_store(&mode_use, 3001, 3500, 0, 0, 0, 0, 0);
    fun_set_rgbw1_store(&mode_use, 3501, 4000, 0, 0, 0, 0, 0);

    fun_set_rgbw1_store(&mode_use, 4001, 4500, 0, 0, 255, 0, 0);
    fun_set_rgbw1_store(&mode_use, 4501, 5000, 0, 0, 0, 0, 0);
    fun_set_rgbw1_store(&mode_use, 5001, 5500, 0, 0, 0, 0, 0);

    fun_set_rgbw1_store(&mode_use, 5501, 6000, 0, 0, 0, 255, 0);
    fun_set_rgbw1_store(&mode_use, 6001, 6500, 0, 0, 0, 0, 0);
    fun_set_rgbw1_store(&mode_use, 6501, 7000, 0, 0, 0, 0, 0);

    fun_set_rgbw1_store(&mode_use, 7001, 7500, 0, 255, 0, 0, 0);
    fun_set_rgbw1_store(&mode_use, 7501, 8000, 0, 0, 0, 0, 0);
    fun_set_rgbw1_store(&mode_use, 8001, 8500, 0, 0, 0, 0, 0);

    fun_set_rgbw1_store(&mode_use, 8501, 9000, 0, 255, 255, 255, 255);
    fun_set_rgbw1_store(&mode_use, 9001, 9500, 0, 0, 0, 0, 0);
    fun_set_rgbw1_store(&mode_use, 9501, 10000, 0, 0, 0, 0, 0);

    fun_set_rgbw0_store(&mode_use, 0, 500, 0, 0, 0, 0, 0);
    fun_set_rgbw0_store(&mode_use, 501, 1000, 0, 0, 0, 0, 0);
    fun_set_rgbw0_store(&mode_use, 1001, 1500, 0, 0, 255, 255, 0);

    fun_set_rgbw0_store(&mode_use, 1501, 2000, 0, 0, 0, 0, 0);
    fun_set_rgbw0_store(&mode_use, 2001, 2200, 0, 0, 0, 0, 0);
    fun_set_rgbw0_store(&mode_use, 2201, 2500, 0, 255, 255, 0, 0);

    fun_set_rgbw0_store(&mode_use, 2501, 3000, 0, 0, 0, 0, 0);
    fun_set_rgbw0_store(&mode_use, 3001, 3500, 0, 0, 0, 0, 0);
    fun_set_rgbw0_store(&mode_use, 3501, 4000, 0, 255, 0, 255, 0);

    fun_set_rgbw0_store(&mode_use, 4001, 4500, 0, 0, 0, 0, 0);
    fun_set_rgbw0_store(&mode_use, 4501, 5000, 0, 0, 0, 0, 0);
    fun_set_rgbw0_store(&mode_use, 5001, 5500, 0, 0, 0, 255, 0);

    fun_set_rgbw0_store(&mode_use, 5501, 6000, 0, 0, 0, 0, 0);
    fun_set_rgbw0_store(&mode_use, 6001, 6500, 0, 0, 0, 0, 0);
    fun_set_rgbw0_store(&mode_use, 6501, 7000, 0, 0, 255, 0, 0);

    fun_set_rgbw0_store(&mode_use, 7001, 7500, 0, 0, 0, 0, 0);
    fun_set_rgbw0_store(&mode_use, 7501, 8000, 0, 0, 0, 0, 0);
    fun_set_rgbw0_store(&mode_use, 8001, 8500, 0, 255, 0, 0, 0);

    fun_set_rgbw0_store(&mode_use, 8501, 9000, 0, 0, 0, 0, 0);
    fun_set_rgbw0_store(&mode_use, 9001, 9500, 0, 0, 0, 0, 0);
    fun_set_rgbw0_store(&mode_use, 9501, 10000, 0, 255, 255, 255, 255);
}

void sys_fun_aexx(){
    fun_set_rg_store(&mode_use, 0, 1000, 0, true, false);
    fun_set_rg_store(&mode_use, 1001, 2000, 0, true, true);
    fun_set_rg_store(&mode_use, 2001, 3000, 0, false, true);
    fun_set_rg_store(&mode_use, 3001, 3500, 0, true, false);
    fun_set_rg_store(&mode_use, 3501, 4000, 0, false, true);
    fun_set_rg_store(&mode_use, 4001, 4500, 0, true, true);


    fun_set_rgbw2_store(&mode_use, 0, 500, 0, 255, 0, 0, 0);
    fun_set_rgbw2_store(&mode_use, 501, 1000, 0, 0, 0, 0, 0);
    fun_set_rgbw2_store(&mode_use, 1001, 1500, 0, 0, 0, 0, 0);

    fun_set_rgbw2_store(&mode_use, 1501, 2000, 60, 0, 255, 0, 0);
    fun_set_rgbw2_store(&mode_use, 2001, 2200, 0, 0, 0, 0, 0);
    fun_set_rgbw2_store(&mode_use, 2201, 2500, 0, 0, 0, 0, 0);

    fun_set_rgbw2_store(&mode_use, 2501, 3000, 0, 0, 0, 255, 0);
    fun_set_rgbw2_store(&mode_use, 3001, 3500, 0, 0, 0, 0, 0);
    fun_set_rgbw2_store(&mode_use, 3501, 4000, 0, 0, 0, 0, 0);

    fun_set_rgbw2_store(&mode_use, 4001, 4500, 0, 0, 255, 255, 0);
    fun_set_rgbw2_store(&mode_use, 4501, 5000, 0, 0, 0, 0, 0);
    fun_set_rgbw2_store(&mode_use, 5001, 5500, 0, 0, 0, 0, 0);

    fun_set_rgbw2_store(&mode_use, 5501, 6000, 0, 255, 0, 255, 0);
    fun_set_rgbw2_store(&mode_use, 6001, 6500, 0, 0, 0, 0, 0);
    fun_set_rgbw2_store(&mode_use, 6501, 7000, 0, 0, 0, 0, 0);

    fun_set_rgbw2_store(&mode_use, 7001, 7500, 0, 255, 255, 0, 0);
    fun_set_rgbw2_store(&mode_use, 7501, 8000, 0, 0, 0, 0, 0);
    fun_set_rgbw2_store(&mode_use, 8001, 8500, 0, 0, 0, 0, 0);

    fun_set_rgbw2_store(&mode_use, 8501, 9000, 0, 255, 255, 255, 255);
    fun_set_rgbw2_store(&mode_use, 9001, 9500, 0, 0, 0, 0, 0);
    fun_set_rgbw2_store(&mode_use, 9501, 10000, 0, 0, 0, 0, 0);




    fun_set_rgbw1_store(&mode_use, 0, 500, 0, 0, 0, 0, 0);
    fun_set_rgbw1_store(&mode_use, 501, 1000, 0, 255, 255, 255, 255);
    fun_set_rgbw1_store(&mode_use, 1001, 1500, 0, 0, 0, 0, 0);

    fun_set_rgbw1_store(&mode_use, 1501, 2000, 0, 0, 0, 0, 0);
    fun_set_rgbw1_store(&mode_use, 2001, 2200, 0, 255, 255, 0, 0);
    fun_set_rgbw1_store(&mode_use, 2201, 2500, 0, 0, 0, 0, 0);

    fun_set_rgbw1_store(&mode_use, 2501, 3000, 0, 0, 0, 0, 0);
    fun_set_rgbw1_store(&mode_use, 3001, 3500, 0, 255, 0, 255, 0);
    fun_set_rgbw1_store(&mode_use, 3501, 4000, 0, 0, 0, 0, 0);

    fun_set_rgbw1_store(&mode_use, 4001, 4500, 0, 0, 0, 0, 0);
    fun_set_rgbw1_store(&mode_use, 4501, 5000, 60, 0, 255, 255, 0);
    fun_set_rgbw1_store(&mode_use, 5001, 5500, 0, 0, 0, 0, 0);

    fun_set_rgbw1_store(&mode_use, 5501, 6000, 0, 0, 0, 0, 0);
    fun_set_rgbw1_store(&mode_use, 6001, 6500, 0, 0, 0, 255, 0);
    fun_set_rgbw1_store(&mode_use, 6501, 7000, 0, 0, 0, 0, 0);

    fun_set_rgbw1_store(&mode_use, 7001, 7500, 0, 0, 0, 0, 0);
    fun_set_rgbw1_store(&mode_use, 7501, 8000, 0, 0, 255, 0, 0);
    fun_set_rgbw1_store(&mode_use, 8001, 8500, 0, 0, 0, 0, 0);

    fun_set_rgbw1_store(&mode_use, 8501, 9000, 0, 0, 0, 0, 0);
    fun_set_rgbw1_store(&mode_use, 9001, 9500, 0, 255, 0, 0, 0);
    fun_set_rgbw1_store(&mode_use, 9501, 10000, 0, 0, 0, 0, 0);

    fun_set_rgbw0_store(&mode_use, 0, 500, 0, 0, 0, 0, 0);
    fun_set_rgbw0_store(&mode_use, 501, 1000, 0, 0, 0, 0, 0);
    fun_set_rgbw0_store(&mode_use, 1001, 1500, 0, 0, 255, 255, 0);

    fun_set_rgbw0_store(&mode_use, 1501, 2000, 0, 0, 0, 0, 0);
    fun_set_rgbw0_store(&mode_use, 2001, 2200, 0, 0, 0, 0, 0);
    fun_set_rgbw0_store(&mode_use, 2201, 2500, 0, 255, 255, 0, 0);

    fun_set_rgbw0_store(&mode_use, 2501, 3000, 0, 0, 0, 0, 0);
    fun_set_rgbw0_store(&mode_use, 3001, 3500, 0, 0, 0, 0, 0);
    fun_set_rgbw0_store(&mode_use, 3501, 4000, 0, 255, 0, 255, 0);

    fun_set_rgbw0_store(&mode_use, 4001, 4500, 0, 0, 0, 0, 0);
    fun_set_rgbw0_store(&mode_use, 4501, 5000, 0, 0, 0, 0, 0);
    fun_set_rgbw0_store(&mode_use, 5001, 5500, 0, 0, 0, 255, 0);

    fun_set_rgbw0_store(&mode_use, 5501, 6000, 0, 0, 0, 0, 0);
    fun_set_rgbw0_store(&mode_use, 6001, 6500, 0, 0, 0, 0, 0);
    fun_set_rgbw0_store(&mode_use, 6501, 7000, 0, 0, 255, 0, 0);

    fun_set_rgbw0_store(&mode_use, 7001, 7500, 0, 0, 0, 0, 0);
    fun_set_rgbw0_store(&mode_use, 7501, 8000, 0, 0, 0, 0, 0);
    fun_set_rgbw0_store(&mode_use, 8001, 8500, 0, 255, 0, 0, 0);

    fun_set_rgbw0_store(&mode_use, 8501, 9000, 0, 0, 0, 0, 0);
    fun_set_rgbw0_store(&mode_use, 9001, 9500, 0, 0, 0, 0, 0);
    fun_set_rgbw0_store(&mode_use, 9501, 10000, 60, 255, 255, 255, 255);
}

void sys_fun_afxx(){
    fun_set_rg_store(&mode_use, 0, 1000, 0, true, false);
    fun_set_rg_store(&mode_use, 1001, 2000, 0, true, true);
    fun_set_rg_store(&mode_use, 2001, 3000, 0, false, true);
    fun_set_rg_store(&mode_use, 3001, 3500, 0, true, false);
    fun_set_rg_store(&mode_use, 3501, 4000, 0, false, true);
    fun_set_rg_store(&mode_use, 4001, 4500, 0, true, true);


    fun_set_rgbw2_store(&mode_use, 0, 500, 0, 255, 0, 0, 0);
    fun_set_rgbw2_store(&mode_use, 501, 1000, 0, 0, 0, 0, 0);
    fun_set_rgbw2_store(&mode_use, 1001, 1500, 0, 0, 0, 0, 0);

    fun_set_rgbw2_store(&mode_use, 1501, 2000, 60, 0, 255, 0, 0);
    fun_set_rgbw2_store(&mode_use, 2001, 2200, 0, 0, 0, 0, 0);
    fun_set_rgbw2_store(&mode_use, 2201, 2500, 0, 0, 0, 0, 0);

    fun_set_rgbw2_store(&mode_use, 2501, 3000, 0, 0, 0, 255, 0);
    fun_set_rgbw2_store(&mode_use, 3001, 3500, 0, 0, 0, 0, 0);
    fun_set_rgbw2_store(&mode_use, 3501, 4000, 0, 0, 0, 0, 0);

    fun_set_rgbw2_store(&mode_use, 4001, 4500, 0, 0, 255, 255, 0);
    fun_set_rgbw2_store(&mode_use, 4501, 5000, 0, 0, 0, 0, 0);
    fun_set_rgbw2_store(&mode_use, 5001, 5500, 0, 0, 0, 0, 0);

    fun_set_rgbw2_store(&mode_use, 5501, 6000, 0, 255, 0, 255, 0);
    fun_set_rgbw2_store(&mode_use, 6001, 6500, 0, 0, 0, 0, 0);
    fun_set_rgbw2_store(&mode_use, 6501, 7000, 0, 0, 0, 0, 0);

    fun_set_rgbw2_store(&mode_use, 7001, 7500, 0, 255, 255, 0, 0);
    fun_set_rgbw2_store(&mode_use, 7501, 8000, 0, 0, 0, 0, 0);
    fun_set_rgbw2_store(&mode_use, 8001, 8500, 0, 0, 0, 0, 0);

    fun_set_rgbw2_store(&mode_use, 8501, 9000, 0, 255, 255, 255, 255);
    fun_set_rgbw2_store(&mode_use, 9001, 9500, 0, 0, 0, 0, 0);
    fun_set_rgbw2_store(&mode_use, 9501, 10000, 0, 0, 0, 0, 0);




    fun_set_rgbw1_store(&mode_use, 0, 500, 0, 0, 0, 0, 0);
    fun_set_rgbw1_store(&mode_use, 501, 1000, 0, 255, 255, 255, 255);
    fun_set_rgbw1_store(&mode_use, 1001, 1500, 0, 0, 0, 0, 0);

    fun_set_rgbw1_store(&mode_use, 1501, 2000, 0, 0, 0, 0, 0);
    fun_set_rgbw1_store(&mode_use, 2001, 2200, 0, 255, 255, 0, 0);
    fun_set_rgbw1_store(&mode_use, 2201, 2500, 0, 0, 0, 0, 0);

    fun_set_rgbw1_store(&mode_use, 2501, 3000, 0, 0, 0, 0, 0);
    fun_set_rgbw1_store(&mode_use, 3001, 3500, 0, 255, 0, 255, 0);
    fun_set_rgbw1_store(&mode_use, 3501, 4000, 0, 0, 0, 0, 0);

    fun_set_rgbw1_store(&mode_use, 4001, 4500, 0, 0, 0, 0, 0);
    fun_set_rgbw1_store(&mode_use, 4501, 5000, 60, 0, 255, 255, 0);
    fun_set_rgbw1_store(&mode_use, 5001, 5500, 0, 0, 0, 0, 0);

    fun_set_rgbw1_store(&mode_use, 5501, 6000, 0, 0, 0, 0, 0);
    fun_set_rgbw1_store(&mode_use, 6001, 6500, 0, 0, 0, 255, 0);
    fun_set_rgbw1_store(&mode_use, 6501, 7000, 0, 0, 0, 0, 0);

    fun_set_rgbw1_store(&mode_use, 7001, 7500, 0, 0, 0, 0, 0);
    fun_set_rgbw1_store(&mode_use, 7501, 8000, 0, 0, 255, 0, 0);
    fun_set_rgbw1_store(&mode_use, 8001, 8500, 0, 0, 0, 0, 0);

    fun_set_rgbw1_store(&mode_use, 8501, 9000, 0, 0, 0, 0, 0);
    fun_set_rgbw1_store(&mode_use, 9001, 9500, 0, 255, 0, 0, 0);
    fun_set_rgbw1_store(&mode_use, 9501, 10000, 0, 0, 0, 0, 0);

    fun_set_rgbw0_store(&mode_use, 0, 500, 0, 0, 0, 0, 0);
    fun_set_rgbw0_store(&mode_use, 501, 1000, 0, 0, 0, 0, 0);
    fun_set_rgbw0_store(&mode_use, 1001, 1500, 0, 0, 255, 255, 0);

    fun_set_rgbw0_store(&mode_use, 1501, 2000, 0, 0, 0, 0, 0);
    fun_set_rgbw0_store(&mode_use, 2001, 2200, 0, 0, 0, 0, 0);
    fun_set_rgbw0_store(&mode_use, 2201, 2500, 0, 255, 255, 0, 0);

    fun_set_rgbw0_store(&mode_use, 2501, 3000, 0, 0, 0, 0, 0);
    fun_set_rgbw0_store(&mode_use, 3001, 3500, 0, 0, 0, 0, 0);
    fun_set_rgbw0_store(&mode_use, 3501, 4000, 0, 255, 0, 255, 0);

    fun_set_rgbw0_store(&mode_use, 4001, 4500, 0, 0, 0, 0, 0);
    fun_set_rgbw0_store(&mode_use, 4501, 5000, 0, 0, 0, 0, 0);
    fun_set_rgbw0_store(&mode_use, 5001, 5500, 0, 255, 255, 255, 255);

    fun_set_rgbw0_store(&mode_use, 5501, 6000, 0, 0, 0, 0, 0);
    fun_set_rgbw0_store(&mode_use, 6001, 6500, 0, 0, 0, 0, 0);
    fun_set_rgbw0_store(&mode_use, 6501, 7000, 60, 255, 255, 255, 255);

    fun_set_rgbw0_store(&mode_use, 7001, 7500, 0, 0, 0, 0, 0);
    fun_set_rgbw0_store(&mode_use, 7501, 8000, 0, 0, 0, 0, 0);
    fun_set_rgbw0_store(&mode_use, 8001, 8500, 0, 255, 255, 255, 255);

    fun_set_rgbw0_store(&mode_use, 8501, 9000, 0, 0, 0, 0, 0);
    fun_set_rgbw0_store(&mode_use, 9001, 9500, 0, 0, 0, 0, 0);
    fun_set_rgbw0_store(&mode_use, 9501, 10000, 60, 255, 255, 255, 255);
}

uint8_t mic_array[] = {60, 65, 50, 40, 30, 25, 20, 15, 10, 8};

void sys_fun_suxx(){
    extern uint8_t mic;
    static uint8_t sound_count;
    uint8_t mic_sensitivity = mic_array[ptr->number - 1];
    if (sound_count % 8 == 0) {
        sound_count = 0;
        if (!GPIO_ReadInputDataBit(MIC_GPIO_Port, MIC_Pin)) {
            if (mic >= mic_sensitivity) {
                mic = 0;
                mode_use.mic_time = 0x0FFF;
            } else {
                mic = 0;
            }
        }
    }

    if (mode_use.mic_time > 0) {
        if (ptr == &S1xx) {
            sys_fun_aexx();
        } else if (ptr == &S2xx) {
            sys_fun_afxx();
        }
    }else{
        sys_fun_OOOO_B();
    }
}
void sys_fun_R3xxx_b(){
    fun_set_rgbw0(255, 0, 0,0);
}

void sys_fun_G3xxx_b(){
    fun_set_rgbw0(0, 255, 0,0);
}

void sys_fun_B3xxx_b(){
    fun_set_rgbw0(0, 0, 255,0);
}

void sys_fun_W3xxx_b(){
    fun_set_rgbw0(0, 0, 0,255);
}

void sys_fun_R4xxx_b(){
    fun_set_rgbw0(0, 0, 0,0);
    fun_set_rgbw1(255, 0, 0,0);

}

void sys_fun_G4xxx_b(){
    fun_set_rgbw1(0, 255, 0,0);

}

void sys_fun_B4xxx_b(){
    fun_set_rgbw1(0, 0, 255,0);

}

void sys_fun_W4xxx_b(){
    fun_set_rgbw1(0, 0, 0,255);

}

void sys_fun_R5xxx_b(){
    fun_set_rgbw1(0, 0, 0,0);
    fun_set_rgbw2(255, 0, 0,0);
}

void sys_fun_G5xxx_b(){
    fun_set_rgbw2(0, 255, 0,0);
}

void sys_fun_B5xxx_b(){
    fun_set_rgbw2(0, 0, 255,0);
}

void sys_fun_W5xxx_b(){
    fun_set_rgbw2(0, 0, 0,255);
}

void sys_fun_OOOO_B(){
    fun_set_run_mode(&mode_use, 100, 6500);
    PWM_RG = 0;

    fun_set_rgbw1(0, 0, 0,0);
    fun_set_rgbw0(0, 0, 0,0);
    fun_set_rgbw2(0, 0, 0,0);
    fun_set_rg(false, false);
    WS2812FX_setSpeed(300);
    WS2812FX_setColor(0x000000);
    WS2812FX_setMode_Ref(FX_MODE_STATIC);
}

void sys_fun_Gxxx_b(){
    fun_set_rgbw1(0, 0, 0,0);
    fun_set_rgbw0(0, 0, 0,0);
    fun_set_rgbw2(0, 0, 0,0);

    WS2812FX_setSpeed(300);
    WS2812FX_setColor(0x00FF00);
    WS2812FX_setMode_Ref(FX_MODE_STATIC);
}

void sys_fun_Bxxx_b(){
    fun_set_rgbw1(0, 0, 0,0);
    fun_set_rgbw0(0, 0, 0,0);
    fun_set_rgbw2(0, 0, 0,0);

    WS2812FX_setSpeed(300);
    WS2812FX_setColor(0x0000FF );
    WS2812FX_setMode_Ref(FX_MODE_STATIC);
}

void sys_fun_Rxxx_b(){
    fun_set_rgbw1(0, 0, 0,0);
    fun_set_rgbw0(0, 0, 0,0);
    fun_set_rgbw2(0, 0, 0,0);

    WS2812FX_setSpeed(300);
    WS2812FX_setColor(0xFF0000);
    WS2812FX_setMode_Ref(FX_MODE_STATIC);
}

/*void sys_fun_SPxx_b(){
    fun_set_rgbw1(0, 0, 0,0);
    fun_set_rgbw0(0, 0, 0,0);
    fun_set_rgbw2(0, 0, 0,0);

    WS2812FX_setSpeed(300*(11 - SPxx_b.number));
    WS2812FX_setColor(0xFFFFFF);
    WS2812FX_setMode_Ref(FX_MODE_SCAN);

}*/

void sys_fun_Axxx_Cxxx()
{
    extern uint8_t mic;
    bool save_flag = false;


    if (DMX_State != DMX_IDLE) {
        console_data.console_ir_mode = false;
        // ��̨ģʽ
        if (DMX_RxBuf[0] == CONSOLE_FRAME_HEADER) {
            if (Cxxx.number == SYS_CONSOLE_DIFF_CH){
                if (DMX_RxBuf[27] != 0) {
                    FASpeed = DMX_RxBuf[28];
                    FSpeed = DMX_RxBuf[28];
//                    PWM_RG = MAX * (float) DMX_RxBuf[28] / 255;
                    switch (console_data.console_ch_diff_ch27_mode + 1) {
                        case 1:
                            sys_fun_a1xx();
                            break;
                        case 2:
                            sys_fun_a2xx();

                            break;
                        case 3:
                            sys_fun_a3xx();
                            break;
                        case 4:
                            sys_fun_a4xx();

                            break;
                        case 5:
                            sys_fun_a5xx();

                            break;
                        case 6:
                            sys_fun_a6xx();


                            break;
                        case 7:
                            sys_fun_a7xx();

                            break;
                        case 8:
                            sys_fun_a8xx();

                            break;
                        case 9:
                            sys_fun_a9xx();

                            break;
                        case 10:
                            sys_fun_aaxx();

                            break;
                        case 11:

                            sys_fun_abxx();

                            break;
                        case 12:
                            sys_fun_acxx();

                            break;
                        case 13:
                            sys_fun_adxx();
                            break;
                        case 14:
                            sys_fun_aexx();
                            break;
                        case 15:
                            sys_fun_afxx();
                            break;
                        case 16:
                            static uint8_t sound_count;
                            uint8_t mic_sensitivity = mic_array[console_data.console_ch_diff_sexx_speed];
                            if (sound_count % 8 == 0) {
                                sound_count = 0;
                                if (!GPIO_ReadInputDataBit(MIC_GPIO_Port, MIC_Pin)) {
                                    if (mic >= mic_sensitivity) {
                                        mic = 0;
                                        mode_use.mic_time = 0x0FFF;
                                    } else {
                                        mic = 0;
                                    }
                                }
                            }

                            if (mode_use.mic_time > 0) {
                                sys_fun_aexx();
                            }else{
                                sys_fun_OOOO_B();
                            }
                            break;
                        case 17:
                            static uint8_t sound_count1;
                            uint8_t mic_sensitivity1 = mic_array[console_data.console_ch_diff_sexx_speed];
                            if (sound_count % 8 == 0) {
                                sound_count = 0;
                                if (!GPIO_ReadInputDataBit(MIC_GPIO_Port, MIC_Pin)) {
                                    if (mic >= mic_sensitivity1) {
                                        mic = 0;
                                        mode_use.mic_time = 0x0FFF;
                                    } else {
                                        mic = 0;
                                    }
                                }
                            }

                            if (mode_use.mic_time > 0) {
                                sys_fun_afxx();
                            }else{
                                sys_fun_OOOO_B();
                            }
                            break;
                        default:
                            break;

                    }

                }
                else {

                    fun_set_run_mode(&mode_use, 1,3000);
                    /*** ֱ����� ���̼��ⲿ��  ***/
                    if (DMX_RxBuf[2] == 0) {
                        fun_set_rg(false, false);
                    } else if (DMX_RxBuf[2] < 50) {
                        fun_set_rg(true, false);
                    } else if (DMX_RxBuf[2] < 100) {
                        fun_set_rg(false, true);
                    } else if (DMX_RxBuf[2] < 255) {
                        fun_set_rg(true, true);
                    }

                    PWM_RG = MAX * (float) DMX_RxBuf[3] / 255;
                    /*** ֱ����� ���̼��ⲿ��  ***/

                    /*** Сħ��  ***/

                    fun_set_rgbw1_store(&mode_use, 0, 3000, DMX_RxBuf[8] == 0 ? 0 : (((12 - (DMX_RxBuf[8] / 25)) * 30)),
                                        DMX_RxBuf[4] * DMX_RxBuf[1] / 255,
                                        DMX_RxBuf[5] * DMX_RxBuf[1] / 255,
                                        DMX_RxBuf[6] * DMX_RxBuf[1] / 255,
                                        DMX_RxBuf[7] * DMX_RxBuf[1] / 255);

                    FASpeed = DMX_RxBuf[9];

                    /*** Сħ��  ***/

                    /*** ��ħ��  ***/
                    fun_set_rgbw2_store(&mode_use, 0, 3000, DMX_RxBuf[14] == 0 ? 0 : (((12 - (DMX_RxBuf[14] / 25)) * 30)),
                                        DMX_RxBuf[10] * DMX_RxBuf[1] / 255,
                                        DMX_RxBuf[11] * DMX_RxBuf[1] / 255,
                                        DMX_RxBuf[12] * DMX_RxBuf[1] / 255,
                                        DMX_RxBuf[13] * DMX_RxBuf[1] / 255);

                    FSpeed = DMX_RxBuf[15];   //����ٶ�

                    /*** ��ħ��  ***/

                    /*** Ƶ����  ***/

                    fun_set_rgbw0_store(&mode_use, 0, 3000, DMX_RxBuf[20] == 0 ? 0 : (((12 - (DMX_RxBuf[20] / 25)) * 30)),
                                        DMX_RxBuf[16] * DMX_RxBuf[1] / 255,
                                        DMX_RxBuf[17] * DMX_RxBuf[1] / 255,
                                        DMX_RxBuf[18] * DMX_RxBuf[1] / 255,
                                        DMX_RxBuf[19] * DMX_RxBuf[1] / 255);

                    /*** Ƶ����  ***/

                    /*** �ƴ� ***/

                    if (DMX_RxBuf[25] == 0) {
                        WS2812FX_setSpeed(10);
                        WS2812FX_setMode_Ref(FX_MODE_STATIC);

                        if (DMX_RxBuf[24] == 0) {
                            WS2812FX_setColor((uint32_t)((DMX_RxBuf[21]<<16|DMX_RxBuf[22]<<8|DMX_RxBuf[23])));
                        }else{
                            if ((mode_use.ws2812_run_time % ((12 - (DMX_RxBuf[24] / 25)) * 30)) > (((12 - (DMX_RxBuf[24] / 25)) * 30 / 3))) {
                                WS2812FX_setColor(0x000000);

                            }else{
                                WS2812FX_setColor((uint32_t)((DMX_RxBuf[21]<<16|DMX_RxBuf[22]<<8|DMX_RxBuf[23])));
                            }
                        }

                    }else{
//                        if (DMX_RxBuf[24] == 0) {
//                            WS2812FX_setColor(0xFFFFFF);
//                        }else{
//                            if ((mode_use.ws2812_run_time % ((12 - (DMX_RxBuf[24] / 25)) * 30)) > (((12 - (DMX_RxBuf[24] / 25)) * 30 / 3))) {
//                                WS2812FX_setColor(0x000000);
//
//                            }else{
//                                WS2812FX_setColor(0xFFFFFF);
//                            }
//                        }
                    }

                    /*** �ƴ� ***/



                }
            }
            else if (Cxxx.number == SYS_CONSOLE_EASE_CH) {
                if (DMX_RxBuf[17] != 0) {

                    FASpeed = DMX_RxBuf[18];
                    FSpeed = DMX_RxBuf[18];
//                    PWM_RG = MAX * (float) DMX_RxBuf[18] / 255;
                    switch (console_data.console_ch_ease_ch17_mode + 1) {
                        case 1:
                            sys_fun_a1xx();
                            break;
                        case 2:
                            sys_fun_a2xx();

                            break;
                        case 3:
                            sys_fun_a3xx();
                            break;
                        case 4:
                            sys_fun_a4xx();

                            break;
                        case 5:
                            sys_fun_a5xx();

                            break;
                        case 6:
                            sys_fun_a6xx();


                            break;
                        case 7:
                            sys_fun_a7xx();

                            break;
                        case 8:
                            sys_fun_a8xx();

                            break;
                        case 9:
                            sys_fun_a9xx();

                            break;
                        case 10:
                            sys_fun_aaxx();

                            break;
                        case 11:

                            sys_fun_abxx();

                            break;
                        case 12:
                            sys_fun_acxx();

                            break;
                        case 13:
                            sys_fun_adxx();
                            break;
                        case 14:
                            sys_fun_aexx();
                            break;
                        case 15:
                            sys_fun_afxx();
                            break;
                        case 16:
                            static uint8_t sound_count;
                            uint8_t mic_sensitivity = mic_array[console_data.console_ch_ease_sexx_speed];
                            if (sound_count % 8 == 0) {
                                sound_count = 0;
                                if (!GPIO_ReadInputDataBit(MIC_GPIO_Port, MIC_Pin)) {
                                    if (mic >= mic_sensitivity) {
                                        mic = 0;
                                        mode_use.mic_time = 0x0FFF;
                                    } else {
                                        mic = 0;
                                    }
                                }
                            }

                            if (mode_use.mic_time > 0) {
                                sys_fun_aexx();
                            }else{
                                sys_fun_OOOO_B();
                            }
                            break;
                        case 17:
                            static uint8_t sound_count1;
                            uint8_t mic_sensitivity1 = mic_array[console_data.console_ch_ease_sexx_speed];
                            if (sound_count % 8 == 0) {
                                sound_count = 0;
                                if (!GPIO_ReadInputDataBit(MIC_GPIO_Port, MIC_Pin)) {
                                    if (mic >= mic_sensitivity1) {
                                        mic = 0;
                                        mode_use.mic_time = 0x0FFF;
                                    } else {
                                        mic = 0;
                                    }
                                }
                            }

                            if (mode_use.mic_time > 0) {
                                sys_fun_afxx();
                            }else{
                                sys_fun_OOOO_B();
                            }
                            break;
                        default:
                            break;

                    }

                }
                else {

                    fun_set_run_mode(&mode_use, 50,3000);
                    /*** ֱ����� ���̼��ⲿ��  ***/
                    bool r_flag;
                    bool g_flag;

                    if (DMX_RxBuf[7] == 0) {
                        r_flag = false;
                    }else {
                        r_flag = true;
                    }

                    if (DMX_RxBuf[8] == 0) {
                        g_flag = false;
                    }else {
                        g_flag = true;
                    }


                    fun_set_rg_store(&mode_use, 0, 3000, DMX_RxBuf[2] == 0 ? 0 : (((12 - (DMX_RxBuf[2] / 25)) * 30)),r_flag,g_flag);
                    PWM_RG = MAX * (float) DMX_RxBuf[11] / 255;
                    /*** ֱ����� ���̼��ⲿ��  ***/

                    /*** Сħ��  ***/

                    fun_set_rgbw1_store(&mode_use, 0, 3000, DMX_RxBuf[2] == 0 ? 0 : (((12 - (DMX_RxBuf[2] / 25)) * 30)),
                                        DMX_RxBuf[3] * DMX_RxBuf[1] / 255,
                                        DMX_RxBuf[4] * DMX_RxBuf[1] / 255,
                                        DMX_RxBuf[5] * DMX_RxBuf[1] / 255,
                                        DMX_RxBuf[6] * DMX_RxBuf[1] / 255);

                    FASpeed = DMX_RxBuf[9];

                    /*** Сħ��  ***/

                    /*** ��ħ��  ***/
                    fun_set_rgbw2_store(&mode_use, 0, 3000, DMX_RxBuf[2] == 0 ? 0 : (((12 - (DMX_RxBuf[2] / 25)) * 30)),
                                        DMX_RxBuf[3] * DMX_RxBuf[1] / 255,
                                        DMX_RxBuf[4] * DMX_RxBuf[1] / 255,
                                        DMX_RxBuf[5] * DMX_RxBuf[1] / 255,
                                        DMX_RxBuf[6] * DMX_RxBuf[1] / 255);

                    FSpeed = DMX_RxBuf[10];   //����ٶ�

                    /*** ��ħ��  ***/

                    /*** Ƶ����  ***/

                    fun_set_rgbw0_store(&mode_use, 0, 3000, DMX_RxBuf[2] == 0 ? 0 : (((12 - (DMX_RxBuf[2] / 25)) * 30)),
                                        DMX_RxBuf[3] * DMX_RxBuf[1] / 255,
                                        DMX_RxBuf[4] * DMX_RxBuf[1] / 255,
                                        DMX_RxBuf[5] * DMX_RxBuf[1] / 255,
                                        DMX_RxBuf[6] * DMX_RxBuf[1] / 255);

                    /*** Ƶ����  ***/

                    /*** �ƴ� ***/

                    if (DMX_RxBuf[15] == 0) {
                        WS2812FX_setSpeed(10);
                        WS2812FX_setMode_Ref(FX_MODE_STATIC);

                        if (DMX_RxBuf[2] == 0) {
                            WS2812FX_setColor((uint32_t)((DMX_RxBuf[12]<<16|DMX_RxBuf[13]<<8|DMX_RxBuf[14])));
                        }else{
                            if ((mode_use.ws2812_run_time % ((12 - (DMX_RxBuf[2] / 25)) * 30)) > (((12 - (DMX_RxBuf[2] / 25)) * 30 / 3))) {
                                WS2812FX_setColor(0x000000);

                            }else{
                                WS2812FX_setColor((uint32_t)((DMX_RxBuf[12]<<16|DMX_RxBuf[13]<<8|DMX_RxBuf[14])));
                            }
                        }

                    }else{
//                        if (DMX_RxBuf[2] == 0) {
//                            WS2812FX_setColor(0xFFFFFF);
//                        }else{
//                            if ((mode_use.ws2812_run_time % ((12 - (DMX_RxBuf[2] / 25)) * 30)) > (((12 - (DMX_RxBuf[2] / 25)) * 30 / 3))) {
//                                WS2812FX_setColor(0x000000);
//
//                            }else{
//                                WS2812FX_setColor(0xFFFFFF);
//                            }
//                        }
                    }

                    /*** �ƴ� ***/



                }
            }

        }

        // ����ģʽ
        else if (DMX_RxBuf[0] == MASTER_SLAVE_FRAME_HEADER) {
            extern bool r_temp;
            extern bool g_temp;
            fun_slave_recv_data();
            fun_set_rg(r_temp, g_temp);

        }

        // RMDģʽ
        else if (DMX_RxBuf[0] == RDM_FRAME_HEADER) {
//            if (apm_rdm_dmx512.rx_flag) {
//                rdm_handle_recRDMdata();
//                apm_rdm_dmx512.rx_flag = false;

//            }
        }

        // ��������
        else if (DMX_RxBuf[0] == MASTER_SLAVE_FRAME_SAVE_HEADER) {
            if (DMX_RxBuf[0] == MASTER_SLAVE_FRAME_SAVE_HEADER && DMX_RxBuf[1] == MASTER_SLAVE_FRAME_SAVE_HEADER1 && DMX_RxBuf[2] == MASTER_SLAVE_FRAME_SAVE_HEADER2&&
                    DMX_RxBuf[19] == MASTER_SLAVE_FRAME_SAVE_HEADER2 && DMX_RxBuf[20] == MASTER_SLAVE_FRAME_SAVE_HEADER1&& DMX_RxBuf[21] == MASTER_SLAVE_FRAME_SAVE_HEADER ) {

                save_flag_light = true;

                if (R3xxx_b.number != DMX_RxBuf[3]) {
                    R3xxx_b.number = DMX_RxBuf[3];
                    save_flag = true;
                }

                if (G3xxx_b.number != DMX_RxBuf[4]) {
                    G3xxx_b.number = DMX_RxBuf[4];
                    save_flag = true;

                }

                if (B3xxx_b.number != DMX_RxBuf[5]) {
                    B3xxx_b.number = DMX_RxBuf[5];
                    save_flag = true;

                }

                if (W3xxx_b.number != DMX_RxBuf[6]) {
                    W3xxx_b.number = DMX_RxBuf[6];
                    save_flag = true;

                }

                if (R4xxx_b.number != DMX_RxBuf[7]) {
                    R4xxx_b.number = DMX_RxBuf[7];
                    save_flag = true;

                }

                if (G4xxx_b.number != DMX_RxBuf[8]) {
                    G4xxx_b.number = DMX_RxBuf[8];
                    save_flag = true;

                }

                if (B4xxx_b.number != DMX_RxBuf[9]) {
                    B4xxx_b.number = DMX_RxBuf[9];
                    save_flag = true;

                }

                if (W4xxx_b.number != DMX_RxBuf[10]) {
                    W4xxx_b.number = DMX_RxBuf[10];
                    save_flag = true;

                }

                if (R5xxx_b.number != DMX_RxBuf[11]) {
                    R5xxx_b.number = DMX_RxBuf[11];
                    save_flag = true;

                }

                if (G5xxx_b.number != DMX_RxBuf[12]) {
                    G5xxx_b.number = DMX_RxBuf[12];
                    save_flag = true;

                }

                if (B5xxx_b.number != DMX_RxBuf[13]) {
                    B5xxx_b.number = DMX_RxBuf[13];
                    save_flag = true;

                }

                if (W5xxx_b.number != DMX_RxBuf[14]) {
                    W5xxx_b.number = DMX_RxBuf[14];
                    save_flag = true;

                }

                if (Rxxx_b.number != DMX_RxBuf[15]) {
                    Rxxx_b.number = DMX_RxBuf[15];
                    save_flag = true;

                }

                if (Gxxx_b.number != DMX_RxBuf[16]) {
                    Gxxx_b.number = DMX_RxBuf[16];
                    save_flag = true;

                }

                if (Bxxx_b.number != DMX_RxBuf[17]) {
                    Bxxx_b.number = DMX_RxBuf[17];
                    save_flag = true;

                }



                if (IRxx_b.number != DMX_RxBuf[18]) {
                    IRxx_b.number = DMX_RxBuf[18];
                    save_flag = true;

                }



                if (save_flag == true) {
                    flash_write();
                }

            }


 }
    } else {
        console_data.console_ir_mode = true;
        sys_fun_OOOO_B();
    }

}

//void sys_fun_SUxx_SExx(){
//    set_rgbwx(BLACK, BLACK, BLACK);
//    WS2812FX_setSpeed(300);
//    WS2812FX_setColor(0x000000 );
//    WS2812FX_setMode_Ref(FX_MODE_STATIC);
//}
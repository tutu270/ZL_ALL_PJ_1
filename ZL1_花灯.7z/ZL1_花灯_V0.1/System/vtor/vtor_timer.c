#include "vtor_timer.h"

#ifdef __VTOR_TIMER__

// 一直指向所有任务的头，不可更改
struct VtorTimer* vtorTimerHeader = NULL;
static uint32_t VtorTimerTick = 0;
static uint32_t VtorTimerCnt = 0;


void VtorTimer_VoidFun()
{
	
}

void VtorTimer_Schedule(void)
{
	struct VtorTimer* timer = vtorTimerHeader;
	VtorTimerCnt++;
	while (timer && NULL != timer->fun)
	{
		if (VtorTimer_VoidFun != timer->fun)
		{
			if(VTOR_TIMER_STATE_READY == timer->state)
			{
				uint32_t endTime = 0;
				uint32_t startTime = VtorTimer_GetTick();
				timer->state = VTOR_TIMER_STATE_RUNNING;
				timer->fun();
				if(VTOR_TIMER_STATE_RUNNING == timer->state)
				{
					timer->state = VTOR_TIMER_STATE_WAITING;
				}
				timer->runCnt++;
				endTime = VtorTimer_GetTick();
				timer->runTime = endTime - startTime;
			}
		}
		timer++;
	}
}


void VtorTimer_IncTick(uint32_t tick)
{
	struct VtorTimer* timer = vtorTimerHeader;
	VtorTimerTick += tick;
	while (timer && NULL != timer->fun)
	{
		if (VtorTimer_VoidFun != timer->fun)
		{
			if(VTOR_TIMER_STATE_WAITING == timer->state)
			{
				timer->curTime += tick;
				if (timer->curTime >= timer->interval)
				{
					timer->curTime = 0;
					timer->state = VTOR_TIMER_STATE_READY;
				}
			}
		}
		timer++;
	}
}

uint32_t VtorTimer_GetTick(void)
{
	return VtorTimerTick;
}

uint32_t VtorTimer_GetCnt(void)
{
	return VtorTimerCnt;
}

struct VtorTimer* VtorTimer_GetRunningTimer()
{
	struct VtorTimer* timer = vtorTimerHeader;
	while (NULL != timer->fun)
	{
		if(VTOR_TIMER_STATE_RUNNING == timer->state)
		{
			return timer;
		}
		timer++;
	}
	return NULL;
}

struct VtorTimer* VtorTimer_GetTimerByFun(VtorTimerFun fun)
{
	struct VtorTimer* timer = vtorTimerHeader;
	if (NULL == fun)
	{
		return NULL;
	}
	while(NULL != timer->fun)
	{
		if (fun == timer->fun)
		{
			return timer;
		}
		timer++;
	}
	return NULL;
}

struct VtorTimer* VtorTimer_Restart(VtorTimerFun fun, uint32_t interval)
{
	struct VtorTimer* timer = NULL;
	if (NULL == fun)
	{
		return NULL;
	}
	timer = VtorTimer_GetTimerByFun(fun);
	if(NULL == timer)
	{
		timer = VtorTimer_GetTimerByFun(VtorTimer_VoidFun);
		if(NULL == timer)
		{
			return NULL;
		}
		timer->fun = fun;
		timer->state = VTOR_TIMER_STATE_STOP;
	}
	
	//if(VTOR_TIMER_STATE_STOP == timer->state)
	{
		VtorTimer_StartCallback(timer->fun);
		timer->curTime = 0;
		timer->state = VTOR_TIMER_STATE_WAITING;
	}
	timer->interval = interval;
	return timer;
}


struct VtorTimer* VtorTimer_Start(VtorTimerFun fun, uint32_t interval)
{
	struct VtorTimer* timer = NULL;
	if (NULL == fun)
	{
		return NULL;
	}
	timer = VtorTimer_GetTimerByFun(fun);
	if(NULL == timer)
	{
		timer = VtorTimer_GetTimerByFun(VtorTimer_VoidFun);
		if(NULL == timer)
		{
			return NULL;
		}
		timer->fun = fun;
		timer->state = VTOR_TIMER_STATE_STOP;
	}
	
	if(VTOR_TIMER_STATE_STOP == timer->state)
	{
		VtorTimer_StartCallback(timer->fun);
		timer->curTime = 0;
		timer->state = VTOR_TIMER_STATE_WAITING;
	}
	timer->interval = interval;
	return timer;
}

void VtorTimer_RunNow(VtorTimerFun fun)
{
	struct VtorTimer* timer = NULL;
	timer = VtorTimer_GetTimerByFun(fun);

	if(NULL != timer)
	{
		if(fun == timer->fun)
		{
			timer->state = VTOR_TIMER_STATE_READY;
			timer->curTime = 0;
		}
	}
}

void VtorTimer_Delete(VtorTimerFun fun)
{
	struct VtorTimer* timer = NULL;
	timer = VtorTimer_GetTimerByFun(fun);
	if(NULL != timer)
	{
		if (VTOR_TIMER_STATE_STOP != timer->state)
		{
			VtorTimer_StopCallback(fun);
			timer->state = VTOR_TIMER_STATE_STOP;
			timer->fun = VtorTimer_VoidFun;
		}
		timer->runCnt = 0;
		timer->curTime = 0;
	}

}

void VtorTimer_Stop(VtorTimerFun fun)
{
	struct VtorTimer* timer = NULL;
	if (NULL == fun)
	{
		return ;
	}
	timer = VtorTimer_GetTimerByFun(fun);
	if(NULL != timer)
	{
		if (VTOR_TIMER_STATE_STOP != timer->state)
		{
			VtorTimer_StopCallback(fun);
			timer->state = VTOR_TIMER_STATE_STOP;
		}
		timer->curTime = 0;
	}
}

#endif


#ifndef __VTOR_TIMER_H__
#define __VTOR_TIMER_H__

#ifdef __cplusplus
extern "C" {
#endif

#include "vtor_elec_module_config.h"

#ifdef __VTOR_TIMER__

// 定义VTOR定时器状态
#define VTOR_TIMER_STATE_STOP 0 // 停止状态
#define VTOR_TIMER_STATE_START 1 // 开始状态
#define VTOR_TIMER_STATE_WAITING 2 // 等待状态
#define VTOR_TIMER_STATE_READY 3 // 准备状态
#define VTOR_TIMER_STATE_RUNNING 4 // 运行状态

typedef void (*VtorTimerFun)(void);


typedef struct VtorTimer
{
	VtorTimerFun fun; // 将要执行的函数
	uint32_t interval;	// 当计次达到interval，执行fun函数
	uint8_t state;		// 状态
	uint32_t curTime;	// 当前计次
	uint32_t runCnt;		// 本函数运行次数
	uint32_t runTime;	// 完成本次任务耗时多久
}VtorTimerStruct;



void VtorTimer_VoidFun(void);

// 一直指向所有任务的头，不可更改
extern struct VtorTimer* vtorTimerHeader;

// 实际任务运行
void VtorTimer_Schedule(void);
// 时间片运行
void VtorTimer_IncTick(uint32_t tick);
void VtorTimer_Init(void);
uint32_t VtorTimer_GetTick(void);
uint32_t VtorTimer_GetCnt(void);
struct VtorTimer* VtorTimer_Restart(VtorTimerFun fun, uint32_t interval);
struct VtorTimer* VtorTimer_Start(VtorTimerFun fun, uint32_t interval);
void VtorTimer_RunNow(VtorTimerFun fun);
void VtorTimer_Stop(VtorTimerFun fun);
void VtorTimer_Delete(VtorTimerFun fun);
struct VtorTimer* VtorTimer_GetRunningTimer(void);
struct VtorTimer* VtorTimer_GetTimerByFun(VtorTimerFun fun);


void VtorTimer_StopCallback(VtorTimerFun fun);
void VtorTimer_StartCallback(VtorTimerFun fun);



#endif

#ifdef __cplusplus
}
#endif

#endif

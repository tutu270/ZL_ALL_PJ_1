#include <stdbool.h>
#include "vtor_timer.h"
#include "digital_tube/TM1650.h"
#include "digital_tube/digital_tube_driver.h"
#include "key/key.h"
#include "menu/menu.h"
#include "ws2812/ws2812_driver.h"
#include "usartx/dmx.h"
#include "decode_433/d_433.h"
#include "Dri_Motor.h"
#include "ws2812/adafruit_neopixel.h"
#include "ws2812/ws2812fx.h"
#include "ws2812/ws2812_fun.h"
#include "usartx/rdm.h"
// 修改成用户的工程宏
#ifdef __USER_PROJECT__
// 加入用户用中需要用到的头文件
// 用户需要执行的函数



//uint8_t a[] = {10, 20, 30, 40, 50, 60, 100, 0};
//uint8_t e[] = {10, 20, 30, 40, 50, 60, 100, 0};
uint16_t _key_adc_value;
void test1()
{
    reset_dmx_r_buf();
    _key_adc_value = tm1650_get_key();
    key_scan(_key_adc_value);
    d_433_scan();
    menu_run();
//    count = TIM_GetCounter(TIM6);  // 获取当前计数值
}

uint8_t flag1 = 1;
uint8_t flag2 = 3;
void test2()
{
    extern Menu_With_Numbers *ptr;
//    ws2812_change_moder();
//    spi1_send_data1();
//    Adafruit_NeoPixel_show();


    if(DMX_RxBuf[0] == MASTER_SLAVE_FRAME_HEADER && ptr == &Axxx){
        Adafruit_NeoPixel_show();
    }else{
        WS2812FX_service();
        if (DMX_RxBuf[0] != RDM_FRAME_HEADER && DMX_RxBuf[0] != MASTER_SLAVE_FRAME_HEADER &&sys_ptr == NULL && rdm_st_count == 60001) {
            fun_master_send_data();
        }
    }

}


void test3(void){
    if (DMX_RxBuf[0] != RDM_FRAME_HEADER  && rdm_st_count == 60001) {
        menu_func_call(ptr);
    } else if ( rdm_st_count < 60000) {
        FDmxPosition = 0;
        FADmxPosition = 0;
        FASpeed = 0;
        FSpeed = 0;
        PWM_RG = 0;
    }
}

struct VtorTimer vtorTimerArray[] =
        {
                {VtorTimer_VoidFun, 50,  0, 0, 0, 0},
                {VtorTimer_VoidFun, 5,  0, 0, 0, 0},
                {VtorTimer_VoidFun, 10, 0, 0, 0, 0},
//		{VtorTimer_VoidFun,				5, 0, 0, 0, 0},
//		{VtorTimer_VoidFun,				0, 0, 0, 0, 0},
//		{VtorTimer_VoidFun,				0, 0, 0, 0, 0},
//		{VtorTimer_VoidFun,				0, 0, 0, 0, 0},
//		 {VtorTimer_VoidFun,				0, 0, 0, 0, 0},
//		{VtorTimer_VoidFun,				0, 0, 0, 0, 0},
//		{VtorTimer_VoidFun,				0, 0, 0, 0, 0},
//		{VtorTimer_VoidFun,				0, 0, 0, 0, 0},
//		{VtorTimer_VoidFun,				0, 0, 0, 0, 0},
//		{VtorTimer_VoidFun,				0, 0, 0, 0, 0},
//		{VtorTimer_VoidFun,				0, 0, 0, 0, 0},
//		{VtorTimer_VoidFun,				0, 0, 0, 0, 0},
                {NULL,              0,  0, 0, 0, 0},
        };

void VtorTimer_Init(void)
{
    vtorTimerHeader = vtorTimerArray;
    VtorTimer_Start(test1, 1);
    VtorTimer_Start(test2, 10);
    VtorTimer_Start(test3, 2);

}

void VtorTimer_StartCallback(VtorTimerFun fun)
{

}

void VtorTimer_StopCallback(VtorTimerFun fun)
{

}

#endif

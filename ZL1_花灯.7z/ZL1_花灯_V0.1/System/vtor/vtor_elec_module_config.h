//#ifdef __ELEC_MODULE_CONFIG_EXAMPLE_H__ // 使用时，注释此行

#ifndef __ELEC_MODULE_CONFIG_H__
#define __ELEC_MODULE_CONFIG_H__

#define __USER_PROJECT__


#ifdef __cplusplus
extern "C" {
#endif


// 头文件包含（一般是c语言标准库头文件）
#include "stdio.h"
#include "stdint.h"
#include "stdlib.h"
#include "string.h"
// include "main.h"

#define ELEC_MODULE_VTOR_TIMER_ENABLED
//#define ELEC_MODULE_VTOR_KEY_ENABLED
//#define ELEC_MODULE_VTOR_MENU_ENABLED
//#define ELEC_MODULE_VTOR_I2C_ENABLED
//#define ELEC_MODULE_VTOR_OLED_ENABLED
//#define ELEC_MODULE_VTOR_SPI_ENABLED
//#define ELEC_MODULE_VTOR_MODBUS_ENABLED
//#define ELEC_MODULE_VTOR_SHELL_ENABLED

#define __VTOR_TIMER__
// 配置的参考例子
// 使用log信息
//#define __OLED_LOG__
// 小ram芯片不使用gram
// GRAM是大部分操作（graph extra）的基础
//#define __OLED_GRAM__

// 提供画线，画圆等函数
// #define __OLED_GRAPH__

// 提供多种字体，非常占空间
// #define __OLED_MULTI_SIZE__

// 提供中文支持，需自行添加字库
// #define __OLED_HZK__

// 提供OLED_Printf，number等函数
// #define __OLED_PRINTF__

// 提供额外函数，画图片，滚动等操作
// #define __OLED_EXTRA__



// 为vtorkey，提供自定义扫描时间间隔
// #ifndef VTOR_KEY_CONFIG_BY_USERSELF
// #define VTOR_KEY_TIME_SHAKE				20
// #define VTOR_KEY_TIME_LONG_DOWN	 		500
// #define VTOR_KEY_TIME_LONG_UP	 		500
// #define VTOR_KEY_TIME_MAX 				1000
// #endif



// vtor_shell
//#define __VTOR_SHELL_GET_TIME_RESERVE__
//#define __VTOR_SHELL_GET_TIME_BY_VTOR_TIMER__
//#define __VTOR_SHELL_GET_TIME_BY_USERSELF__





// vtor_string
//#define __VTOR_STRING_PRINT_RESERVE__
//#define __VTOR_STRING_PRINT_BY_USERSELF__



#ifdef __cplusplus
}
#endif



#endif


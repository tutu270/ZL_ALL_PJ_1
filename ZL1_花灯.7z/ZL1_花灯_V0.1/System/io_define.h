
#ifndef __IO_DEFINE_H
#define __IO_DEFINE_H

#include "stm32f0xx.h"


#define   KEY_DOWN  41
#define   KEY_MENU   11
#define   KEY_SAVE   21
#define   KEY_UP   31


#define TIM1650_CLK_Pin GPIO_Pin_2
#define TIM1650_CLK_GPIO_Port GPIOB

#define TIM1650_DAT_Pin GPIO_Pin_3
#define TIM1650_DAT_GPIO_Port GPIOB

#define MIC_Pin GPIO_Pin_5
#define MIC_GPIO_Port GPIOA

#define  PWMB    TIM1->CCR2
#define  PWMW    TIM1->CCR1
#define  PWMR    TIM1->CCR4
#define  PWMG    TIM1->CCR3

#define  PWMR1    TIM2->CCR1
#define  PWMG1    TIM2->CCR2
#define  PWMB1    TIM2->CCR3
#define  PWMW1    TIM2->CCR4


#define  PWMR2    TIM3->CCR1
#define  PWMG2    TIM3->CCR2
#define  PWMB2    TIM3->CCR3
#define  PWMW2    TIM3->CCR4


#define G_EN                        GPIOC->BSRR = (1 << 13)
#define G_DISEN                     GPIOC->BRR = (1 << 13)

#define R_EN                        GPIOC->BSRR = (1 << 14)
#define R_DISEN                     GPIOC->BRR = (1 << 14)

#define  PWM_RG    TIM14->CCR1
//#define  PWM_RG    TIM16->CCR1 //G


#define  FAN_1    TIM17->CCR1//R

#endif
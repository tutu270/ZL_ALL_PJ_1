#include <stdint.h>
#include <stdbool.h>
#include "key.h"
#include "io_define.h"

#define ADC_SAMPLES 5  // �������Ǵ洢�����10��ADC����ֵ
#define ADC_STABLE_THRESHOLD 1  // �����ȶ�����ֵ��200����λ




Key key1 = KEY_INIT(KEY_MENU, KEY_MENU, Released);
Key key2 = KEY_INIT(KEY_UP, KEY_UP, Released);
Key key3 = KEY_INIT(KEY_DOWN, KEY_DOWN, Released);
Key key4 = KEY_INIT(KEY_SAVE, KEY_SAVE, Released);
Key *key_arr[] = {&key1, &key2, &key3, &key4};
bool can_single_long_press_true = true;

int adc_samples[ADC_SAMPLES];
int adc_index = 0;
int adc_sum = 0;
int adc_count = 0;
int adc_stable_value = 0;

static void key_set_key_mode()
{

    uint8_t i = 0;
    for (i = 0; i < 4; i++) {


        if (key_arr[i]->key_pressed_time >= 50) {
            key_arr[i]->key_mode = longPress;
            key_arr[i]->key_pressed_time = 0;
        } else if (key_arr[i]->key_pressed_time >= 1 && key_arr[i]->key_state == Released) {
            key_arr[i]->key_mode = shortPress;
            key_arr[i]->key_pressed_time = 0;
        }

    }

}



void key_scan(uint16_t adc)
{
    int new_sample = adc;  // ��ȡADC�ĵ�ǰֵ
    uint8_t i = 0;
    adc_samples[adc_index] = new_sample;
    adc_sum += new_sample;
    adc_count++;
    adc_index = (adc_index + 1) % ADC_SAMPLES;  // ѭ������

    if (adc_count >= ADC_SAMPLES) {
        int min_value = adc_samples[0];
        int max_value = adc_samples[0];
        for ( i = 1; i < ADC_SAMPLES; i++) {
            if (adc_samples[i] < min_value) {
                min_value = adc_samples[i];
            }
            if (adc_samples[i] > max_value) {
                max_value = adc_samples[i];
            }
        }

        // ����������������ȶ���Χ�ڣ������ƽ��ֵ
        if (max_value - min_value <= ADC_STABLE_THRESHOLD) {
            adc_stable_value = adc_sum / ADC_SAMPLES;
            // �����������ȶ���ADCֵ��ִ����������
            for (i = 0; i < 4; i++) {
                if (adc_stable_value >= key_arr[i]->key_adc_value_min && adc_stable_value <= key_arr[i]->key_adc_value_max) {
                    key_arr[i]->key_count = 0;
                    if (key_arr[i]->key_mode != noPress) return;
                    key_arr[i]->key_state = Pressed;
                    key_arr[i]->key_pressed_time++;
                } else {
                    if (key_arr[i]->key_count > 1) {
                        key_arr[i]->key_state = Released;
                        if (key_arr[i]->key_mode == longPress) {
                            key_arr[i]->key_mode = noPress;
                        }
                    } else {
                        key_arr[i]->key_count++;
                    }

                }
            }
            key_set_key_mode();
        }

        adc_sum = 0;
        adc_count = 0;
    }
}






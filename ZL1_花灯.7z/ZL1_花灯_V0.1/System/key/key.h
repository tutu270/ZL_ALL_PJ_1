#ifndef _KEY_H
#define _KEY_H

#define Released  0
#define Pressed   1

#define noPress   0
#define longPress  1
#define shortPress 2
#define continuous_longPress 3

typedef struct {
    uint8_t key_adc_value_min;   //����adc��Сֵ
    uint8_t key_adc_value_max;   //����adc���ֵ
    uint8_t key_state;
    uint8_t key_pressed_time;
    uint8_t key_mode;
    uint8_t key_count;
} Key;

// ��ʼ������
#define KEY_INIT(min, max, state) { \
    (min),     \
    (max),     \
    (state),           \
     0,          \
     0,                  \
     0                  \
}

extern bool can_single_long_press_true;
void key_scan(uint16_t adc);



#endif

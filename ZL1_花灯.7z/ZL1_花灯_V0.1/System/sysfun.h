
#include <stdint.h>
#include <stdbool.h>

#ifndef HUADENG_SYSFUN_H
#define HUADENG_SYSFUN_H
//typedef struct  mode_ctrl
//{
//    uint8_t mode;
//    uint16_t run_time_16;
//    uint16_t max_run_time_u16;
//    uint16_t run_circle_16;
//    uint32_t store_time_16;
//    uint32_t store_next_time_16;
//    uint32_t store_light_time_16;
//}_mode_ctrl;
void sys_fun_a1xx();
void sys_fun_a2xx();
void sys_fun_a3xx();
void sys_fun_a4xx();
void sys_fun_a5xx();
void sys_fun_a6xx();
void sys_fun_a7xx();
void sys_fun_a8xx();
void sys_fun_a9xx();
void sys_fun_aaxx();
void sys_fun_abxx();
void sys_fun_acxx();
void sys_fun_adxx();
void sys_fun_aexx();
void sys_fun_afxx();
void sys_fun_suxx();
void sys_fun_Axxx_Cxxx();
void sys_fun_SUxx_SExx();
void sys_fun_R3xxx_b();
void sys_fun_G3xxx_b();
void sys_fun_B3xxx_b();
void sys_fun_W3xxx_b();

void sys_fun_R4xxx_b();
void sys_fun_G4xxx_b();
void sys_fun_B4xxx_b();
void sys_fun_W4xxx_b();

void sys_fun_R5xxx_b();
void sys_fun_G5xxx_b();
void sys_fun_B5xxx_b();
void sys_fun_W5xxx_b();

void sys_fun_Rxxx_b();
void sys_fun_Gxxx_b();
void sys_fun_Bxxx_b();
void sys_fun_OOOO_B();
extern bool save_flag_light;

#endif

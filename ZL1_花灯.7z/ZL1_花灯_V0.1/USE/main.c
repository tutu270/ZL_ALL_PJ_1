#include "stm32f0xx.h"
#include "main.h"
#include "math.h"
#include "arm_math.h"
#include "Dri_Motor.h"
#include "stm32f0xx_tim.h"
#include "stm32f0xx_gpio.h"
#include "stm32f0xx_rcc.h"
#include "stm32f0xx_conf.h"
#include "digital_tube/TM1650.h"
#include "digital_tube/digital_tube_driver.h"
#include "menu/menu.h"
#include "key/key.h"
#include "vtor/vtor_timer.h"
#include "iwdg/iwdg.h"
//#include "ws2812/ws2812_driver.h"
//#include "ws2812/ws2812_fun.h"
#include "usartx/dmx.h"
#include "i_flash/flash.h"
//#include "decode_433/d_433.h"
#include "io_define.h"
#include "usartx/rdm.h"
#include "fun.h"
#include "decode_433/d_433.h"
#include "ws2812/ws2812_driver.h"
#include "ws2812/ws2812_fun.h"
//#include "ws2812/adafruit_neopixel.h"
//#include "ws2812/ws2812fx.h"

#if 1
#pragma import(__use_no_semihosting)
//��׼����Ҫ��֧�ֺ���
struct __FILE {
    int handle;
    /* Whatever you require here. If the only file you are using is */
    /* standard output using printf() for debugging, no file handling */
    /* is required. */
};
/* FILE is typedef�� d in stdio.h. */
FILE __stdout;

//����_sys_exit()�Ա���ʹ�ð�����ģʽ
void _sys_exit(int x)
{
    x = x;
}

//�ض���fputc����
int fputc(int ch, FILE *f)
{
    while (!((USART1->ISR) & (1 << 7))) {}
    USART1->TDR = ch;
    return (ch);
}

extern void Dma_Ea2(void);

#endif
/*************************************************************/

SYSTEM System;


#define APPLICATION_ADDRESS     ((uint32_t)0x08001C00)

void SysTick_Init(void)
{
    /* SystemFrequency / 1000    1ms�ж�һ��
     * SystemFrequency / 100000	 10us�ж�һ��
     * SystemFrequency / 1000000 1us�ж�һ��
     */
//    NVIC_SetPriority(SysTick_IRQn, 3);  // ����Ϊ���ȼ�1

//	if (SysTick_Config(SystemFrequency / 100000))	// ST3.0.0��汾
//    if (SysTick_Config(SystemCoreClock / 10000))     // 100us//  10US ST3.5.0��汾100 20000
    if (SysTick_Config(SystemCoreClock / 5000))     // 100us//  10US ST3.5.0��汾100 20000
    {
        /* Capture error */
        while (1);


    }

//NVIC_SetPriority (SysTick_IRQn, 0X02);



}


void Dri_Time15_Init(void)//2
{

    TIM_TimeBaseInitTypeDef TIM_TimeBaseStructure;
    TIM_OCInitTypeDef TIM_OCInitStructure;
    GPIO_InitTypeDef GPIO_InitStructure;
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_TIM15, ENABLE);


    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_14 | GPIO_Pin_15;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_Level_2;
    GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;

    GPIO_Init(GPIOB, &GPIO_InitStructure);

    GPIO_PinAFConfig(GPIOB, GPIO_PinSource14, GPIO_AF_1);
    GPIO_PinAFConfig(GPIOB, GPIO_PinSource15, GPIO_AF_1);


    TIM_TimeBaseStructure.TIM_Prescaler = 0;
    TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;

    TIM_TimeBaseStructure.TIM_Period = 2399;
    TIM_TimeBaseStructure.TIM_ClockDivision = 0;
    TIM_TimeBaseStructure.TIM_RepetitionCounter = 0;
    TIM_TimeBaseInit(TIM15, &TIM_TimeBaseStructure);

    TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM2;
    TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;
    TIM_OCInitStructure.TIM_OutputNState = TIM_OutputNState_Disable;

    TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_Low;
    TIM_OCInitStructure.TIM_OCNPolarity = TIM_OCNPolarity_High;

    TIM_OCInitStructure.TIM_OCIdleState = TIM_OCIdleState_Set;
    TIM_OCInitStructure.TIM_OCNIdleState = TIM_OCIdleState_Reset;


    TIM_OCInitStructure.TIM_Pulse = 1200;

    TIM_OC1Init(TIM15, &TIM_OCInitStructure);


    TIM_OCInitStructure.TIM_Pulse = 1200;

    TIM_OC2Init(TIM15, &TIM_OCInitStructure);

    TIM_Cmd(TIM15, ENABLE);
    TIM_CtrlPWMOutputs(TIM15, ENABLE);


}

void Dri_Time16_Init(void)//1
{
    TIM_TimeBaseInitTypeDef TIM_TimeBaseStructure;
    TIM_OCInitTypeDef TIM_OCInitStructure;
    GPIO_InitTypeDef GPIO_InitStructure;


    RCC_APB2PeriphClockCmd(RCC_APB2Periph_TIM16, ENABLE);


    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_Level_2;
    GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
    GPIO_Init(GPIOB, &GPIO_InitStructure);
    GPIO_PinAFConfig(GPIOB, GPIO_PinSource8, GPIO_AF_2);


    TIM_TimeBaseStructure.TIM_Prescaler = 0;
    TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;


    TIM_TimeBaseStructure.TIM_Period = 2399;
    TIM_TimeBaseStructure.TIM_ClockDivision = 0;
    TIM_TimeBaseStructure.TIM_RepetitionCounter = 0;
    TIM_TimeBaseInit(TIM16, &TIM_TimeBaseStructure);

    TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM2;
    TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;
    TIM_OCInitStructure.TIM_OutputNState = TIM_OutputNState_Disable;

    TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_Low;
    TIM_OCInitStructure.TIM_OCNPolarity = TIM_OCNPolarity_High;

    TIM_OCInitStructure.TIM_OCIdleState = TIM_OCIdleState_Set;
    TIM_OCInitStructure.TIM_OCNIdleState = TIM_OCIdleState_Reset;


    TIM_OCInitStructure.TIM_Pulse = 1200;

    TIM_OC1Init(TIM16, &TIM_OCInitStructure);


    TIM_Cmd(TIM16, ENABLE);
    TIM_CtrlPWMOutputs(TIM16, ENABLE);


}

void Dri_Time17_Init(void)//1
{


    GPIO_InitTypeDef GPIO_InitStructure;
    TIM_TimeBaseInitTypeDef TIM_TimeBaseStructure;
    TIM_OCInitTypeDef TIM_OCInitStructure;
    NVIC_InitTypeDef NVIC_InitStructure;

    /* GPIOB Clocks enable */
    RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOB, ENABLE);

    /* GPIOB Configuration: Channel 1 as alternate function push-pull */
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
    GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
    GPIO_Init(GPIOB, &GPIO_InitStructure);


    GPIO_PinAFConfig(GPIOB, GPIO_PinSource9, GPIO_AF_2);

    /* TIM17 clock enable */
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_TIM17, ENABLE);

    /* Time Base configuration */
    TIM_TimeBaseStructure.TIM_Period = 2399;
    TIM_TimeBaseStructure.TIM_Prescaler = 0;
    TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;
    TIM_TimeBaseStructure.TIM_ClockDivision = 0;
    TIM_TimeBaseStructure.TIM_RepetitionCounter = 0;

    TIM_TimeBaseInit(TIM17, &TIM_TimeBaseStructure);

    /* Channel 1 Configuration in PWM mode */
    TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1;
    TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;
    TIM_OCInitStructure.TIM_OutputNState = TIM_OutputNState_Disable;

    TIM_OCInitStructure.TIM_Pulse = 1200;
    TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High;
    TIM_OCInitStructure.TIM_OCNPolarity = TIM_OCNPolarity_Low;
    TIM_OCInitStructure.TIM_OCIdleState = TIM_OCIdleState_Set;
    TIM_OCInitStructure.TIM_OCNIdleState = TIM_OCIdleState_Reset;

    TIM_OC1Init(TIM17, &TIM_OCInitStructure);


    /* TIM17 counter enable */
    TIM_Cmd(TIM17, ENABLE);

    /* TIM17 Main Output Enable */
    TIM_CtrlPWMOutputs(TIM17, ENABLE);
}


void Dri_Time1_Init(void)
{


    GPIO_InitTypeDef GPIO_InitStructure;
    TIM_TimeBaseInitTypeDef TIM_TimeBaseStructure;
    TIM_OCInitTypeDef TIM_OCInitStructure;
//	NVIC_InitTypeDef NVIC_InitStructure;

    /* GPIOA Clocks enable */
    RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOA, ENABLE);


    /* GPIOA Configuration: Channel 1, 2, 3 and 4 as alternate function push-pull */
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8 | GPIO_Pin_9 | GPIO_Pin_10 | GPIO_Pin_11;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
    GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
    GPIO_Init(GPIOA, &GPIO_InitStructure);


    GPIO_PinAFConfig(GPIOA, GPIO_PinSource8, GPIO_AF_2);
    GPIO_PinAFConfig(GPIOA, GPIO_PinSource9, GPIO_AF_2);

    GPIO_PinAFConfig(GPIOA, GPIO_PinSource10, GPIO_AF_2);
    GPIO_PinAFConfig(GPIOA, GPIO_PinSource11, GPIO_AF_2);
    /* TIM1 clock enable */
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_TIM1, ENABLE);

    /* Time Base configuration */
    TIM_TimeBaseStructure.TIM_Prescaler = 0;
    TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;
    TIM_TimeBaseStructure.TIM_Period = 2399;
    TIM_TimeBaseStructure.TIM_ClockDivision = 0;
    TIM_TimeBaseStructure.TIM_RepetitionCounter = 0;
    TIM_TimeBaseInit(TIM1, &TIM_TimeBaseStructure);

    TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM2;
    TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;
    TIM_OCInitStructure.TIM_OutputNState = TIM_OutputNState_Disable;

    TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_Low;
    TIM_OCInitStructure.TIM_OCNPolarity = TIM_OCNPolarity_High;

    TIM_OCInitStructure.TIM_OCIdleState = TIM_OCIdleState_Set;
    TIM_OCInitStructure.TIM_OCNIdleState = TIM_OCIdleState_Reset;


    TIM_OCInitStructure.TIM_Pulse = 0;

    TIM_OC1Init(TIM1, &TIM_OCInitStructure);


    TIM_OCInitStructure.TIM_Pulse = 0;

    TIM_OC2Init(TIM1, &TIM_OCInitStructure);


    TIM_OCInitStructure.TIM_Pulse = 0;

    TIM_OC3Init(TIM1, &TIM_OCInitStructure);

    TIM_OCInitStructure.TIM_Pulse = 0;

    TIM_OC4Init(TIM1, &TIM_OCInitStructure);

    TIM_Cmd(TIM1, ENABLE);
    TIM_CtrlPWMOutputs(TIM1, ENABLE);
//TIM_ITConfig(TIM6, TIM_IT_Update, ENABLE);

    /* TIM1 Interrupts enable */
//	TIM_ITConfig(TIM1, TIM_IT_Update, ENABLE);

}

void Dri_Time3_Init(void)
{


    GPIO_InitTypeDef GPIO_InitStructure;
    TIM_TimeBaseInitTypeDef TIM_TimeBaseStructure;
    TIM_OCInitTypeDef TIM_OCInitStructure;
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3, ENABLE);


    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6 | GPIO_Pin_7;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_Level_2;
    GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_Level_2;
    GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
    GPIO_Init(GPIOB, &GPIO_InitStructure);


    GPIO_PinAFConfig(GPIOA, GPIO_PinSource6, GPIO_AF_1);
    GPIO_PinAFConfig(GPIOA, GPIO_PinSource7, GPIO_AF_1);

    GPIO_PinAFConfig(GPIOB, GPIO_PinSource0, GPIO_AF_1);
    GPIO_PinAFConfig(GPIOB, GPIO_PinSource1, GPIO_AF_1);

    TIM_TimeBaseStructure.TIM_Prescaler = 0;
    TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;

    TIM_TimeBaseStructure.TIM_Period = 2399;
    TIM_TimeBaseStructure.TIM_ClockDivision = 0;
    TIM_TimeBaseStructure.TIM_RepetitionCounter = 0;
    TIM_TimeBaseInit(TIM3, &TIM_TimeBaseStructure);

    TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM2;
    TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;
    TIM_OCInitStructure.TIM_OutputNState = TIM_OutputNState_Disable;

    TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_Low;
    TIM_OCInitStructure.TIM_OCNPolarity = TIM_OCNPolarity_High;

    TIM_OCInitStructure.TIM_OCIdleState = TIM_OCIdleState_Set;
    TIM_OCInitStructure.TIM_OCNIdleState = TIM_OCIdleState_Reset;


    TIM_OCInitStructure.TIM_Pulse = 0;
    TIM_OC1Init(TIM3, &TIM_OCInitStructure);


    TIM_OCInitStructure.TIM_Pulse = 0;
    TIM_OC2Init(TIM3, &TIM_OCInitStructure);


    TIM_OCInitStructure.TIM_Pulse = 0;
    TIM_OC3Init(TIM3, &TIM_OCInitStructure);

    TIM_OCInitStructure.TIM_Pulse = 0;
    TIM_OC4Init(TIM3, &TIM_OCInitStructure);

    TIM_Cmd(TIM3, ENABLE);
    TIM_CtrlPWMOutputs(TIM3, ENABLE);


}


void Dri_Time2_Init(void)
{

    TIM_TimeBaseInitTypeDef TIM_TimeBaseStructure;
    TIM_OCInitTypeDef TIM_OCInitStructure;
    GPIO_InitTypeDef GPIO_InitStructure;

    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2, ENABLE);

    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1 | GPIO_Pin_2 | GPIO_Pin_3;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_Level_2;
    GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

    GPIO_PinAFConfig(GPIOA, GPIO_PinSource0, GPIO_AF_2);
    GPIO_PinAFConfig(GPIOA, GPIO_PinSource1, GPIO_AF_2);
    GPIO_PinAFConfig(GPIOA, GPIO_PinSource2, GPIO_AF_2);
    GPIO_PinAFConfig(GPIOA, GPIO_PinSource3, GPIO_AF_2);

    //  PrescalerValue=16384;

    TIM_TimeBaseStructure.TIM_Prescaler = 0;
    TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;
    TIM_TimeBaseStructure.TIM_Period = 2399;
    TIM_TimeBaseStructure.TIM_ClockDivision = 0;
    TIM_TimeBaseStructure.TIM_RepetitionCounter = 0;
    TIM_TimeBaseInit(TIM2, &TIM_TimeBaseStructure);

    TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM2;
    TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;
    TIM_OCInitStructure.TIM_OutputNState = TIM_OutputNState_Disable;

    TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_Low;
    TIM_OCInitStructure.TIM_OCNPolarity = TIM_OCNPolarity_High;

    TIM_OCInitStructure.TIM_OCIdleState = TIM_OCIdleState_Set;
    TIM_OCInitStructure.TIM_OCNIdleState = TIM_OCIdleState_Reset;

    TIM_OCInitStructure.TIM_Pulse = 0;

    TIM_OC1Init(TIM2, &TIM_OCInitStructure);

    TIM_OCInitStructure.TIM_Pulse = 0;

    TIM_OC2Init(TIM2, &TIM_OCInitStructure);

    TIM_OCInitStructure.TIM_Pulse = 0;

    TIM_OC3Init(TIM2, &TIM_OCInitStructure);

    TIM_OCInitStructure.TIM_Pulse = 0;

    TIM_OC4Init(TIM2, &TIM_OCInitStructure);

    TIM_Cmd(TIM2, ENABLE);
    TIM_CtrlPWMOutputs(TIM2, ENABLE);
}

void Dri_Time14_Init(void)//1
{
    TIM_TimeBaseInitTypeDef TIM_TimeBaseStructure;
    TIM_OCInitTypeDef TIM_OCInitStructure;
    GPIO_InitTypeDef GPIO_InitStructure;

    /* TIM3 clock enable */
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM14, ENABLE);

    /* GPIOC clock enable */
//  RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOA | RCC_AHBPeriph_GPIOB, ENABLE);

    /* GPIOA Configuration: TIM3 CH1 (PA6) and TIM3 CH2 (PA7) */

    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_4;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_Level_2;
    GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
    GPIO_Init(GPIOA, &GPIO_InitStructure);


    // GPIO_Init(GPIOB, &GPIO_InitStructure);

    /* Connect TIM Channels to AF2 */
    GPIO_PinAFConfig(GPIOA, GPIO_PinSource4, GPIO_AF_4);


    TIM_TimeBaseStructure.TIM_Prescaler = 0;
    TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;

    TIM_TimeBaseStructure.TIM_Period = 2399;
    TIM_TimeBaseStructure.TIM_ClockDivision = 0;
    TIM_TimeBaseStructure.TIM_RepetitionCounter = 0;
    TIM_TimeBaseInit(TIM14, &TIM_TimeBaseStructure);

    TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM2;
    TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;
    TIM_OCInitStructure.TIM_OutputNState = TIM_OutputNState_Disable;

    TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_Low;
    TIM_OCInitStructure.TIM_OCNPolarity = TIM_OCNPolarity_High;

    TIM_OCInitStructure.TIM_OCIdleState = TIM_OCIdleState_Set;
    TIM_OCInitStructure.TIM_OCNIdleState = TIM_OCIdleState_Reset;


    TIM_OCInitStructure.TIM_Pulse = 0;

    TIM_OC1Init(TIM14, &TIM_OCInitStructure);


    TIM_Cmd(TIM14, ENABLE);
    TIM_CtrlPWMOutputs(TIM14, ENABLE);


}

void Dri_Time6_Init(void)
{

    TIM_TimeBaseInitTypeDef TIM_TimeBaseStructure;
    NVIC_InitTypeDef NVIC_InitStructure;

    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM6, ENABLE);

    TIM_TimeBaseStructure.TIM_Prescaler = 47;  // ��Ƶϵ��
    TIM_TimeBaseStructure.TIM_Period = 65535;    // �Զ�����ֵ
    TIM_TimeBaseStructure.TIM_ClockDivision = TIM_CKD_DIV1;
    TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;
    TIM_TimeBaseInit(TIM6, &TIM_TimeBaseStructure);

    // 3. ����NVIC
//    NVIC_InitStructure.NVIC_IRQChannel = TIM6_DAC_IRQn; // TIM6�ж�ͨ��
//    NVIC_InitStructure.NVIC_IRQChannelPriority = 2;     // ���ȼ�����
//    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;     // ʹ��NVIC
//    NVIC_Init(&NVIC_InitStructure);
//
//    NVIC_InitStructure.NVIC_IRQChannel = SysTick_IRQn; // TIM6�ж�ͨ��
//    NVIC_InitStructure.NVIC_IRQChannelPriority = 3;     // ���ȼ�����
//    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;     // ʹ��NVIC
//    NVIC_Init(&NVIC_InitStructure);
    // ������±�־λ
    TIM_ClearFlag(TIM6, TIM_FLAG_Update);

    // 5. ������ʱ�������ж�
//    TIM_ITConfig(TIM6, TIM_IT_Update, ENABLE);
    // 3. ʹ�ܶ�ʱ��
    TIM_Cmd(TIM6, ENABLE);

}

void IO_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStructure;

    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_13 | GPIO_Pin_14;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_10MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
    GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
    GPIO_Init(GPIOC, &GPIO_InitStructure);

}

uint32_t aaaa = 0;

int main(void)
{


    RCC_AHBPeriphClockCmd(
            RCC_AHBPeriph_GPIOA | RCC_AHBPeriph_GPIOB | RCC_AHBPeriph_GPIOC | RCC_AHBPeriph_GPIOD | RCC_AHBPeriph_GPIOF,
            ENABLE);
    IO_Init();
    Motor_Init();
    SysTick_Init();
    Dri_Time15_Init();
    Dri_Time16_Init();
    Dri_Time17_Init();
    Dri_Time14_Init();
    Dri_Time1_Init();
    Dri_Time2_Init();
    Dri_Time3_Init();


    Dri_Time6_Init();
    tm1650_init();
    menu_init();
    ws2812_spi1_dma_init();
    menu_fun_ptr_init();
    VtorTimer_Init();
    DMX512_Init(250000);
    d_433_Init();
    Flash_GetSaveVariable();
    init_globals();
    iwdg_init();
    while (1) {
        aaaa++;
        if (DMX_RxBuf[0] == CONSOLE_FRAME_HEADER) {
            console_data.console_ch_diff_ch25_mode = DMX_RxBuf[25] * 10 / 155;
            console_data.console_ch_diff_ch26_mode = DMX_RxBuf[26] / 25;
            console_data.console_ch_diff_ch27_mode = DMX_RxBuf[27] * 10 / 155;

            console_data.console_ch_ease_ch15_mode = DMX_RxBuf[15] * 10 / 155;
            console_data.console_ch_ease_ch16_mode = DMX_RxBuf[16] / 25;
            console_data.console_ch_ease_ch17_mode = DMX_RxBuf[17] * 10 / 155;

            console_data.console_ch_ease_all_speed = DMX_RxBuf[18] / 25;
            console_data.console_ch_diff_all_speed = DMX_RxBuf[28] / 25;

            console_data.console_ch_ease_sexx_speed = DMX_RxBuf[19] / 25;
            console_data.console_ch_diff_sexx_speed = DMX_RxBuf[29] / 25;
        }
        iwdg_feed();  // ι��
        VtorTimer_Schedule();
//        PWM_RG = 0;
    }

}
//


//#define  PWMR    TIM16->CCR1 //G
//#define  PWMW    TIM17->CCR1//R
//#define  PWMA    TIM14->CCR1
unsigned short CPWM, Cnt = 0;
#define  MAX_PWM   2000


static uint8_t sys_time;
volatile uint32_t g_tickCount = 0;  // ���ڴ洢ϵͳ����ʱ�䣨���룩
void SysTick_Handler(void)
{

    Motor_Driv();
    SetFdmxPostion();
    SetFAdmxPostion();
    VtorTimer_IncTick(5);
//    PWMA = 2000;
    sys_time++;
    if (sys_time == 2) {
        g_tickCount++;  // ÿ���ж����Ӽ���
        sys_time = 0;

    }

//    if (DMX_RxBuf[0] != CONSOLE_FRAME_HEADER) {
//        fun_mode_timer_run();
//    }

//    if (DMX_RxBuf[0] != CONSOLE_FRAME_HEADER) {
    fun_mode_timer_run();
//    }

//    if(DMX_RxBuf[0] == MASTER_SLAVE_FRAME_HEADER && ptr == &Axxx){
//        Adafruit_NeoPixel_show();
//    }else{
//        WS2812FX_service();
//        fun_master_send_data();
//    }

//	 PWMR = PWMW=PWMB = PWMG=2000;
//		 PWMR1 = PWMW1=PWMB1 = PWMG1=2000;
    if (Cnt++ > 8000) {
        CPWM++;

        if (CPWM >= 12)
            CPWM = 0;
        Cnt = 0;
        fun_set_motor();

    }


}
//uint32_t GetSystemRunTime(void) {
//    return g_tickCount;  // ����ϵͳ����ʱ�䣨���룩
//}





























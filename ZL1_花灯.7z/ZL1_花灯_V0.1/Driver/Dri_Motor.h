#ifndef __DRI_Motor_H
#define __DRI_Motor_H


// FASpeed FADmxPosition  Сħ��
// FSpeed FDmxPosition  ��ħ��
extern unsigned   char  XRefresh,XDmxPosition,XDmxPositionFine,XOfficeValue,XSpeed,XbInverse ,
	               YRefresh,YDmxPosition,YDmxPositionFine,YOfficeValue,YSpeed,YbInverse,
                FRefresh,FDmxPosition,FDmxPositionFine,FOfficeValue,FSpeed,FbInverse,
      FARefresh,FADmxPosition,FADmxPositionFine,FAOfficeValue,FASpeed,FAbInverse,
                ZRefresh,ZDmxPosition,ZDmxPositionFine,ZOfficeValue,ZSpeed,ZbInverse,
  FARefresh,FADmxPosition,FADmxPositionFine,FAOfficeValue,FASpeed,FAbInverse,
            Qi_Cai_FRefresh,Qi_Cai_FDmxPosition,Qi_Cai_FDmxPositionFine,Qi_Cai_FOfficeValue,
            Qi_Cai_FSpeed,Qi_Cai_FbInverse,
	          GoboRefresh,	GoboDmxPosition,	GoboDmxPositionFine,	GoboOfficeValue,	GoboSpeed,

          ZoomRefresh,	ZoomDmxPosition,	ZoomDmxPositionFine,	ZoomOfficeValue,	ZoomSpeed,
    	   ColorRefresh,	ColorDmxPosition,	ColorDmxPositionFine,ColorOfficeValue,	ColorSpeed;


unsigned char  ReadXRunFlag(void);
unsigned char  ReadYRunFlag(void);
unsigned char  ReadFRunFlag(void);
unsigned char  ReadFARunFlag(void);
unsigned char  ReadQi_Cai_FRunFlag(void);
unsigned char  ReadGoboRunFlag(void);
unsigned char  ReadColorRunFlag(void);

void  SetXdmxPostion(void);
void  SetYdmxPostion(void);
void  SetFdmxPostion(void);
void  SetFAdmxPostion(void);
void  SetQi_Cai_FdmxPostion(void);
void  SetZoomdmxPostion(void);
void  SetColordmxPostion(void);
void  SetGobodmxPostion(void);
void  SetZoomdmxPostion(void);
unsigned char  ReadFARestFlag(void);
extern unsigned char  ReadXRestFlag(void);
extern unsigned char  ReadYRestFlag(void);
extern unsigned char  ReadFRestFlag(void);
extern unsigned char  ReadFARestFlag(void);
extern unsigned char  ReadQi_Cai_FRestFlag(void);
extern unsigned char  ReadZRestFlag(void);
extern unsigned char  ReadGoboRestFlag(void);
extern unsigned char  ReadColorRestFlag(void);
extern unsigned char  ReadZoomRestFlag(void);
extern void Motor_Driv(void);
extern void Motor_Init(void);

extern  void Dri_Time3_Init(void);
void  SetXRefresh(void);
void  SetYRefresh(void);
void  SetFRefresh(void);
void  SetQi_Cai_FRefresh(void);

void  SetZRefresh(void);
void  SetColorRefresh(void);
void  SetGoboRefresh(void);
void  SetZoomRefresh(void);
void Gobo_touduFlag(void);
void Color_touduFlag(void);

#define NULL                                0
#define DECREASE                            0
#define INCREASE                            !DECREASE
#define OFF                                 0
#define ON                                  !OFF
void Dri_Time16_Init(void);
void Dri_Time17_Init(void);
void Dri_Time15_Init(void);

#endif


#include <string.h>
#include "fun.h"
#include "ws2812/ws2812fx.h"
#include "ws2812/ws2812_fun.h"
#include "usartx/dmx.h"
#include "ws2812/ws2812_driver.h"
#include "Dri_Motor.h"
#include "sys_config.h"
#include "usartx/rdm.h"

_mode_ctrl mode_use;
_console_data console_data;
uint8_t mic;
bool r_temp;
bool g_temp;




void fun_set_run_mode(_mode_ctrl * modeCtrl,uint16_t mode,uint16_t max_run_time){
    extern Segment_runtime* _segment_runtimes;
    if (modeCtrl->mode != mode) {
        modeCtrl->mode = mode;
        modeCtrl->max_run_time_u16 = max_run_time;
        modeCtrl->motor_max_run_time_u16 = 10000;
        modeCtrl->run_time_16 = 0;  //�л�ģʽʱʱ������
        modeCtrl->motor_run_time_16 = 0;
        modeCtrl->ws2812_run_time = 0;
        _segment_runtimes->next_time = 0;
        set_flag_false();
    }
}


void fun_mode_timer_run()
{
    static uint8_t count = 0;
    static uint8_t count2 = 0;
    static bool flag = false;

    count++;
    if (count >= 8) {
        count = 0;
        mode_use.run_time_16++;   //Լ1ms��һ��
        mode_use.motor_run_time_16++;
        mode_use.ws2812_run_time++;

        if (mode_use.mic_time > 0) {
            mode_use.mic_time--;
        }
    }

    count2++;
    if (count2 >= 50) {
        count2 = 0;

    }


    if (mode_use.run_time_16 >= mode_use.max_run_time_u16) {
        mode_use.run_time_16 = 0;
    }

    if (mode_use.motor_run_time_16 >= mode_use.motor_max_run_time_u16){
        mode_use.motor_run_time_16 = 0;
    }
//    if (DMX_RxBuf[0] == CONSOLE_FRAME_HEADER) {
//        console_data.console_ch_diff_ch27_mode = DMX_RxBuf[2] * 10 / 155;
//        console_data.console_ch_diff_ch25_mode = DMX_RxBuf[26] * 10 / 155;
//        console_data.console_ch_diff_ch26_mode = DMX_RxBuf[27] / 25;
//    }
    ws2812_change_moder();
    ws2812_console_choice_moder();
}

void fun_mode_time_reset(){
    mode_use.ws2812_run_time = 0;
    mode_use.run_time_16 = 0;
}
void fun_set_rg(bool r, bool g)
{
    r_temp = r;
    g_temp = g;
    if (ptr == &Axxx && DMX_RxBuf[0] ==  CONSOLE_FRAME_HEADER && DMX_RxBuf[1] == 0x0) {
        R_DISEN;
        G_DISEN;
    }else{
        if (r) R_EN;   // �켤��
        else
            R_DISEN;

        if (g) G_EN;   // �̼���
        else
            G_DISEN;
    }

}

void fun_set_rgbw0(uint8_t r, uint8_t g, uint8_t b, uint8_t w)
{
    if ((ptr == &Axxx ||ptr == &Cxxx) && DMX_RxBuf[0] ==  CONSOLE_FRAME_HEADER &&
    ((Cxxx.number == SYS_CONSOLE_DIFF_CH && DMX_RxBuf[27] > 0x0)||(Cxxx.number == SYS_CONSOLE_EASE_CH && DMX_RxBuf[17] > 0x0))) {
        PWMR = MAX * r / 255 * DMX_RxBuf[1] / 255  * R4xxx_b.number / 10;
        PWMG = MAX * g / 255 * DMX_RxBuf[1] / 255  * G4xxx_b.number / 10;
        PWMB = MAX * b / 255 * DMX_RxBuf[1] / 255  * B4xxx_b.number / 10;
        PWMW = MAX * w / 255 * DMX_RxBuf[1] / 255  * W4xxx_b.number / 10;
    }else {
        PWMR = MAX * r / 255 * R4xxx_b.number / 10;
        PWMG = MAX * g / 255 * G4xxx_b.number / 10;
        PWMB = MAX * b / 255 * B4xxx_b.number / 10;
        PWMW = MAX * w / 255 * W4xxx_b.number / 10;
    }
}



void fun_set_rgbw1(uint8_t r, uint8_t g, uint8_t b, uint8_t w)
{
    if (ptr == &Axxx && DMX_RxBuf[0] ==  CONSOLE_FRAME_HEADER && DMX_RxBuf[2] > 0x0) {
        PWMR1 = MAX * r / 255 * DMX_RxBuf[1] / 255  * R4xxx_b.number / 10;
        PWMG1 = MAX * g / 255 * DMX_RxBuf[1] / 255  * G4xxx_b.number / 10;
        PWMB1 = MAX * b / 255 * DMX_RxBuf[1] / 255  * B4xxx_b.number / 10;
        PWMW1 = MAX * w / 255 * DMX_RxBuf[1] / 255  * W4xxx_b.number / 10;
    }else {
        PWMR1 = MAX * r / 255 * R4xxx_b.number / 10;
        PWMG1 = MAX * g / 255 * G4xxx_b.number / 10;
        PWMB1 = MAX * b / 255 * B4xxx_b.number / 10;
        PWMW1 = MAX * w / 255 * W4xxx_b.number / 10;
    }
}

void fun_set_rgbw2(uint8_t r, uint8_t g, uint8_t b, uint8_t w)
{
    if (ptr == &Axxx && DMX_RxBuf[0] ==  CONSOLE_FRAME_HEADER && DMX_RxBuf[2] > 0x0) {
        PWMR2 = MAX * r / 255 * DMX_RxBuf[1] / 255 * R5xxx_b.number / 10;
        PWMG2 = MAX * g / 255 * DMX_RxBuf[1] / 255 * G5xxx_b.number / 10;
        PWMB2 = MAX * b / 255 * DMX_RxBuf[1] / 255 * B5xxx_b.number / 10;
        PWMW2 = MAX * w / 255 * DMX_RxBuf[1] / 255 * W5xxx_b.number / 10;
    }else{
        PWMR2 = MAX * r / 255 * R5xxx_b.number / 10;
        PWMG2 = MAX * g / 255 * G5xxx_b.number / 10;
        PWMB2 = MAX * b / 255 * B5xxx_b.number / 10;
        PWMW2 = MAX * w / 255 * W5xxx_b.number / 10;
    }

}

void fun_set_rg_store(_mode_ctrl * modeCtrl,uint16_t min,uint16_t max,uint16_t store_speed,bool r, bool g){
    if (modeCtrl->run_time_16 >= min && modeCtrl->run_time_16 <= max  ) {
        // �����ٶȿ�����˸Ƶ��
        if (store_speed == 0) {
            fun_set_rg(r, g);
            return;
        }

        if ((modeCtrl->run_time_16 % store_speed) > (store_speed / 3)) {
            fun_set_rg(false,false);
        }else{
            fun_set_rg(r, g);
        }
    }
}
void fun_set_rgbw0_store(_mode_ctrl * modeCtrl,uint16_t min,uint16_t max,uint16_t store_speed,uint8_t r, uint8_t g, uint8_t b, uint8_t w){
    if (modeCtrl->run_time_16 >= min && modeCtrl->run_time_16 <= max  ) {
        // �����ٶȿ�����˸Ƶ��
        if (store_speed == 0) {
            fun_set_rgbw0(r, g, b, w);
            return;
        }
        if ((modeCtrl->run_time_16 % store_speed) > (store_speed / 3)) {
            fun_set_rgbw0(0, 0, 0, 0);
        }else{
            fun_set_rgbw0(r, g, b, w);
        }

    }
}

void fun_set_rgbw1_store(_mode_ctrl * modeCtrl,uint16_t min,uint16_t max,uint16_t store_speed,uint8_t r, uint8_t g, uint8_t b, uint8_t w){
    if (modeCtrl->run_time_16 >= min && modeCtrl->run_time_16 <= max) {
        // �����ٶȿ�����˸Ƶ��

        if (store_speed == 0) {
            fun_set_rgbw1(r, g, b, w);
            return;
        }
        if ((modeCtrl->run_time_16 % store_speed) > (store_speed / 3)) {
            fun_set_rgbw1(0, 0, 0, 0);
        }else{
            fun_set_rgbw1(r, g, b, w);
        }
    }
}

void fun_set_rgbw2_store(_mode_ctrl * modeCtrl,uint16_t min,uint16_t max,uint16_t store_speed,uint8_t r, uint8_t g, uint8_t b, uint8_t w){
    if (modeCtrl->run_time_16 >= min && modeCtrl->run_time_16 <= max  ) {
        // �����ٶȿ�����˸Ƶ��
        if (store_speed == 0) {
            fun_set_rgbw2(r, g, b, w);
            return;
        }

        if ((modeCtrl->run_time_16 % store_speed) > (store_speed / 3)) {
            fun_set_rgbw2(0, 0, 0, 0);
        }else{
            fun_set_rgbw2(r, g, b, w);

        }
    }
}


void fun_set_motor(){

//        if ((modeCtrl->run_time_16 % store_speed) > (store_speed / 3)) {
//            fun_set_rgbw0(0, 0, 0, 0);
//        }else{
//            fun_set_rgbw0(r, g, b, w);
//        }
    if (DMX_RxBuf[0] == RDM_FRAME_HEADER ||  rdm_st_count < 60001) {
        FDmxPosition = 0;
        FADmxPosition = 0;
        FASpeed = 0;
        FSpeed = 0;
        PWM_RG = 0;
        return;
    }
    if ((PWMG2 == 0 && PWMR2 == 0 && PWMB2 == 0 && PWMW2 == 0)) {
        FDmxPosition = 0;
    }
    else{
        if (mode_use.motor_run_time_16 < 100) {
            if(FDmxPosition==0)
            {

                FDmxPosition=255;
            }
            else
            {
                FDmxPosition=0;
            }
        }
        else if (mode_use.motor_run_time_16 < 2000) {
            if(FDmxPosition <125)
            {

                FDmxPosition=255;
            }
            else
            {
                FDmxPosition=125;
            }
        } else if (mode_use.motor_run_time_16 < 2500) {
            FDmxPosition = 0;
        } else if (mode_use.motor_run_time_16 < 4000) {
            if(FDmxPosition <50)
            {

                FDmxPosition=255;
            }
            else
            {
                FDmxPosition=125;
            }
        }else if (mode_use.motor_run_time_16 < 6000) {
            if(FDmxPosition <80)
            {

                FDmxPosition=255;
            }
            else
            {
                FDmxPosition=125;
            }
        }else if (mode_use.motor_run_time_16 < 8000) {
            if(FDmxPosition <80)
            {

                FDmxPosition=155;
            }
            else
            {
                FDmxPosition=125;
            }
        }else if (mode_use.motor_run_time_16 < 10000) {
            if(FDmxPosition <150)
            {

                FDmxPosition=255;
            }
            else
            {
                FDmxPosition=125;
            }
        }
    }


    if (PWMG1 == 0 && PWMR1 == 0 && PWMB1 == 0 && PWMW1 == 0){
        FADmxPosition = 0;
    }
    else{
        if (mode_use.motor_run_time_16 < 1000) {
            FADmxPosition=255-FDmxPosition;
        } else if (mode_use.motor_run_time_16 < 2000) {

            FADmxPosition=255-FDmxPosition;
        } else if (mode_use.motor_run_time_16 < 2500) {
            FADmxPosition=0;
        } else if (mode_use.motor_run_time_16 < 4000) {

            FADmxPosition=255-FDmxPosition;
        }else if (mode_use.motor_run_time_16 < 6000) {

            FADmxPosition=255-FDmxPosition;
        }else if (mode_use.motor_run_time_16 < 8000) {

            FADmxPosition=255-FDmxPosition;
        }else if (mode_use.motor_run_time_16 < 10000) {
            FADmxPosition=255-FDmxPosition;
        }
    }


    if (ptr!= &Axxx&& ptr !=&Cxxx){
        if (mode_use.motor_run_time_16 >2000 && mode_use.motor_run_time_16 < 3000){
            FASpeed = 0;
            FSpeed = 0;

            if (ptr == &S1xx && ptr == &S2xx) {
                FSpeed = 0;
                FASpeed = 0;

            }else{
                if ((0 + (9-ptr->number) *5) > 255) FASpeed = 255;
                else{ FASpeed = 0 + (9-ptr->number) *5;}

                if ((0 + (9-ptr->number) *5) > 255) FSpeed = 255;
                else{ FSpeed = 0 + (9-ptr->number) *5;}
            }

            if (r_temp == true || g_temp == true) {
                PWM_RG = MAX;
            }
        }else if (mode_use.motor_run_time_16 >5000 && mode_use.motor_run_time_16 < 6000){
            if (ptr == &S1xx && ptr == &S2xx) {
                FASpeed = 0;
                FSpeed = 120;

            }else{
                if ((0 + (9-ptr->number) *5) > 255) FASpeed = 255;
                else{ FASpeed = 0 + (9-ptr->number) *5;}

                if ((120 + (9-ptr->number) *5) > 255) FSpeed = 255;
                else{ FSpeed = 120 + (9-ptr->number) *5;}
            }

            if (r_temp == true || g_temp == true) {

                PWM_RG = MAX;}
        }else if (mode_use.motor_run_time_16 >8000 && mode_use.motor_run_time_16 < 9000){

            if (ptr == &S1xx && ptr == &S2xx) {
                FASpeed = 120;
                FSpeed = 0;

            }else{
                if ((120 + (9-ptr->number) *5) > 255) FASpeed = 255;
                else{ FASpeed = 120 + (9-ptr->number) *5;}

                if ((0 + (9-ptr->number) *5) > 255) FSpeed = 255;
                else{ FSpeed = 0 + (9-ptr->number) *5;}
            }
            if (r_temp == true || g_temp == true) {

                PWM_RG = MAX / 2;
            }
        }else{
            if (ptr == &S1xx && ptr == &S2xx) {
                FASpeed = 50;
                FSpeed = 50;

            }else{
                if ((50 + (9-ptr->number) *5) > 255) FASpeed = 255;
                else{ FASpeed = 50 + (9-ptr->number) *5;}

                if ((50 + (9-ptr->number) *5) > 255) FSpeed = 255;
                else{ FSpeed = 50 + (9-ptr->number) *5;}
            }

            if (r_temp == true || g_temp == true) {

                PWM_RG = MAX;
            }
        }

    }


    if ((ptr == &Axxx || ptr == &Cxxx) && ((DMX_RxBuf[27] != 0 && Cxxx.number == SYS_CONSOLE_DIFF_CH) ||
                                           (DMX_RxBuf[17] != 0 && Cxxx.number == SYS_CONSOLE_EASE_CH))){
        if (mode_use.motor_run_time_16 >2000 && mode_use.motor_run_time_16 < 3000){
            if (r_temp == true || g_temp == true) {
                PWM_RG = MAX;
            }else{
                PWM_RG = 0;

            }
        }else if (mode_use.motor_run_time_16 >5000 && mode_use.motor_run_time_16 < 6000){

            if (r_temp == true || g_temp == true) {
                PWM_RG = MAX;
            }else{
                PWM_RG = 0;

            }
        }else if (mode_use.motor_run_time_16 >8000 && mode_use.motor_run_time_16 < 9000){
            if (r_temp == true || g_temp == true) {

                PWM_RG = MAX / 2;
            }else{
                PWM_RG = 0;

            }
        }else{
            if (r_temp == true || g_temp == true) {
                PWM_RG = MAX;
            }else{
                PWM_RG = 0;

            }
        }
    }
}

void fun_master_send_data()
{
    if ((ptr == &A1xx || ptr == &A2xx || ptr == &A3xx || ptr == &A4xx || ptr == &A5xx ||
        ptr == &A6xx || ptr == &A7xx || ptr == &A8xx || ptr == &A9xx || ptr == &AAxx || ptr == &ABxx ||
        ptr == &ACxx || ptr == &ADxx || ptr == &AExx || ptr == &AFxx && DMX_CONNECT_State == DMX_CONNECT_ERROR)) {
        extern uint8_t pixels[WS2812_NUM * 3];
        DMX_TxBuf[0] = MASTER_SLAVE_FRAME_HEADER;
        DMX_TxBuf[1] = (uint8_t) (PWMR >> 8);
        DMX_TxBuf[2] = (uint8_t) PWMR;
        DMX_TxBuf[3] = (uint8_t) (PWMG >> 8);
        DMX_TxBuf[4] = (uint8_t) PWMG;
        DMX_TxBuf[5] = (uint8_t) (PWMB >> 8);
        DMX_TxBuf[6] = (uint8_t) PWMB;
        DMX_TxBuf[7] = (uint8_t) (PWMW >> 8);
        DMX_TxBuf[8] = (uint8_t) PWMW;
        DMX_TxBuf[9] = (uint8_t) (PWMR1 >> 8);
        DMX_TxBuf[10] = (uint8_t) PWMR1;
        DMX_TxBuf[11] = (uint8_t) (PWMG1 >> 8);
        DMX_TxBuf[12] = (uint8_t) PWMG1;
        DMX_TxBuf[13] = (uint8_t) (PWMB1 >> 8);
        DMX_TxBuf[14] = (uint8_t) PWMB1;
        DMX_TxBuf[15] = (uint8_t) (PWMW1 >> 8);
        DMX_TxBuf[16] = (uint8_t) PWMW1;
        DMX_TxBuf[17] = (uint8_t) (PWMR2 >> 8);
        DMX_TxBuf[18] = (uint8_t) PWMR2;
        DMX_TxBuf[19] = (uint8_t) (PWMG2 >> 8);
        DMX_RxBuf[20] = (uint8_t) PWMG2;
        DMX_TxBuf[21] = (uint8_t) (PWMB2 >> 8);
        DMX_TxBuf[22] = (uint8_t) PWMB2;
        DMX_TxBuf[23] = (uint8_t) (PWMW2 >> 8);
        DMX_TxBuf[24] = (uint8_t) PWMW2;
        DMX_TxBuf[25] = r_temp;
        DMX_TxBuf[26] = g_temp;
        DMX_TxBuf[27] = (uint8_t) (PWM_RG >> 8);
        DMX_TxBuf[28] = (uint8_t) PWM_RG;
        DMX_TxBuf[29] = (uint8_t) FDmxPosition;
        DMX_TxBuf[30] = (uint8_t) FADmxPosition;
        DMX_TxBuf[31] = (uint8_t) FASpeed;
        DMX_TxBuf[32] = (uint8_t) FSpeed;
        memcpy(&DMX_TxBuf[33], pixels, WS2812_NUM * 3);
        DMX512_StartTransmit(DMX_TxBuf, DMX_BUF_SIZE);
    }
}

void fun_slave_recv_data()
{
    extern uint8_t pixels[WS2812_NUM * 3];
    PWMR = DMX_RxBuf[1] << 8 | DMX_RxBuf[2];
    PWMG = DMX_RxBuf[3] << 8 | DMX_RxBuf[4];
    PWMB = DMX_RxBuf[5] << 8 | DMX_RxBuf[6];
    PWMW = DMX_RxBuf[7] << 8 | DMX_RxBuf[8];
    PWMR1 = DMX_RxBuf[9] << 8 | DMX_RxBuf[10];
    PWMG1 = DMX_RxBuf[11] << 8 | DMX_RxBuf[12];
    PWMB1 = DMX_RxBuf[13] << 8 | DMX_RxBuf[14];
    PWMW1 = DMX_RxBuf[15] << 8 | DMX_RxBuf[16];
    PWMR2 = DMX_RxBuf[17] << 8 | DMX_RxBuf[18];
    PWMG2 = DMX_RxBuf[19] << 8 | DMX_RxBuf[20];
    PWMB2 = DMX_RxBuf[21] << 8 | DMX_RxBuf[22];
    PWMW2 = DMX_RxBuf[23] << 8 | DMX_RxBuf[24];
    r_temp = DMX_RxBuf[25];
    g_temp = DMX_RxBuf[26];
    PWM_RG = DMX_RxBuf[27] << 8 | DMX_RxBuf[28];
    FDmxPosition = DMX_RxBuf[29];
    FADmxPosition = DMX_RxBuf[30];
    FASpeed = DMX_RxBuf[31];
    FSpeed = DMX_RxBuf[32];
    memcpy(pixels, DMX_RxBuf + 33, WS2812_NUM * 3);
}
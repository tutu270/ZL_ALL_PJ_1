
#include "usart1.h"

void USART1_Init(uint32_t baud)
{
    GPIO_InitTypeDef GPIO_InitStructure;
    USART_InitTypeDef USART_InitStructure;
    NVIC_InitTypeDef NVIC_InitStructure;

    // 1.ʹ��ʱ��
    RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOA, ENABLE);
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1, ENABLE);

    // 2.��ʼ��GPIO
    // PA9 - TX
    // PA10 - RX
    GPIO_PinAFConfig(GPIOA, GPIO_PinSource9, GPIO_AF_1);
    GPIO_PinAFConfig(GPIOA, GPIO_PinSource10, GPIO_AF_1);

    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9 | GPIO_Pin_10;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
    GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

    // 3.����USART1
    USART_InitStructure.USART_BaudRate = baud;  // ������
    USART_InitStructure.USART_WordLength = USART_WordLength_8b;  // 8λ����
    USART_InitStructure.USART_StopBits = USART_StopBits_1;  // 1λֹͣλ
    USART_InitStructure.USART_Parity = USART_Parity_No;  // ��У��
    USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;  // ��Ӳ������
    USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;  // �շ�ģʽ
    USART_Init(USART1, &USART_InitStructure);

    // 4.����NVIC
    NVIC_InitStructure.NVIC_IRQChannel = USART1_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPriority = 1;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);

    // 5.ʹ�ܽ����ж�
    USART_ITConfig(USART1, USART_IT_RXNE, ENABLE);

    // 6.ʹ��USART1
    USART_Cmd(USART1, ENABLE);
}

// 7.�жϷ�����
//void USART1_IRQHandler(void)
//{
//    uint8_t Res;
//    if(USART_GetITStatus(USART1, USART_IT_RXNE) != RESET)
//    {
//        Res = USART_ReceiveData(USART1);
//
//        // �������յ�������
//        // ...
//
//        // �����Ҫ�ط�����
//        // USART_SendData(USART1, Res);
//        // while(USART_GetFlagStatus(USART1, USART_FLAG_TXE) == RESET);
//    }
//}

// 8.����һ���ֽ�
void USART1_SendByte(uint8_t data)
{
    USART_SendData(USART1, data);
    while(USART_GetFlagStatus(USART1, USART_FLAG_TXE) == RESET);
}

// 9.�����ַ���
void USART1_SendString(char *str)
{
    while(*str)
    {
        USART1_SendByte(*str++);
    }
}// ��ʼ����

//void DMX512_StartTransmit(void)
//{
//    // 1. ����BREAK (����TX��>88us)
//    USART_SendBreak(USART1);
//
//    // 2. �ȴ��������
//    while(USART_GetFlagStatus(USART1, USART_FLAG_TC) == RESET);
//
//    // 3. MAB (Mark After Break)
//    for(uint16_t i = 0; i < 100; i++); // ��ʱ
//
//    // 4. ������ʼ��(0x00)��512��ͨ������
//    for(uint16_t i = 0; i < DMX_BUF_SIZE; i++)
//    {
//        USART_SendData(USART1, DMX_TxBuf[i]);
//        while(USART_GetFlagStatus(USART1, USART_FLAG_TC) == RESET);
//    }
//}


#ifndef _USART1_H
#define _USART1_H
#include "stm32f0xx_conf.h"

void USART1_Init(uint32_t baud);
#endif //HUADENG_USART1_H

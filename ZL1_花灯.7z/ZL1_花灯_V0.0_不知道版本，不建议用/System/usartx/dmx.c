
#include <string.h>
#include "dmx.h"
#include "menu/menu.h"
#include "fun.h"
#include "rdm.h"


uint8_t DMX_RxBuf[513]= {1};
uint8_t DMX_TxBuf[160] = {0, 0, 0, 0};
DMX_StateTypeDef DMX_State = DMX_IDLE;
DMX_CONNECT_StateTypeDef DMX_CONNECT_State = DMX_CONNECT_ERROR;
static uint16_t transmit_address = 0;
uint16_t dmx_dataCount_u8 = 0;
uint16_t rx_time = 5000;

static void Delay_us(uint32_t us)
{
    // ���㣺����ÿ�ο�ѭ����Լ��Ҫ5��ʱ������
    volatile uint32_t count = us * 6;  // ����������ƥ��48 MHzʱ��Ƶ��
    while (count--) {
        __asm("nop");  // ��ֹ�Ż�
    }
}

void DMX512_Init(uint32_t baud)
{
    GPIO_InitTypeDef GPIO_InitStructure;
    USART_InitTypeDef USART_InitStructure;
    NVIC_InitTypeDef NVIC_InitStructure;
    DMA_InitTypeDef DMA_InitStructure;
    NVIC_InitTypeDef NVIC_InitStruct;

    // ʹ��ʱ��
    RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOB, ENABLE);
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1, ENABLE);

    // ����GPIO
    GPIO_PinAFConfig(GPIOB, GPIO_PinSource6, GPIO_AF_0);  // TX
    GPIO_PinAFConfig(GPIOB, GPIO_PinSource7, GPIO_AF_0); // RX

    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6 | GPIO_Pin_7;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
    GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
    GPIO_Init(GPIOB, &GPIO_InitStructure);

    // ����PB11ΪRS485�����������
    GPIO_InitStructure.GPIO_Pin = RS485_DIR_PIN;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_10MHz;
    GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
    GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
    GPIO_Init(RS485_DIR_PORT, &GPIO_InitStructure);
    RS485_RX_EN();  // Ĭ�Ͻ���ʹ��

    // ����USART
    USART_InitStructure.USART_BaudRate = baud;  // DMX512��׼������250kbps
    USART_InitStructure.USART_WordLength = USART_WordLength_8b;
    USART_InitStructure.USART_StopBits = USART_StopBits_2; // DMXʹ��2λֹͣλ
    USART_InitStructure.USART_Parity = USART_Parity_No;
    USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
    USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
    USART_Init(USART1, &USART_InitStructure);


    // DMA����
    DMA_DeInit(DMA1_Channel2);  // USART1_TX��ӦDMA1 Channel2
    DMA_InitStructure.DMA_PeripheralBaseAddr = (uint32_t) &USART1->TDR;
    DMA_InitStructure.DMA_MemoryBaseAddr = (uint32_t) DMX_TxBuf;
    DMA_InitStructure.DMA_DIR = DMA_DIR_PeripheralDST;
    DMA_InitStructure.DMA_BufferSize = DMX_BUF_SIZE;
    DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;
    DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable;
    DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_Byte;
    DMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize_Byte;
    DMA_InitStructure.DMA_Mode = DMA_Mode_Normal;
    DMA_InitStructure.DMA_Priority = DMA_Priority_High;
    DMA_InitStructure.DMA_M2M = DMA_M2M_Disable;
    DMA_Init(DMA1_Channel2, &DMA_InitStructure);

    NVIC_InitStruct.NVIC_IRQChannel = DMA1_Channel2_3_IRQn;  // ѡ��DMAͨ��3���ж�
    NVIC_InitStruct.NVIC_IRQChannelPriority = 2;  // �ж����ȼ�
    NVIC_InitStruct.NVIC_IRQChannelCmd = ENABLE;  // ʹ���ж�
    NVIC_Init(&NVIC_InitStruct);
    // ʹ��DMA��������ж�
    DMA_ITConfig(DMA1_Channel2, DMA_IT_TC, ENABLE);

    // ʹ���ж�
    USART_ITConfig(USART1, USART_IT_RXNE, ENABLE);

    // USART��DMA���͹���ʹ��
    USART_DMACmd(USART1, USART_DMAReq_Tx, ENABLE);

    // ����NVIC
    NVIC_InitStructure.NVIC_IRQChannel = USART1_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);

    USART_Cmd(USART1, ENABLE);
}

void USART_Send_Data(uint8_t *data, uint16_t size)
{
    uint16_t i;
    for (i = 0; i < size; i++) {
        // �ȴ���һ�η������
        while (USART_GetFlagStatus(USART1, USART_FLAG_TXE) == RESET);

        // ����һ���ֽ�����
        USART_SendData(USART1, data[i]);
    }

    // �ȴ����һ���ֽڷ������
    while (USART_GetFlagStatus(USART1, USART_FLAG_TC) == RESET);
    Delay_us(20);

}

// DMA���ͺ���
void DMX512_DMA_Send(uint8_t *data, uint16_t size)
{


    // ���ô������ݴ�С
    DMA1_Channel2->CNDTR = size;

    // �����ڴ��ַ
    DMA1_Channel2->CMAR = (uint32_t) data;

    // ʹ��DMAͨ��
    DMA_Cmd(DMA1_Channel2, ENABLE);


}


// ����Break�ź�
static void DMX512_SendBreak(void)
{
    // 1. ʹ�ܷ���
    RS485_TX_EN();

    // 2. ��������Ϊ���ģʽ
    GPIO_InitTypeDef GPIO_InitStructure;
    GPIO_InitStructure.GPIO_Pin = DMX_TX_PIN;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
    GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_DOWN;
    GPIO_Init(DMX_TX_PORT, &GPIO_InitStructure);

    // 3. ����Break(����>88us)
    GPIO_ResetBits(DMX_TX_PORT, DMX_TX_PIN);
    Delay_us(100);  // ��ʱ100us��ȷ��Breakʱ���㹻
    GPIO_SetBits(DMX_TX_PORT, DMX_TX_PIN);

    // 4. MAB��ʱ(>8us)
    Delay_us(12);

    // 5. �ָ�ΪUSART����
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
    GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_DOWN;
    GPIO_Init(DMX_TX_PORT, &GPIO_InitStructure);
}

static void DMX512_SendBreak_user(uint16_t break_time, uint16_t mab_time)
{
    // 1. ʹ�ܷ���
    RS485_TX_EN();

    // 2. ��������Ϊ���ģʽ
    GPIO_InitTypeDef GPIO_InitStructure;
    GPIO_InitStructure.GPIO_Pin = DMX_TX_PIN;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
    GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
    GPIO_Init(DMX_TX_PORT, &GPIO_InitStructure);

    // 3. ����Break(����>88us)
    GPIO_ResetBits(DMX_TX_PORT, DMX_TX_PIN);
    Delay_us(break_time);  // ��ʱ100us��ȷ��Breakʱ���㹻
    GPIO_SetBits(DMX_TX_PORT, DMX_TX_PIN);

    // 4. MAB��ʱ(>8us)
    Delay_us(mab_time);

    // 5. �ָ�ΪUSART����
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
    GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_DOWN;
    GPIO_Init(DMX_TX_PORT, &GPIO_InitStructure);

}

volatile uint8_t DMX_TxStatus = 0;  // 0:idle, 1:sending

// ��ʼ����
void DMX512_StartTransmit(uint8_t *data, uint16_t size)
{
    // ȷ��DMAδ�ڴ���
    if (DMX_TxStatus == 0) {
        DMX_TxStatus = 1;
        // 1. ����BREAK (����TX��>88us)
        DMX512_SendBreak();
        // 4. ʹ��DMA��������
        DMX512_DMA_Send(data, size);
        // ������ɺ��л�������ģʽ
    }
}

void DMX512_StartTransmit_user(uint8_t *data, uint16_t size, uint16_t break_time, uint16_t mab_time)
{
    // ȷ��DMAδ�ڴ���
    if (DMX_TxStatus == 0) {
        DMX_TxStatus = 1;
//         1. ����BREAK (����TX��>88us)
        DMX512_SendBreak_user(break_time, mab_time);
        // 4. ʹ��DMA��������
        DMX512_DMA_Send(data, size);

        // ������ɺ��л�������ģʽ
    }
}

void DMX512_StartTransmit_user1(uint8_t *data, uint16_t size, uint16_t break_time, uint16_t mab_time)
{

    __disable_irq();
    DMX512_SendBreak_user(break_time, mab_time);
    USART_Send_Data(data, size);
    RS485_RX_EN();
    __enable_irq();

}


unsigned char    cReceiveMarkCode,cReceiveStartCode;
void USART1_IRQHandler(void)
{
    if (USART_GetITStatus(USART1, USART_IT_RXNE) != RESET) {
        uint8_t data = USART_ReceiveData(USART1);

        // BREAK���
        if (USART_GetFlagStatus(USART1, USART_FLAG_FE) == SET) {
            USART_ClearFlag(USART1, USART_FLAG_FE);  // ���֡�����־
            DMX_State = DMX_BREAK;
            cReceiveMarkCode=data;
            if (dmx_dataCount_u8 == 1 && DMX_RxBuf[0] == CONSOLE_FRAME_HEADER) {
                memset(DMX_RxBuf, 0, 50);
            }
            dmx_dataCount_u8 = 0;
            transmit_address = 1;
            return;
        }
//        if (DMX_RxBuf[0] == CONSOLE_FRAME_HEADER) {
//            if (ptr == &Axxx) {
//                fun_mode_timer_run();
//            }
//        }

        // ���ݽ���
        switch (DMX_State) {
            case DMX_BREAK:
                cReceiveStartCode=data;
                if ((cReceiveMarkCode == 104) && (cReceiveStartCode == 100)){
                    __disable_irq();
                    NVIC_SystemReset(); // ϵͳ��λ
                    return;
                }
                if ((data == CONSOLE_FRAME_HEADER || data == MASTER_SLAVE_FRAME_HEADER ||
                     data == MASTER_TO_MASTER_FRAME_HEADER || data == RDM_FRAME_HEADER ||
                     data == 104) && DMX_CONNECT_State == DMX_CONNECT_ERROR)  // ����������һ��������������ݽ���ģʽ
                {
                    DMX_RxBuf[dmx_dataCount_u8++] = data;
                    DMX_State = DMX_DATA;
                    if (data == CONSOLE_FRAME_HEADER && ptr != &Axxx && ptr != &Cxxx) {
                        console_data.other_in_axxx = true;
                        console_data.other_menu_addr = ptr;
                    }

                    if (ptr != &Axxx && ptr != &Cxxx) {
                        ptr = &Axxx;
                    }

                    DMX_CONNECT_State = DMX_CONNECT_OK;

                }
                break;

            case DMX_DATA:
                if (DMX_RxBuf[0] == CONSOLE_FRAME_HEADER) {
                    if (transmit_address < Axxx.number) {
                        transmit_address++;
                    } else {
                        if (dmx_dataCount_u8 < DMX_BUF_SIZE) {
                            DMX_RxBuf[dmx_dataCount_u8++] = data;
                        }
                        if (dmx_dataCount_u8 >= DMX_BUF_SIZE) {
                            DMX_State = DMX_R_IDLE;
                        }
                    }
                }
                else if (DMX_RxBuf[0] == RDM_FRAME_HEADER) {

//                    if (!apm_rdm_dmx512.rx_flag) {
                    if (dmx_dataCount_u8 < DMX_BUF_SIZE) {
                        DMX_RxBuf[dmx_dataCount_u8++] = data;
                    }
                    if (dmx_dataCount_u8 > 4) {
                        if (dmx_dataCount_u8 >= DMX_RxBuf[2] + 1) {
                            handle_rdm_msg(DMX_RxBuf);
                        }
                    }

//                    }
                }
                else {
                    if (dmx_dataCount_u8 < DMX_BUF_SIZE) {
                        DMX_RxBuf[dmx_dataCount_u8++] = data;
                    }
                    if (dmx_dataCount_u8 >= DMX_BUF_SIZE) {
                        DMX_State = DMX_R_IDLE;
                    }


                }

                rx_time = 0;
                break;

            default:
                break;
        }
    }


    if (USART_GetFlagStatus(USART1, USART_FLAG_ORE) == SET) // ��� ORE ��־
    {
        USART_ClearFlag(USART1, USART_FLAG_ORE);
        USART_ReceiveData(USART1);
    }
}

void reset_dmx_r_buf(void)
{
    if (rx_time < 5000) {
        rx_time++;
        if (console_data.other_in_axxx) {
            if (ptr != &Axxx) {
                console_data.other_in_axxx = false;
                console_data.other_menu_addr = NULL;
            }
        }
    }
    if (rx_time == 5000) {
        rx_time = 5001;
        memset(DMX_RxBuf, 0, DMX_BUF_SIZE);
        DMX_RxBuf[0] = 1;
        DMX_State = DMX_IDLE;
        DMX_CONNECT_State = DMX_CONNECT_ERROR;
//        if (ptr == &Axxx) {
        if (console_data.other_in_axxx) {
            ptr = console_data.other_menu_addr;
            console_data.other_in_axxx = false;
            console_data.other_menu_addr = NULL;
        }
//        }


    }

    if (rdm_st_count < 60000) {
        rdm_st_count++;
    }else{
        rdm_st_count = 60001;
    }
}

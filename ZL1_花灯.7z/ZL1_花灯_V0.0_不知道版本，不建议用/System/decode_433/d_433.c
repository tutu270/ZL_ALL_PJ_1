#include "d_433.h"
#include "menu/menu.h"
#include "ws2812/ws2812_fun.h"
#include "sysfun.h"
#include "fun.h"
#include "i_flash/flash.h"

#define CLASS_433_24BIT 1U
#define CLASS_433_32BIT 2U
#define PROTOCOL_CLASS CLASS_433_24BIT

#define BASIC_TIME 1U              //����ʱ��Դ 100us
#define IR_STABLE_THRESHOLD  300U  //�ȶ�����ֵ��200����λ

#if PROTOCOL_CLASS == CLASS_433_24BIT
#define IR_START_H_LEVEL_STANDARD_TIME (392U)  // ��׼�����ߵ�ƽʱ�� 0.435ms
#define IR_START_L_LEVEL_STANDARD_TIME (12344U)   // ��׼�����͵�ƽʱ�� 12ms
#define IR_STOP_H_LEVEL_STANDARD_TIME (340)     // ��׼ֹͣ�ߵ�ƽʱ�� 0.5ms
#define IR_STOP_L_LEVEL_STANDARD_TIME (38732)   // ��׼ֹͣ�͵�ƽʱ�� 28ms
#define IR_LOGICAL_CODE_1_H_LEVEL_STANDARD_TIME (1100U)         // ��׼ �߼�1�ߵ�ƽʱ�� 1.395ms
#define IR_LOGICAL_CODE_1_L_LEVEL_STANDARD_TIME (500U)          // ��׼ �߼�1�͵�ƽʱ�� 0.456ms
#define IR_LOGICAL_CODE_0_H_LEVEL_STANDARD_TIME (356U)         // ��׼ �߼�0�ߵ�ƽʱ�� 0.52ms
#define IR_LOGICAL_CODE_0_L_LEVEL_STANDARD_TIME (1313U)        // ��׼ �߼�0�͵�ƽʱ�� 1.337ms

#define IR_START_H_LEVEL_TIME_MAX (IR_START_H_LEVEL_TIME + IR_STABLE_THRESHOLD)  // �����ߵ�ƽ���ֵ
#define IR_START_H_LEVEL_TIME_MIN (IR_START_H_LEVEL_TIME - IR_STABLE_THRESHOLD)  // �����ߵ�ƽ��Сֵ

#define IR_START_L_LEVEL_TIME_MAX (IR_START_L_LEVEL_TIME+3000U)  // �����͵�ƽ���ֵ
#define IR_START_L_LEVEL_TIME_MIN (IR_START_L_LEVEL_TIME-3000U)  // �����͵�ƽ��Сֵ

#elif PROTOCOL_CLASS == CLASS_433_32BIT
#define IR_START_H_LEVEL_STANDARD_TIME (8500U)  // ��׼�����ߵ�ƽʱ�� 8.5ms
#define IR_START_L_LEVEL_STANDARD_TIME (4000U)   // ��׼�����͵�ƽʱ�� 4ms
#define IR_STOP_H_LEVEL_STANDARD_TIME (500)     // ��׼ֹͣ�ߵ�ƽʱ�� 0.5ms
#define IR_STOP_L_LEVEL_STANDARD_TIME (28000)   // ��׼ֹͣ�͵�ƽʱ�� 28.0ms
#define IR_LOGICAL_CODE_1_H_LEVEL_STANDARD_TIME (500U)         // ��׼ �߼�1�ߵ�ƽʱ�� 0.5ms
#define IR_LOGICAL_CODE_1_L_LEVEL_STANDARD_TIME (500U)          // ��׼ �߼�1�͵�ƽʱ�� 0.5ms
#define IR_LOGICAL_CODE_0_H_LEVEL_STANDARD_TIME (500U)         // ��׼ �߼�0�ߵ�ƽʱ�� 0.5ms
#define IR_LOGICAL_CODE_0_L_LEVEL_STANDARD_TIME (1600U)        // ��׼ �߼�0�͵�ƽʱ�� 1.6ms

#define IR_START_H_LEVEL_TIME_MAX (IR_START_H_LEVEL_TIME+3000U)  // �����ߵ�ƽ���ֵ
#define IR_START_H_LEVEL_TIME_MIN (IR_START_H_LEVEL_TIME-3000U)  // �����ߵ�ƽ��Сֵ

#define IR_START_L_LEVEL_TIME_MAX (IR_START_L_LEVEL_TIME + IR_STABLE_THRESHOLD)  // �����͵�ƽ���ֵ
#define IR_START_L_LEVEL_TIME_MIN (IR_START_L_LEVEL_TIME - IR_STABLE_THRESHOLD)  // �����͵�ƽ��Сֵ
#endif

#define IR_START_H_LEVEL_TIME (IR_START_H_LEVEL_STANDARD_TIME/BASIC_TIME)   // ��Ƭ��������׼�����ߵ�ƽʱ�����
#define IR_START_L_LEVEL_TIME (IR_START_L_LEVEL_STANDARD_TIME/BASIC_TIME)   // ��Ƭ��������׼�����͵�ƽʱ�����
#define IR_STOP_H_LEVEL_TIME (IR_STOP_H_LEVEL_STANDARD_TIME/BASIC_TIME)     // ��Ƭ��������׼ֹͣ�ߵ�ƽʱ�����
#define IR_STOP_L_LEVEL_TIME (IR_STOP_L_LEVEL_STANDARD_TIME/BASIC_TIME)     // ��Ƭ��������׼ֹͣ�͵�ƽʱ�����


#define IR_STOP_H_LEVEL_TIME_MAX (IR_STOP_H_LEVEL_TIME+800)  // ֹͣ�ߵ�ƽ���ֵ
#define IR_STOP_H_LEVEL_TIME_MIN (IR_STOP_H_LEVEL_TIME-200U)  // ֹͣ�ߵ�ƽ��Сֵ

#define IR_STOP_L_LEVEL_TIME_MAX (IR_STOP_L_LEVEL_TIME+10000)  // ֹͣ�͵�ƽ���ֵ
#define IR_STOP_L_LEVEL_TIME_MIN (IR_STOP_L_LEVEL_TIME-21000)  // ֹͣ�͵�ƽ��Сֵ

#define IR_LOGICAL_CODE_1_H_LEVEL_TIME (IR_LOGICAL_CODE_1_H_LEVEL_STANDARD_TIME/BASIC_TIME)  //  ��Ƭ��������׼�߼�1�ߵ�ƽʱ�����
#define IR_LOGICAL_CODE_1_L_LEVEL_TIME (IR_LOGICAL_CODE_1_L_LEVEL_STANDARD_TIME/BASIC_TIME)  // ��Ƭ��������׼�߼�1�͵�ƽʱ�����

#define IR_LOGICAL_CODE_0_H_LEVEL_TIME (IR_LOGICAL_CODE_0_H_LEVEL_STANDARD_TIME/BASIC_TIME)  //  ��Ƭ��������׼�߼�0�ߵ�ƽʱ�����
#define IR_LOGICAL_CODE_0_L_LEVEL_TIME (IR_LOGICAL_CODE_0_L_LEVEL_STANDARD_TIME/BASIC_TIME)  // ��Ƭ��������׼�߼�0�͵�ƽʱ�����

#define IR_LOGICAL_CODE_1_H_LEVEL_TIME_MAX (IR_LOGICAL_CODE_1_H_LEVEL_TIME+IR_STABLE_THRESHOLD)  // �߼�1�ߵ�ƽ���ֵ
#define IR_LOGICAL_CODE_1_H_LEVEL_TIME_MIN (IR_LOGICAL_CODE_1_H_LEVEL_TIME-IR_STABLE_THRESHOLD)  // �߼�1�ߵ�ƽ��Сֵ

#define IR_LOGICAL_CODE_1_L_LEVEL_TIME_MAX (IR_LOGICAL_CODE_1_L_LEVEL_TIME+IR_STABLE_THRESHOLD)  // �߼�1�͵�ƽ���ֵ
#define IR_LOGICAL_CODE_1_L_LEVEL_TIME_MIN (IR_LOGICAL_CODE_1_L_LEVEL_TIME-IR_STABLE_THRESHOLD)  // �߼�1�͵�ƽ��Сֵ

#define IR_LOGICAL_CODE_0_H_LEVEL_TIME_MAX (IR_LOGICAL_CODE_0_H_LEVEL_TIME+IR_STABLE_THRESHOLD)  // �߼�0�ߵ�ƽ���ֵ
#define IR_LOGICAL_CODE_0_H_LEVEL_TIME_MIN (IR_LOGICAL_CODE_0_H_LEVEL_TIME-IR_STABLE_THRESHOLD)  // �߼�0�ߵ�ƽ��Сֵ

#define IR_LOGICAL_CODE_0_L_LEVEL_TIME_MAX (IR_LOGICAL_CODE_0_L_LEVEL_TIME+IR_STABLE_THRESHOLD)  // �߼�0�͵�ƽ���ֵ
#define IR_LOGICAL_CODE_0_L_LEVEL_TIME_MIN (IR_LOGICAL_CODE_0_L_LEVEL_TIME-IR_STABLE_THRESHOLD)   // �߼�0�͵�ƽ��Сֵ

IR ir_data;

// ��ʼ������
static void init(IR *ir)
{
    ir->is_start_decoded = false;
    ir->encode_num = 0;
    ir->h_level_time = 0;
    ir->l_level_time = 0;
    ir->key_number = 0;
    ir->data = 0;
}

void d_433_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStructure;
    EXTI_InitTypeDef EXTI_InitStructure;
    NVIC_InitTypeDef NVIC_InitStructure;

    // 1. ʹ��GPIOA��SYSCFGʱ��
    RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOA, ENABLE);
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_SYSCFG, ENABLE);

    // 2. ����GPIOΪ����
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_12;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN;
    GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;  // �ɸ�����Ҫ��Ϊ����������
    GPIO_Init(GPIOA, &GPIO_InitStructure);


    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_5;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN;
    GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;  // �ɸ�����Ҫ��Ϊ����������
    GPIO_Init(GPIOA, &GPIO_InitStructure);
    // 3. ��PA12���ӵ�EXTI��
    SYSCFG_EXTILineConfig(EXTI_PortSourceGPIOA, EXTI_PinSource12);
    SYSCFG_EXTILineConfig(EXTI_PortSourceGPIOA, EXTI_PinSource5);

    // 4. ����EXTI��
    EXTI_InitStructure.EXTI_Line = EXTI_Line12;
    EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
    EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Rising_Falling;  // ˫���ش���
    EXTI_InitStructure.EXTI_LineCmd = ENABLE;
    EXTI_Init(&EXTI_InitStructure);

    EXTI_InitStructure.EXTI_Line = EXTI_Line5;
    EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
    EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Rising_Falling;  // ˫���ش���
    EXTI_InitStructure.EXTI_LineCmd = ENABLE;
    EXTI_Init(&EXTI_InitStructure);
    // 5. ����NVIC
    NVIC_InitStructure.NVIC_IRQChannel = EXTI4_15_IRQn;  // PA12ʹ��EXTI4_15�ж�ͨ��
    NVIC_InitStructure.NVIC_IRQChannelPriority = 1;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);

    init(&ir_data);
}

static void decode_433()
{
    static uint8_t index = 0;

    if (ir_data.h_level_time >= IR_STOP_H_LEVEL_TIME_MIN && ir_data.h_level_time <= IR_STOP_H_LEVEL_TIME_MAX &&
        ir_data.l_level_time >= IR_STOP_L_LEVEL_TIME_MIN && ir_data.l_level_time <= IR_STOP_L_LEVEL_TIME_MAX) {

        ir_data.over = true;

        if (ir_data.is_long_press)ir_data.count = 0;
        ir_data.is_long_press = false;
    }

//    if (!ir_data.is_start_decoded) {
//        if (ir_data.h_level_time >= IR_START_H_LEVEL_TIME_MIN && ir_data.h_level_time <= IR_START_H_LEVEL_TIME_MAX &&
//            ir_data.l_level_time >= IR_START_L_LEVEL_TIME_MIN && ir_data.l_level_time <= IR_START_L_LEVEL_TIME_MAX) {
//            ir_data.is_start_decoded = true;
//            if (ir_data.encode_num < 50) {
//                ir_data.encode_num++;
//            }
//        }
//    } else {
    if (ir_data.h_level_time >= IR_LOGICAL_CODE_1_H_LEVEL_TIME_MIN &&
        ir_data.h_level_time <= IR_LOGICAL_CODE_1_H_LEVEL_TIME_MAX &&
        ir_data.l_level_time >= IR_LOGICAL_CODE_1_L_LEVEL_TIME_MIN &&
        ir_data.l_level_time <= IR_LOGICAL_CODE_1_L_LEVEL_TIME_MAX) {
        ir_data.data = (ir_data.data | 0x01);
        index++;

    } else if (ir_data.h_level_time >= IR_LOGICAL_CODE_0_H_LEVEL_TIME_MIN &&
               ir_data.h_level_time <= IR_LOGICAL_CODE_0_H_LEVEL_TIME_MAX &&
               ir_data.l_level_time >= IR_LOGICAL_CODE_0_L_LEVEL_TIME_MIN &&
               ir_data.l_level_time <= IR_LOGICAL_CODE_0_L_LEVEL_TIME_MAX) {
        ir_data.data = (ir_data.data | 0x00);
        index++;
    } else {
        ir_data.idle_time++;
        index = 0;
        ir_data.data = 0;
        ir_data.is_start_decoded = false;
        ir_data.encode_num = 0;

    }
#if PROTOCOL_CLASS == CLASS_433_24BIT
    if (index == 24) {
        ir_data.idle_time = 0;
        ir_data.key_number = (uint8_t) (ir_data.data);
        index = 0;
        ir_data.data = 0;
        ir_data.count++;
        ir_data.over = false;

//        ir_data.over = false;

//            if (ir_data.count > 20) ir_data.count = 20;
    } else {
        ir_data.data = ir_data.data << 1;
    }
#elif PROTOCOL_CLASS == CLASS_433_32BIT
    if (index == 32) {
        ir_data.key_number = (uint8_t) (ir_data.data);
        index = 0;
        ir_data.data = 0;
        ir_data.is_start_decoded = false;
    } else {
        ir_data.data = ir_data.data << 1;
    }
#endif

    if (ir_data.count >= 50 && !ir_data.over) {
        ir_data.is_long_press = true;
    } else if (ir_data.count >= 1 && ir_data.over) {
        ir_data.is_short_press = true;
        ir_data.count = 0;

    }
//    }
}

void d_433_decode(void)
{
    decode_433();
}

 uint16_t timer;
 uint8_t timer2;
 bool d_433_on_or_off = false;  //false  ��  true  ��
void d_433_scan(void)
{
    extern Menu_With_Numbers *ptr;
    extern Menu_With_Numbers Axxx;
    extern Menu_With_Numbers AUxx;
    extern Menu_With_Numbers SAVE;
    extern Menu_With_Numbers IRxx_b;

    if (IRxx_b.number != 1  || !console_data.console_ir_mode) return;

    if (ir_data.is_long_press) { timer++; }else{ timer = 0;}
//    if (ir_data.is_short_press) { timer2++; }else{ timer2 = 0;}

    if (ir_data.is_short_press || timer >= 60) {
        if (ir_data.is_short_press) ir_data.is_short_press = false;
        if (ir_data.is_long_press) timer = 20;


        if (ir_data.key_number != IR_ON && d_433_on_or_off) {
            return;
        }else{
            d_433_on_or_off = false;
        }

        switch (ir_data.key_number) {
            case IR_OFF:
                sys_fun_OOOO_B();
                flash_write();
                ptr = &Off;
                d_433_on_or_off = true;

                break;
            case  IR_ON:
                if (ptr == &Off) {
                    Flash_GetSaveVariable();
                }

                break;
            case IR_DMX:
                if (ptr != &Axxx) {
                    ptr = &Axxx;
                }
                break;
            case IR_AUTO:
                if (ptr == &A1xx) {
                    ptr = &A2xx;
                }else if (ptr == &A2xx) {
                    ptr = &A3xx;
                }else if (ptr == &A3xx) {
                    ptr = &A4xx;
                }else if (ptr == &A4xx) {
                    ptr = &A5xx;
                }else if (ptr == &A5xx) {
                    ptr = &A6xx;
                }else if (ptr == &A6xx) {
                    ptr = &A7xx;
                }else if (ptr == &A7xx) {
                    ptr = &A8xx;
                }else if (ptr == &A8xx) {
                    ptr = &A9xx;
                }else if (ptr == &A9xx) {
                    ptr = &AAxx;
                }else if (ptr == &AAxx) {
                    ptr = &ABxx;
                }else if (ptr == &ABxx) {
                    ptr = &ACxx;
                }else if (ptr == &ACxx) {
                    ptr = &ADxx;
                }else if (ptr == &ADxx) {
                    ptr = &AExx;
                }else if (ptr == &AExx) {
                    ptr = &AFxx;
                }else if (ptr == &AFxx) {
                    ptr = &A1xx;
                }else{
                    ptr = &A1xx;
                }
                break;
            case IR_SPEED_ADD:
                if (ptr == &A1xx) {
                    number_add(&A1xx);
                } else if (ptr == &A2xx) {
                    number_add(&A2xx);
                } else if (ptr == &A3xx) {
                    number_add(&A3xx);
                } else if (ptr == &A4xx) {
                    number_add(&A4xx);
                } else if (ptr == &A5xx) {
                    number_add(&A5xx);
                } else if (ptr == &A6xx) {
                    number_add(&A6xx);
                } else if (ptr == &A7xx) {
                    number_add(&A7xx);
                } else if (ptr == &A8xx) {
                    number_add(&A8xx);
                } else if (ptr == &A9xx) {
                    number_add(&A9xx);
                } else if (ptr == &AAxx) {
                    number_add(&AAxx);
                } else if (ptr == &ABxx) {
                    number_add(&ABxx);
                } else if (ptr == &ACxx) {
                    number_add(&ACxx);
                } else if (ptr == &ADxx) {
                    number_add(&ADxx);
                } else if (ptr == &AExx) {
                    number_add(&AExx);
                } else if (ptr == &AFxx) {
                    number_add(&AFxx);
                }
                break;
            case IR_SPEED_SUB:
                set_flag_false();
                if (ptr == &A1xx) {
                    number_subtract(&A1xx);
                } else if (ptr == &A2xx) {
                    number_subtract(&A2xx);
                } else if (ptr == &A3xx) {
                    number_subtract(&A3xx);
                } else if (ptr == &A4xx) {
                    number_subtract(&A4xx);
                } else if (ptr == &A5xx) {
                    number_subtract(&A5xx);
                } else if (ptr == &A6xx) {
                    number_subtract(&A6xx);
                } else if (ptr == &A7xx) {
                    number_subtract(&A7xx);
                } else if (ptr == &A8xx) {
                    number_subtract(&A8xx);
                } else if (ptr == &A9xx) {
                    number_subtract(&A9xx);
                } else if (ptr == &AAxx) {
                    number_subtract(&AAxx);
                } else if (ptr == &ABxx) {
                    number_subtract(&ABxx);
                } else if (ptr == &ACxx) {
                    number_subtract(&ACxx);
                } else if (ptr == &ADxx) {
                    number_subtract(&ADxx);
                } else if (ptr == &AExx) {
                    number_subtract(&AExx);
                } else if (ptr == &AFxx){
                    number_subtract(&AFxx);
                }
                break;
            case IR_VOICE:
                set_flag_false();
                if (ptr == &S1xx) {
                    ptr = &S2xx;
                } else if (ptr == &S2xx){
                    ptr = &S1xx;
                }else {
                    ptr = &S1xx;
                }
                break;
            case IR_MIC_ADD:
                if (ptr == &S1xx) {
                    number_add(&S1xx);
                } else if (ptr == &S2xx){
                    number_add(&S2xx);
                }
                break;
            case IR_MIC_SUB:
                if (ptr == &S1xx) {
                    number_subtract(&S1xx);
                } else if (ptr == &S2xx){
                    number_subtract(&S2xx);
                }
                break;
            case IR_1:
                if (ptr == &Axxx) {
                    number_add(&Axxx);
                }
                break;
            case IR_2:
                if (ptr == &Axxx) {
                    number_subtract(&Axxx);
                }
                break;
            case IR_3:
                if (ptr != &Cxxx) {
                    ptr = &Cxxx;
                }
                break;
            case IR_4:
                if (ptr == &Cxxx) {
                    number_add(&Cxxx);
                }
                break;
            case IR_5:
                if (ptr == &Cxxx) {
                    number_subtract(&Cxxx);
                }
                break;
            case IR_Y:
                flash_write();
                save_flag = 1;
                break;
            default:
                break;
        }

    }

}
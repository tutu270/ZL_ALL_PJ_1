#include "digital_tube_driver.h"
#include "TM1650.h"
#include "menu/menu.h"

#if  DIGITAL_TUBE_CONTROL_CHIP == IO_CONTROL      //�������ʾ����������оƬIO����
GPIO_TypeDef *pin_addr[] = {SMS_H_GPIO_Port, SMS_G_GPIO_Port, SMS_F_GPIO_Port, SMS_E_GPIO_Port, SMS_D_GPIO_Port,
                            SMS_C_GPIO_Port, SMS_B_GPIO_Port, SMS_A_GPIO_Port};
uint32_t pin[] = {SMS_H_Pin, SMS_G_Pin, SMS_F_Pin, SMS_E_Pin, SMS_D_Pin, SMS_C_Pin, SMS_B_Pin, SMS_A_Pin};
#elif   DIGITAL_TUBE_CONTROL_CHIP == CHIP_AIP650_Or_TM1650
uint8_t aip650_index = 0;
uint8_t api650_flicker_data;
#endif


static uint8_t displays_char[] = {
        SHOW_A, SHOW_B, SHOW_C, SHOW_D, SHOW_E, SHOW_F, SHOW_G, SHOW_H, SHOW_I, SHOW_J, SHOW_K,
        SHOW_L, SHOW_M, SHOW_N, SHOW_O, SHOW_P, SHOW_Q, SHOW_R, SHOW_S, SHOW_T, SHOW_U,
        SHOW_V, SHOW_W, SHOW_X, SHOW_Y, SHOW_Z};

static uint8_t displays_num[] = {
        SHOW_NUM0, SHOW_NUM1, SHOW_NUM2, SHOW_NUM3, SHOW_NUM4, SHOW_NUM5, SHOW_NUM6, SHOW_NUM7, SHOW_NUM8, SHOW_NUM9
};

static bool check_char_is_digital(char c)
{
    // ����ַ��Ƿ��������ַ���Χ��
    return c >= '0' && c <= '9';
    // ���б�ע�ͣ�������Ǽ���״̬��������ַ��Ƿ�Ϊ��ĸ
    // return (c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z');
}

static void Displays_Driver(uint8_t data)
{
    uint8_t addr[] = {0x68, 0x6A, 0x6C, 0x6E};
    if (ptr == &Off) {
        tm1650_send_command(addr[aip650_index], NO_DATA);
    }else{
        if (0xff == api650_flicker_data) {
            tm1650_send_command(addr[aip650_index], data);
        } else {
            tm1650_send_command(addr[aip650_index], NO_DATA);

        }
    }

}

void Display_Send( char data,char data2) {


    if (check_char_is_digital(data)){
        Displays_Driver(displays_num[data- '0'] | data2);
    }else{
        if (data == '-') {
            Displays_Driver(segG | data2);
        }else{
            Displays_Driver(displays_char[data - 'A'] | data2);
        }
    }

}

void Display_Flicker_ForBit(uint8_t index, uint8_t bit1cycle, uint8_t bit2cycle, uint8_t bit3cycle, uint8_t bit4cycle)
{
    static uint8_t time = 0;
    time++;
    time %= 200;

    aip650_index = index;
    switch (index) {
        case 0:
            if (bit1cycle == 0) {
                api650_flicker_data = 0xFF;
            } else {
                if (time < bit1cycle) {
                    api650_flicker_data = 0x00;
                } else {
                    api650_flicker_data = 0xFF;
                }
            }
            break;
        case 1:
            if (bit2cycle == 0) {
                api650_flicker_data = 0xFF;
            } else if (time < bit2cycle) {
                if (time < bit2cycle) {
                    api650_flicker_data = 0x00;
                } else {
                    api650_flicker_data = 0xFF;
                }
            }
            break;
        case 2:
            if (bit3cycle == 0) {
                api650_flicker_data = 0xFF;
            } else if (time < bit3cycle) {
                if (time < bit3cycle) {
                    api650_flicker_data = 0x00;
                } else {
                    api650_flicker_data = 0xFF;
                }
            }
            break;
        case 3:
            if (bit4cycle == 0) {
                api650_flicker_data = 0xFF;
            } else if (time < bit4cycle) {
                if (time < bit4cycle) {
                    api650_flicker_data = 0x00;
                } else {
                    api650_flicker_data = 0xFF;
                }
            }
            break;
        default:
            break;
    }
#

}

char Display_Flicker_For_Only_segP(uint8_t index, uint8_t bit1cycle, uint8_t bit2cycle, uint8_t bit3cycle,
                                   uint8_t bit4cycle,bool is_open) {

    static uint8_t time = 0;
   
		 if (!is_open){
        return   0x00;
    }
    time++;
    time%=200;

    if (bit1cycle != 0 && index == 0) {
        api650_flicker_data = 0xFF;
        if (time < bit1cycle){
            return segP;
        }
    }

    if (bit2cycle != 0 && index == 1 ) {
        api650_flicker_data = 0xFF;
        if (time < bit2cycle){
            return segP;
        }
    }
    if (bit3cycle != 0 && index == 2 ) {
        api650_flicker_data = 0xFF;
        if (time < bit3cycle){
            return segP;
        }
    }
    if (bit4cycle != 0 && index == 3 ) {
        api650_flicker_data = 0xFF;
        if (time < bit4cycle){
            return segP;
        }
    }
    return  0x00;
}
void Display_ChoiceBit(uint8_t index, uint8_t bit1cycle, uint8_t bit2cycle, uint8_t bit3cycle, uint8_t bit4cycle)
{


    Display_Flicker_ForBit(index, bit1cycle, bit2cycle, bit3cycle, bit4cycle);
}

//void DisplayCharForISR(const char *data, uint8_t bit1cycle, uint8_t bit2cycle, uint8_t bit3cycle, uint8_t bit4cycle,
//                       enum SegmentationType seg_mode)
//{
//    static uint8_t index = 0;
//    uint8_t res = 0;
//    static uint8_t time = 0;
//    static bool flag = true;
//    if (flag) {
//        Display_ChoiceBit(index, bit1cycle, bit2cycle, bit3cycle, bit4cycle);
//        if (1 == seg_mode) {
//            Display_Send(data[index],
//                         DisplayUtils::Display_Flicker_For_Only_segP(index, bit1cycle, bit2cycle, bit3cycle, bit4cycle,
//                                                                     is_open));
//        } else if (0 == seg_mode) {
//            Display_Send(data[index],
//                         DisplayUtils::Display_Flicker_For_With_segP(index, bit1cycle, bit2cycle, bit3cycle, bit4cycle,
//                                                                     is_open));
//        }
//        res = 4;
//        flag = false;
//    }
//
//    if (time < res) time++;
//    else {
//        time = 0;
//        index = (++index) % 4;
//        flag = true;
//    }
//}


void DisplayChar(const char *data,uint8_t bit1cycle, uint8_t bit2cycle, uint8_t bit3cycle, uint8_t bit4cycle,bool is_open) {
	int i = 0;
    for (i = 0; i < 4; i++) {
        Display_ChoiceBit(i, bit1cycle, bit2cycle, bit3cycle, bit4cycle);
        Display_Send(data[i],Display_Flicker_For_Only_segP(i, bit1cycle, bit2cycle, bit3cycle, bit4cycle, is_open) );
    }
}

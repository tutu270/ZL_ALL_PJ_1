#ifndef __MAIN_H__
#define __MAIN_H__

#include "stm32f0xx.h"
#include <stdbool.h>
#define ALIGN(n)                            __attribute__((aligned(n)))
#define   u32      unsigned int 
#define   u16     unsigned short
#define   u8      unsigned char	
	

#define uint8 	unsigned char
#define uint16 	unsigned short int
#define uint32	unsigned long int





#define  TRUE  1
#define FALSE  !TRUE






typedef struct  _SYSTEM
{
    unsigned char
			 ms5cTask,
		 c5msDelay,
		c10msDelay,
		c20msDelay,
			 c2msDelay,
		 SysTickTimer,
		 SysTickTimer50us,
		 SysTickTimer100us,
	    cTask,

		ctickCount,
		bPanTiltTick,
		ctickCountms,
		cDebugValue;
    unsigned int

		wPowerOnCount;


}SYSTEM, *P_SYSTEM;


//ALIGN(1)
//typedef union{
//	uint16_t ODR;
//	struct{
//		//uint32_t reserved:16;
//		uint16_t bit0:1;
//		uint16_t bit1:1;
//		uint16_t bit2:1;
//		uint16_t bit3:1;
//		uint16_t bit4:1;
//		uint16_t bit5:1;
//		uint16_t bit6:1;
//		uint16_t bit7:1;
//		uint16_t bit8:1;
//		uint16_t bit9:1;
//		uint16_t bit10:1;
//		uint16_t bit11:1;
//		uint16_t bit12:1;
//		uint16_t bit13:1;
//		uint16_t bit14:1;
//		uint16_t bit15:1;
//	}ODR_BITS;
//}PORT, *PORT_PTR;


//extern PORT_PTR pa_odr_ptr,  pb_odr_ptr, pc_odr_ptr , pd_odr_ptr, pf_odr_ptr, pa_idr_ptr,pb_idr_ptr, pc_idr_ptr, pd_idr_ptr;

//extern SYSTEM System;

//uint32_t GetSystemRunTime(void);
#include "stdio.h"

#endif

